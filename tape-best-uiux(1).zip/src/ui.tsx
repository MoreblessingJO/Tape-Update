import React, { useEffect, useRef, useState } from "react";
import { cn } from "./utils/cn";

/* ---------------- scroll reveal ---------------- */
export function Reveal({
  children,
  className,
  delay = 0,
}: {
  children: React.ReactNode;
  className?: string;
  delay?: number;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const [inView, setInView] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(
      ([e]) => {
        if (e.isIntersecting) {
          setInView(true);
          io.disconnect();
        }
      },
      { threshold: 0.12, rootMargin: "0px 0px -40px 0px" }
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);
  return (
    <div
      ref={ref}
      className={cn("reveal", inView && "in", className)}
      style={{ "--d": `${delay}s` } as React.CSSProperties}
    >
      {children}
    </div>
  );
}

/* ---------------- animated counter ---------------- */
export function CountUp({
  to,
  decimals = 0,
  prefix = "",
  suffix = "",
  duration = 1700,
  className,
}: {
  to: number;
  decimals?: number;
  prefix?: string;
  suffix?: string;
  duration?: number;
  className?: string;
}) {
  const ref = useRef<HTMLSpanElement>(null);
  const [val, setVal] = useState(0);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const io = new IntersectionObserver(
      ([e]) => {
        if (!e.isIntersecting) return;
        io.disconnect();
        if (reduced) {
          setVal(to);
          return;
        }
        const t0 = performance.now();
        const step = (t: number) => {
          const p = Math.min(1, (t - t0) / duration);
          const eased = 1 - Math.pow(1 - p, 3);
          setVal(to * eased);
          if (p < 1) requestAnimationFrame(step);
        };
        requestAnimationFrame(step);
      },
      { threshold: 0.4 }
    );
    io.observe(el);
    return () => io.disconnect();
  }, [to, duration]);
  return (
    <span ref={ref} className={className}>
      {prefix}
      {val.toLocaleString(undefined, { minimumFractionDigits: decimals, maximumFractionDigits: decimals })}
      {suffix}
    </span>
  );
}

/* ---------------- sparkline ---------------- */
export function Sparkline({
  points,
  w = 120,
  h = 36,
  up = true,
  className,
  id,
  delay = 0.3,
}: {
  points: number[];
  w?: number;
  h?: number;
  up?: boolean;
  className?: string;
  id: string;
  delay?: number;
}) {
  const min = Math.min(...points);
  const max = Math.max(...points);
  const nx = (i: number) => (i / (points.length - 1)) * w;
  const ny = (v: number) => h - 3 - ((v - min) / (max - min || 1)) * (h - 6);
  const d = points.map((p, i) => `${i === 0 ? "M" : "L"}${nx(i).toFixed(1)},${ny(p).toFixed(1)}`).join(" ");
  const area = `${d} L${w},${h} L0,${h} Z`;
  const color = up ? "#17c964" : "#f43f5e";
  return (
    <svg width={w} height={h} viewBox={`0 0 ${w} ${h}`} className={className} aria-hidden>
      <defs>
        <linearGradient id={id} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor={color} stopOpacity="0.3" />
          <stop offset="100%" stopColor={color} stopOpacity="0" />
        </linearGradient>
      </defs>
      <path d={area} fill={`url(#${id})`} className="spark-fill" />
      <path
        d={d}
        fill="none"
        stroke={color}
        strokeWidth={Math.max(1.5, h / 22)}
        strokeLinecap="round"
        strokeLinejoin="round"
        pathLength={1}
        className="spark-path"
        style={{ "--d": `${delay}s` } as React.CSSProperties}
      />
    </svg>
  );
}

/* ---------------- avatar ---------------- */
export function Avatar({
  src,
  name,
  size = 40,
  className,
}: {
  src: string;
  name: string;
  size?: number;
  className?: string;
}) {
  return (
    <img
      src={src}
      alt={name}
      loading="lazy"
      width={size}
      height={size}
      className={cn("shrink-0 rounded-full bg-neutral-200 object-cover", className)}
      style={{ width: size, height: size }}
    />
  );
}

/* ---------------- follow button ---------------- */
export function FollowButton({
  label = "Follow",
  className,
}: {
  label?: string;
  className?: string;
}) {
  const [on, setOn] = useState(false);
  return (
    <button
      type="button"
      onClick={(e) => {
        e.stopPropagation();
        setOn((v) => !v);
      }}
      className={cn(
        "shrink-0 rounded-full px-3.5 py-1.5 text-[10px] font-bold transition-all duration-200 active:scale-90",
        on
          ? "border border-neutral-300 bg-white text-neutral-500 hover:border-neutral-400"
          : "bg-ink text-white shadow-sm hover:bg-neutral-700",
        className
      )}
    >
      {on ? "Following" : label}
    </button>
  );
}

/* ---------------- tab pills ---------------- */
export function TabPills({
  tabs,
  active,
  onChange,
  className,
}: {
  tabs: string[];
  active: string;
  onChange?: (t: string) => void;
  className?: string;
}) {
  return (
    <div className={cn("no-scrollbar flex gap-1.5 overflow-x-auto", className)}>
      {tabs.map((t) => (
        <button
          key={t}
          type="button"
          onClick={() => onChange?.(t)}
          className={cn(
            "shrink-0 whitespace-nowrap rounded-full px-3.5 py-1.5 text-[10px] font-bold transition-colors duration-150",
            active === t
              ? "bg-ink text-white"
              : "border border-neutral-200 bg-white text-neutral-500 hover:border-neutral-400 hover:text-neutral-800"
          )}
        >
          {t}
        </button>
      ))}
    </div>
  );
}

/* ---------------- live ticking price ---------------- */
export function useTick(base: number, spread: number, ms = 2800) {
  const [s, setS] = useState({ v: base, dir: 0, n: 0 });
  useEffect(() => {
    const id = window.setInterval(() => {
      setS((prev) => {
        const delta = (Math.random() - 0.48) * spread;
        return { v: prev.v + delta, dir: delta >= 0 ? 1 : -1, n: prev.n + 1 };
      });
    }, ms);
    return () => window.clearInterval(id);
  }, [spread, ms]);
  return s;
}

/* ---------------- section heading ---------------- */
export function Kicker({ children, className }: { children: React.ReactNode; className?: string }) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-2 rounded-full border border-neutral-900/15 bg-white px-3.5 py-1.5 text-[11px] font-extrabold uppercase tracking-[0.18em] text-neutral-600",
        className
      )}
    >
      <span className="relative flex h-1.5 w-1.5">
        <span className="ping-ring absolute inline-flex h-full w-full rounded-full bg-gain" />
        <span className="relative inline-flex h-1.5 w-1.5 rounded-full bg-gain" />
      </span>
      {children}
    </span>
  );
}
