import { cn } from "./utils/cn";
import { sourceHealth, useMarket, type ProviderInfo } from "./api/market";
import { IcBolt, IcCopy, IcShield, IcTrendUp } from "./icons";
import { TabPills } from "./ui";
import { useState } from "react";

const statusMeta: Record<ProviderInfo["status"], { label: string; cls: string; dot: string }> = {
  live: { label: "Live", cls: "bg-gain/15 text-[#0b6b3a]", dot: "bg-gain" },
  demo: { label: "Demo data", cls: "bg-neutral-100 text-neutral-500", dot: "bg-neutral-300" },
  loading: { label: "Connecting", cls: "bg-sky-100 text-sky-700", dot: "bg-sky-500" },
  error: { label: "Error", cls: "bg-loss/10 text-loss", dot: "bg-loss" },
};

const screenMap = [
  { screen: "Discover · leaderboard", fields: "pnl_7d / pnl_30d / pnl_90d, win_rate, aum_usd, venue, chain", used: "RankedBoard" },
  { screen: "Home · Top traders", fields: "name, handle, avatar_url, followers, pnl_90d", used: "HomePage → TraderCard" },
  { screen: "Home · Live alerts", fields: "NormalizedTrade: side, token, size_usd, price_usd, executed_at", used: "LiveAlerts" },
  { screen: "Trade · post + copy ticket", fields: "entry, target, stop, size_usd, thesis", used: "TradePage / CopyModal" },
  { screen: "Copy engine", fields: "Trade events + user risk config; exits execute server-side", used: "CopyProvider → execution worker" },
  { screen: "Wallet · holdings", fields: "Balances, positions and realized/unrealized PnL per wallet", used: "WalletPage" },
];

const CHECKS = [
  {
    t: "Proxy every provider behind your own API",
    d: "Browser code holds no secret. Vercel/Netlify function or an Express service injects BIRDEYE_API_KEY, HELIUS_API_KEY and the PumpPortal key, then returns the Tape contract.",
  },
  {
    t: "Point the three VITE_* URLs at that service",
    d: "VITE_TAPE_API_URL, VITE_PUMPFUN_INDEXER_URL and VITE_ONCHAIN_INDEXER_URL. Each needs GET /leaderboard?window=7d|30d|90d returning { traders: ApiTrader[] }.",
  },
  {
    t: "Index continuously, not on page load",
    d: "PumpPortal websocket + Helius/Birdeye pollers write fills to Postgres. Serve leaderboard snapshots from materialized views refreshed every 30–60s.",
  },
  {
    t: "Compute PnL and rank server-side",
    d: "Cost basis, realized/unrealized PnL and drawdown need full trade history. The client only renders; never trusts browser-side math for a leaderboard.",
  },
  {
    t: "Execute copies on the backend",
    d: "The copy engine (allocation, TP, SL, trailing, max investment) runs as a worker on fill events. The client configures and reports; it never signs or holds keys.",
  },
  {
    t: "Label data honestly",
    d: "Every provider card here shows Live / Demo / Error. Until a URL is set, the app stays in Demo mode and the badge follows the data through the UI.",
  },
];

export function DataSourcesPage({ onFindTraders }: { onFindTraders: () => void }) {
  const { sources, mode, lastSync, refresh, loading } = useMarket();
  const health = sourceHealth(sources);
  const [tab, setTab] = useState("Providers");

  return (
    <div className="fadeup mx-auto flex max-w-[1060px] flex-col gap-5">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="font-display text-[28px] font-extrabold tracking-tight">Data sources</h1>
          <p className="mt-1 max-w-2xl text-[12px] font-medium leading-relaxed text-neutral-500">
            Tape normalizes three upstreams into one contract before anything reaches a screen. This page is the
            wiring map: what is connected, which endpoint feeds which view, and what stays server-side.
          </p>
        </div>
        <button
          type="button"
          onClick={refresh}
          disabled={loading}
          className="inline-flex items-center gap-1.5 rounded-full bg-ink px-4 py-2.5 text-[12px] font-extrabold text-white transition-all hover:bg-neutral-700 active:scale-95 disabled:opacity-60"
        >
          <IcBolt className="h-3.5 w-3.5" /> {loading ? "Syncing…" : "Refresh now"}
        </button>
      </div>

      <div className="grid gap-3 sm:grid-cols-3">
        <div className="rounded-2xl border border-neutral-200 bg-white p-4">
          <div className="text-[9px] font-extrabold uppercase tracking-[0.14em] text-neutral-400">Connection mode</div>
          <div className="mt-1 flex items-center gap-2">
            <span
              className={cn(
                "h-2 w-2 rounded-full",
                mode === "live" ? "bg-gain" : mode === "partial" ? "bg-amber-400" : "bg-neutral-300"
              )}
            />
            <span className="font-display text-[20px] font-extrabold capitalize">{mode}</span>
          </div>
          <div className="text-[10px] font-medium text-neutral-400">
            {health.live}/{health.total} providers live · {health.total - health.configured} on demo
          </div>
        </div>
        <div className="rounded-2xl border border-neutral-200 bg-white p-4">
          <div className="text-[9px] font-extrabold uppercase tracking-[0.14em] text-neutral-400">Last sync</div>
          <div className="mt-1 font-display text-[20px] font-extrabold">Just now</div>
          <div className="text-[10px] font-medium text-neutral-400">
            {lastSync ? new Date(lastSync).toLocaleTimeString() : "—"}
          </div>
        </div>
        <div className="rounded-2xl border border-neutral-200 bg-white p-4">
          <div className="text-[9px] font-extrabold uppercase tracking-[0.14em] text-neutral-400">Client keys</div>
          <div className="mt-1 flex items-center gap-1.5 font-display text-[20px] font-extrabold">
            <IcShield className="h-4 w-4 text-gain" /> None
          </div>
          <div className="text-[10px] font-medium text-neutral-400">All provider keys live behind the proxy</div>
        </div>
      </div>

      <TabPills tabs={["Providers", "Field mapping", "Integration checklist"]} active={tab} onChange={setTab} className="justify-start" />

      {tab === "Providers" && (
        <div className="flex flex-col gap-4">
          {sources.map((s) => {
            const meta = statusMeta[s.status];
            return (
              <div key={s.id} className="rounded-3xl border border-neutral-200 bg-white p-5">
                <div className="flex flex-wrap items-start gap-3">
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-2">
                      <h2 className="text-[15px] font-extrabold">{s.label}</h2>
                      <span className={cn("inline-flex items-center gap-1.5 rounded-full px-2 py-0.5 text-[9.5px] font-extrabold", meta.cls)}>
                        <span className={cn("h-1.5 w-1.5 rounded-full", meta.dot)} />
                        {meta.label}
                      </span>
                      <span className="rounded-md bg-paper px-1.5 py-0.5 text-[9.5px] font-bold text-neutral-500">
                        {s.records} records
                      </span>
                    </div>
                    <p className="mt-1 text-[11.5px] font-medium leading-relaxed text-neutral-500">{s.powers}</p>
                  </div>
                  <code className="shrink-0 rounded-lg bg-paper px-2.5 py-1.5 font-mono text-[10px] font-bold text-neutral-600">
                    {s.envKey}={s.baseUrl ? "configured" : "unset"}
                  </code>
                </div>

                <div className="mt-3 grid gap-3 sm:grid-cols-2">
                  <div className="rounded-xl bg-paper p-3">
                    <div className="text-[9px] font-extrabold uppercase tracking-[0.12em] text-neutral-400">
                      Upstream this route wraps
                    </div>
                    <ul className="mt-1.5 flex flex-col gap-1">
                      {s.upstream.map((u) => (
                        <li key={u} className="break-words font-mono text-[10px] font-medium leading-relaxed text-neutral-600">
                          {u}
                        </li>
                      ))}
                    </ul>
                  </div>
                  <div className="flex flex-col gap-2">
                    <div className="rounded-xl bg-paper p-3">
                      <div className="text-[9px] font-extrabold uppercase tracking-[0.12em] text-neutral-400">Coverage</div>
                      <div className="mt-0.5 text-[11px] font-bold">{s.chains}</div>
                    </div>
                    <div className="rounded-xl bg-paper p-3">
                      <div className="text-[9px] font-extrabold uppercase tracking-[0.12em] text-neutral-400">Auth</div>
                      <div className="mt-0.5 text-[10.5px] font-medium leading-relaxed text-neutral-500">{s.auth}</div>
                    </div>
                  </div>
                </div>

                {s.error && (
                  <div className="mt-3 rounded-xl border border-loss/20 bg-loss/5 px-3 py-2 text-[10.5px] font-semibold text-loss">
                    {s.error}
                  </div>
                )}
              </div>
            );
          })}
          <div className="flex flex-wrap items-center justify-between gap-3 rounded-3xl bg-ink p-5 text-white">
            <div className="flex items-start gap-2.5">
              <IcTrendUp className="mt-0.5 h-4 w-4 shrink-0 text-gain" />
              <div>
                <div className="text-[12px] font-extrabold">One ranking across all three venues</div>
                <p className="mt-0.5 max-w-xl text-[11px] font-medium leading-relaxed text-white/60">
                  Merge, de-duplicate by wallet, then rank with {`pnl_7d / pnl_30d / pnl_90d`}. The leaderboard and the
                  Copy buttons read the exact same normalized rows.
                </p>
              </div>
            </div>
            <button
              type="button"
              onClick={onFindTraders}
              className="rounded-full bg-white px-4 py-2 text-[11px] font-extrabold text-ink transition-colors hover:bg-gain"
            >
              View the ranked board
            </button>
          </div>
        </div>
      )}

      {tab === "Field mapping" && (
        <div className="overflow-hidden rounded-3xl border border-neutral-200 bg-white">
          <div className="border-b border-neutral-200 px-5 py-4">
            <h2 className="text-[14px] font-extrabold">Screen → data contract</h2>
            <p className="mt-0.5 text-[11px] font-medium text-neutral-400">
              Component names match the source files, so this doubles as a wiring guide.
            </p>
          </div>
          <div className="flex flex-col divide-y divide-neutral-100">
            {screenMap.map((m) => (
              <div key={m.screen} className="flex flex-col gap-1 px-5 py-3.5 sm:flex-row sm:items-start sm:gap-4">
                <div className="w-[220px] shrink-0 text-[11.5px] font-extrabold">{m.screen}</div>
                <div className="min-w-0 flex-1 font-mono text-[10.5px] font-medium leading-relaxed text-neutral-500">
                  {m.fields}
                </div>
                <div className="shrink-0 rounded-md bg-paper px-2 py-0.5 text-[9.5px] font-bold text-neutral-500">
                  {m.used}
                </div>
              </div>
            ))}
          </div>
          <div className="border-t border-neutral-200 bg-paper px-5 py-4">
            <div className="text-[9px] font-extrabold uppercase tracking-[0.12em] text-neutral-400">
              ApiTrader contract (src/api/market.tsx)
            </div>
            <pre className="mt-2 overflow-x-auto rounded-xl bg-ink p-4 font-mono text-[10px] leading-relaxed text-white/80">
{`{
  id, venue: "tape" | "pumpfun" | "onchain",
  name, handle, avatar_url, chain, verified, followers,
  win_rate, aum_usd,
  pnl_7d, pnl_30d, pnl_90d,
  updated_at
}`}
            </pre>
          </div>
        </div>
      )}

      {tab === "Integration checklist" && (
        <div className="flex flex-col gap-3">
          {CHECKS.map((c, i) => (
            <div key={c.t} className="rounded-2xl border border-neutral-200 bg-white p-4">
              <div className="flex items-start gap-3">
                <span className="flex h-6 w-6 shrink-0 items-center justify-center rounded-full bg-ink text-[10px] font-extrabold text-white">
                  {i + 1}
                </span>
                <div>
                  <div className="text-[12.5px] font-extrabold">{c.t}</div>
                  <p className="mt-0.5 text-[11.5px] font-medium leading-relaxed text-neutral-500">{c.d}</p>
                </div>
              </div>
            </div>
          ))}
          <div className="rounded-2xl border border-neutral-200 bg-white p-4">
            <div className="flex items-center gap-1.5 text-[12px] font-extrabold">
              <IcCopy className="h-3.5 w-3.5 text-neutral-400" /> Same contract for every provider
            </div>
            <pre className="mt-2 overflow-x-auto rounded-xl bg-paper p-4 font-mono text-[10px] leading-relaxed text-neutral-600">
{`# .env.local  (server-owned; do not commit)
VITE_TAPE_API_URL=https://api.tape.trade
VITE_PUMPFUN_INDEXER_URL=https://api.tape.trade/pumpfun
VITE_ONCHAIN_INDEXER_URL=https://api.tape.trade/onchain

# -- proxy holds these, browser never sees them --
BIRDEYE_API_KEY=...
HELIUS_API_KEY=...
PUMPPORTAL_API_KEY=...`}
            </pre>
          </div>
        </div>
      )}
    </div>
  );
}
