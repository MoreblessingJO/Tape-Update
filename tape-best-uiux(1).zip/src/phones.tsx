import React, { useState } from "react";
import { cn } from "./utils/cn";
import {
  GAINERS,
  HOME_TOP,
  LOSERS,
  NOTIFS,
  ONCHAIN_TOP,
  PLATFORM_TOP,
  TRADERS,
  TRENDING,
  type Notif,
  type Trader,
} from "./data";
import {
  CoinBadge,
  IcBack,
  IcBell,
  IcBookmark,
  IcChat,
  IcChevR,
  IcDoc,
  IcEye,
  IcHeart,
  IcHome,
  IcMore,
  IcPulse,
  IcPlus,
  IcRep,
  IcSearch,
  IcShare,
  IcGear,
  IcTrendDown,
  IcTrendUp,
  IcUser,
  IcUserPlus,
  IcWallet,
  LogoMark,
  StatusBarRight,
  Verified,
} from "./icons";
import { Avatar, FollowButton, Sparkline, TabPills, useTick } from "./ui";

/* ================= frame ================= */

export function Phone({ children, className }: { children: React.ReactNode; className?: string }) {
  return (
    <div
      className={cn(
        "w-[286px] shrink-0 rounded-[42px] border border-neutral-200/90 bg-white p-[7px]",
        "shadow-[0_50px_90px_-25px_rgba(12,16,28,0.35),0_8px_20px_-8px_rgba(12,16,28,0.15)]",
        className
      )}
    >
      <div className="overflow-hidden rounded-[35px] bg-white">
        <div className="flex items-center justify-between px-6 pb-1 pt-3">
          <span className="text-[11px] font-bold tracking-tight">9:41</span>
          <StatusBarRight />
        </div>
        <div className="h-[558px] overflow-hidden px-4 pb-3">{children}</div>
      </div>
    </div>
  );
}

const NAV = [
  { id: "Home", Icon: IcHome },
  { id: "Discover", Icon: IcSearch },
  { id: "Trade", Icon: IcPulse },
  { id: "Wallet", Icon: IcWallet },
  { id: "Profile", Icon: IcUser },
];

function BottomNav({ active }: { active: string }) {
  return (
    <div className="mt-auto flex items-center justify-around border-t border-neutral-100 pb-1 pt-2">
      {NAV.map(({ id, Icon }) => (
        <button
          key={id}
          type="button"
          className={cn(
            "flex flex-col items-center gap-[3px] transition-colors",
            active === id ? "text-ink" : "text-neutral-300 hover:text-neutral-500"
          )}
        >
          <Icon className="h-[19px] w-[19px]" />
          <span className="text-[8px] font-bold">{id}</span>
        </button>
      ))}
    </div>
  );
}

function SectionHead({ title, action }: { title: string; action?: string }) {
  return (
    <div className="flex items-center justify-between">
      <h3 className="text-[13px] font-extrabold tracking-tight">{title}</h3>
      {action && (
        <button type="button" className="text-[9px] font-bold text-neutral-400 hover:text-ink">
          {action}
        </button>
      )}
    </div>
  );
}

/* ================= 1 · HOME ================= */

export function HomeScreen() {
  const [feed, setFeed] = useState("For You");
  const [wl, setWl] = useState("Watchlist");
  const [sub, setSub] = useState("Trending");
  const { v, dir, n } = useTick(12480.2, 14);
  const rows = sub === "Gainers" ? GAINERS : sub === "Losers" ? LOSERS : TRENDING;

  return (
    <div className="flex h-full flex-col gap-2.5">
      <div className="flex items-center justify-between pt-0.5">
        <LogoMark className="h-7 w-7 text-ink" />
        <button type="button" className="relative text-neutral-800" aria-label="notifications">
          <IcBell className="h-[21px] w-[21px]" />
          <span className="absolute -right-0.5 -top-0.5 h-2 w-2 rounded-full bg-gain ring-2 ring-white" />
        </button>
      </div>

      <div className="flex items-center gap-3">
        <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-ink text-white">
          <IcPlus className="h-5 w-5" />
        </span>
        <div className="min-w-0">
          <div
            key={n}
            className={cn("inline-flex items-center gap-2 px-0.5", dir === 1 && "tick-up", dir === -1 && "tick-down")}
          >
            <span className="font-display text-[19px] font-extrabold tracking-tight">
              ${v.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </span>
            <IcEye className="h-4 w-4 text-neutral-400" />
          </div>
          <div className="text-[10px] font-extrabold text-gain">+8.24% (24H)</div>
        </div>
      </div>

      <TabPills tabs={["For You", "Following", "Trending"]} active={feed} onChange={setFeed} />

      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-[#04291a] via-[#0a5a33] to-[#12a457] p-3.5">
        <svg
          className="pointer-events-none absolute -right-1 bottom-1 h-11 w-24 text-white/60"
          viewBox="0 0 100 50"
          fill="none"
          aria-hidden
        >
          <path d="M2 46 L32 28 L52 36 L88 8" stroke="currentColor" strokeWidth="4" strokeLinecap="round" />
          <path d="M76 5 L92 5 L90 21" stroke="currentColor" strokeWidth="4" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
        <div className="font-display text-[14px] font-extrabold leading-[1.12] text-white">
          Trade With
          <br />
          Top Traders
        </div>
        <div className="mt-1 max-w-[74%] text-[8.5px] font-medium leading-snug text-white/75">
          Follow real traders, see their trades, and trade smarter.
        </div>
      </div>

      <div>
        <SectionHead title="Top Traders to Follow" action="See All" />
        <div className="mt-2 grid grid-cols-3 gap-2">
          {HOME_TOP.map((id) => {
            const t = TRADERS[id];
            return (
              <div key={id} className="flex flex-col items-center gap-1">
                <div className="relative">
                  <Avatar src={t.img} name={t.name} size={40} />
                  <span className="absolute -bottom-0.5 -right-0.5 flex h-4 w-4 items-center justify-center rounded-full bg-ink text-white ring-2 ring-white">
                    <IcPlus className="h-2.5 w-2.5" />
                  </span>
                </div>
                <span className="max-w-[76px] truncate text-[9px] font-bold">{t.name}</span>
                <span className="text-[9px] font-extrabold text-gain">{t.pnl}</span>
              </div>
            );
          })}
        </div>
      </div>

      <TabPills tabs={["Watchlist", "Spots", "Futures", "Memes"]} active={wl} onChange={setWl} />
      <TabPills tabs={["Trending", "Gainers", "Losers"]} active={sub} onChange={setSub} />

      <div className="flex flex-col gap-2">
        {rows.map((r) => (
          <div key={r.sym} className="flex items-center gap-2">
            <CoinBadge sym={r.sym} className="h-8 w-8 text-[12px]" />
            <div className="w-[66px]">
              <div className="text-[11px] font-extrabold leading-tight">{r.sym}</div>
              <div className="truncate text-[9px] font-medium text-neutral-400">{r.name}</div>
            </div>
            <Sparkline points={r.points} w={46} h={24} up={r.up} id={`home-${r.sym}`} delay={0.5} />
            <div className="ml-auto text-right">
              <div className="text-[11px] font-extrabold leading-tight">{r.price}</div>
              <div className={cn("text-[9px] font-extrabold", r.up ? "text-gain" : "text-loss")}>{r.change}</div>
            </div>
            <IcChevR className="h-3.5 w-3.5 text-neutral-300" />
          </div>
        ))}
      </div>

      <BottomNav active="Home" />
    </div>
  );
}

/* ================= 2 · DISCOVER ================= */

export function DiscoverScreen() {
  const [tab, setTab] = useState("Traders");

  return (
    <div className="flex h-full flex-col gap-3">
      <LogoMark className="h-7 w-7 text-ink" />
      <h2 className="-mt-1 font-display text-[22px] font-extrabold tracking-tight">Discover</h2>

      <label className="flex items-center gap-2 rounded-xl bg-neutral-100 px-3 py-2.5">
        <IcSearch className="h-3.5 w-3.5 text-neutral-400" />
        <input
          placeholder="Search traders, tokens, wallets…"
          className="w-full bg-transparent text-[10px] font-medium outline-none placeholder:text-neutral-400"
        />
      </label>

      <TabPills tabs={["Traders", "Wallets", "Tokens", "Lists"]} active={tab} onChange={setTab} />

      {tab === "Traders" && (
        <>
          <div>
            <SectionHead title="Top Platform Traders" action="See All" />
            <div className="mt-1.5 flex flex-col gap-1.5">
              {PLATFORM_TOP.map((id) => (
                <TraderRow key={id} t={TRADERS[id]} />
              ))}
            </div>
          </div>
          <div>
            <SectionHead title="Top On-chain Traders" action="See All" />
            <div className="mt-1.5 flex flex-col gap-1.5">
              {ONCHAIN_TOP.map((id) => (
                <TraderRow key={id} t={TRADERS[id]} />
              ))}
            </div>
          </div>
        </>
      )}

      {tab === "Wallets" && (
        <div className="flex flex-col gap-1.5">
          {ONCHAIN_TOP.map((id) => {
            const t = TRADERS[id];
            return (
              <div key={id} className="flex items-center gap-2.5 rounded-xl bg-neutral-50 px-3 py-2.5">
                <IcWallet className="h-4 w-4 text-neutral-500" />
                <div className="min-w-0">
                  <div className="truncate font-mono text-[10px] font-bold">{t.handle}</div>
                  <div className="text-[8.5px] font-medium text-neutral-400">Ethereum · 312 trades (90D)</div>
                </div>
                <span className="ml-auto text-[10px] font-extrabold text-gain">{t.pnl}</span>
              </div>
            );
          })}
        </div>
      )}

      {tab === "Tokens" && (
        <div className="flex flex-col gap-1.5">
          {TRENDING.map((r) => (
            <div key={r.sym} className="flex items-center gap-2.5 rounded-xl bg-neutral-50 px-3 py-2.5">
              <CoinBadge sym={r.sym} className="h-8 w-8 text-[11px]" />
              <div>
                <div className="text-[10.5px] font-extrabold">{r.sym}</div>
                <div className="text-[8.5px] font-medium text-neutral-400">{r.name}</div>
              </div>
              <div className="ml-auto text-right">
                <div className="text-[10.5px] font-extrabold">{r.price}</div>
                <div className={cn("text-[8.5px] font-extrabold", r.up ? "text-gain" : "text-loss")}>{r.change}</div>
              </div>
            </div>
          ))}
        </div>
      )}

      {tab === "Lists" && (
        <div className="flex flex-col gap-1.5">
          {[
            { n: "AI Narratives", d: "42 tokens · +318% avg 90D" },
            { n: "L2 Blue Chips", d: "18 tokens · +124% avg 90D" },
            { n: "Fresh Degen Bets", d: "9 tokens · +97% avg 90D" },
          ].map((l) => (
            <div key={l.n} className="flex items-center gap-2.5 rounded-xl bg-neutral-50 px-3 py-2.5">
              <IcDoc className="h-4 w-4 text-neutral-500" />
              <div>
                <div className="text-[10.5px] font-extrabold">{l.n}</div>
                <div className="text-[8.5px] font-medium text-neutral-400">{l.d}</div>
              </div>
              <IcChevR className="ml-auto h-3.5 w-3.5 text-neutral-300" />
            </div>
          ))}
        </div>
      )}

      <BottomNav active="Discover" />
    </div>
  );
}

function TraderRow({ t }: { t: Trader }) {
  return (
    <div className="flex items-center gap-2.5 rounded-xl px-1 py-1 transition-colors hover:bg-neutral-50">
      <div className="relative">
        <Avatar src={t.img} name={t.name} size={38} />
        <span className="absolute -bottom-0.5 -right-0.5 h-2.5 w-2.5 rounded-full bg-gain ring-2 ring-white" />
      </div>
      <div className="min-w-0">
        <div className="flex items-center gap-1">
          <span className="truncate text-[11px] font-extrabold leading-tight">{t.name}</span>
          <Verified className="h-3 w-3 shrink-0" />
        </div>
        <div className="text-[9.5px] font-extrabold leading-tight text-gain">{t.pnl} (90D)</div>
        <div className="truncate text-[8.5px] font-medium text-neutral-400">{t.followers}</div>
      </div>
      <FollowButton className="ml-auto" />
    </div>
  );
}

/* ================= 3 · TRADER PROFILE ================= */

const POSITIONS = [
  { sym: "SOL", pct: "42.5%", val: "$164,630", pnl: "+18.7%" },
  { sym: "BTC", pct: "28.1%", val: "$108,850", pnl: "+6.4%" },
  { sym: "ETH", pct: "12.6%", val: "$48,790", pnl: "+9.1%" },
];
const MINI_TRADES = [
  { side: "BUY", txt: "2,500 SOL @ $168.40", time: "2m ago" },
  { side: "SELL", txt: "10.2 ETH @ $3,842.00", time: "3h ago" },
  { side: "LONG", txt: "5.1 BTC (10x)", time: "1d ago" },
];

export function ProfileScreen() {
  const [tab, setTab] = useState("Portfolio");
  const t = TRADERS.kaito;

  return (
    <div className="flex h-full flex-col gap-3">
      <div className="flex items-center justify-between pt-0.5">
        <IcBack className="h-5 w-5 text-ink" />
        <IcMore className="h-5 w-5 text-ink" />
      </div>

      <div className="flex items-center gap-3">
        <Avatar src={t.img} name={t.name} size={56} />
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-1.5">
            <span className="font-display text-[17px] font-extrabold tracking-tight">{t.name}</span>
            <Verified className="h-4 w-4" />
          </div>
          <div className="text-[10px] font-medium text-neutral-400">{t.handle}</div>
        </div>
        <FollowButton label="Follow" className="px-4 py-2 text-[11px]" />
      </div>

      <p className="-mt-1 text-[10px] font-medium leading-relaxed text-neutral-500">
        Crypto Trader | On-chain Analyst | Macro &amp; Narrative Plays
      </p>

      <div className="grid grid-cols-3 divide-x divide-neutral-100 rounded-2xl border border-neutral-100 bg-white py-2.5">
        {[
          { v: "88.1K", l: "Followers" },
          { v: "420", l: "Following" },
          { v: "+482%", l: "90D PnL", g: true },
        ].map((s) => (
          <div key={s.l} className="px-3 text-center">
            <div className={cn("font-display text-[14px] font-extrabold", s.g && "text-gain")}>{s.v}</div>
            <div className="text-[8px] font-bold uppercase tracking-wider text-neutral-400">{s.l}</div>
          </div>
        ))}
      </div>

      <div className="rounded-2xl bg-neutral-50 p-3">
        <div className="flex items-start justify-between gap-2">
          <div>
            <div className="text-[9px] font-bold uppercase tracking-wider text-neutral-400">Total PnL (90D)</div>
            <div className="font-display text-[20px] font-extrabold tracking-tight text-gain">+482.3%</div>
          </div>
          <Sparkline
            points={[2, 4, 3, 7, 5, 9, 8, 12, 10, 15, 13, 18, 16, 22]}
            w={130}
            h={44}
            id="profile-pnl"
            delay={0.4}
            className="mt-1 shrink-0"
          />
        </div>
        <div className="mt-2 grid grid-cols-3 divide-x divide-neutral-200/70 border-t border-neutral-200/70 pt-2 text-center">
          {[
            { l: "Win Rate", v: "72%" },
            { l: "Total Trades", v: "1,264" },
            { l: "Avg. R:R", v: "1:3.8" },
          ].map((s) => (
            <div key={s.l} className="px-2">
              <div className="text-[8.5px] font-bold text-neutral-400">{s.l}</div>
              <div className="text-[11px] font-extrabold">{s.v}</div>
            </div>
          ))}
        </div>
      </div>

      <TabPills tabs={["Portfolio", "Trades", "Thesis", "About"]} active={tab} onChange={setTab} />

      <div className="min-h-0 flex-1">
        {tab === "Portfolio" && (
          <div>
            <div className="mb-1.5 flex items-center justify-between">
              <span className="text-[11px] font-extrabold">Portfolio ($387,420)</span>
              <span className="text-[10px] font-extrabold text-gain">+12.4%</span>
            </div>
            <div className="flex flex-col gap-2">
              {POSITIONS.map((p) => (
                <div key={p.sym} className="flex items-center gap-2.5">
                  <CoinBadge sym={p.sym} className="h-8 w-8 text-[11px]" />
                  <div className="w-9">
                    <div className="text-[10.5px] font-extrabold leading-tight">{p.sym}</div>
                    <div className="text-[8.5px] font-medium text-neutral-400">{p.pct}</div>
                  </div>
                  <div className="ml-auto text-right">
                    <div className="text-[10.5px] font-extrabold leading-tight">{p.val}</div>
                    <div className="text-[8.5px] font-extrabold text-gain">{p.pnl}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
        {tab === "Trades" && (
          <div className="flex flex-col gap-1.5">
            {MINI_TRADES.map((tr) => (
              <div key={tr.txt} className="flex items-center gap-2.5 rounded-xl bg-neutral-50 px-3 py-2.5">
                <span
                  className={cn(
                    "rounded-md px-1.5 py-0.5 text-[8px] font-extrabold",
                    tr.side === "SELL" ? "bg-loss/10 text-loss" : "bg-gain/10 text-gain"
                  )}
                >
                  {tr.side}
                </span>
                <span className="text-[10px] font-bold">{tr.txt}</span>
                <span className="ml-auto text-[8.5px] font-medium text-neutral-400">{tr.time}</span>
              </div>
            ))}
          </div>
        )}
        {tab === "Thesis" && (
          <p className="text-[10px] font-medium leading-relaxed text-neutral-600">
            SOL is showing strong momentum after the recent ecosystem updates. I’m accumulating on dips while DEX
            volume stays elevated. Macro window into Q3 looks constructive — target $210, invalid below $150.
          </p>
        )}
        {tab === "About" && (
          <div className="flex flex-col gap-2 text-[10px] font-medium">
            <div className="text-neutral-600">Crypto Trader | On-chain Analyst | Macro &amp; Narrative Plays</div>
            <div className="flex justify-between border-t border-neutral-100 pt-2">
              <span className="text-neutral-400">Joined</span>
              <span className="font-bold">March 2024</span>
            </div>
            <div className="flex justify-between border-t border-neutral-100 pt-2">
              <span className="text-neutral-400">Focus</span>
              <span className="font-bold">L1 · L2 · AI</span>
            </div>
            <div className="flex justify-between border-t border-neutral-100 pt-2">
              <span className="text-neutral-400">Exchange</span>
              <span className="font-bold">Binance · Bybit</span>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

/* ================= 4 · TRADE POST ================= */

export function PostScreen() {
  const t = TRADERS.kaito;
  const { v, dir, n } = useTick(168.4, 0.4);

  return (
    <div className="flex h-full flex-col gap-3">
      <div className="flex items-center justify-between pt-0.5">
        <IcBack className="h-5 w-5 text-ink" />
        <div className="flex items-center gap-4">
          <IcShare className="h-[18px] w-[18px] text-ink" />
          <IcMore className="h-5 w-5 text-ink" />
        </div>
      </div>

      <div className="flex items-center gap-2.5">
        <Avatar src={t.img} name={t.name} size={40} />
        <div className="min-w-0">
          <div className="flex items-center gap-1">
            <span className="text-[12px] font-extrabold">{t.name}</span>
            <Verified className="h-3.5 w-3.5" />
          </div>
          <div className="text-[9px] font-medium text-neutral-400">2m ago</div>
        </div>
      </div>

      <div className="flex items-center gap-2.5">
        <span className="rounded-full bg-gain px-2.5 py-1 text-[9px] font-extrabold tracking-wide text-white">BUY</span>
        <CoinBadge sym="SOL" className="h-7 w-7 text-[10px]" />
        <span
          key={n}
          className={cn(
            "font-display text-[15px] font-extrabold tracking-tight",
            dir === 1 && "tick-up",
            dir === -1 && "tick-down"
          )}
        >
          ${v.toFixed(2)}
        </span>
        <span className="text-[10px] font-extrabold text-gain">+3.2%</span>
      </div>

      <div className="grid grid-cols-2 gap-x-3 gap-y-2.5 rounded-2xl bg-neutral-50 p-3">
        {[
          { l: "Position Size", v: "$50,000" },
          { l: "Entry", v: "$168.40" },
          { l: "Target", v: "$210.00" },
          { l: "Stop", v: "$154.00" },
        ].map((c) => (
          <div key={c.l}>
            <div className="text-[8px] font-bold uppercase tracking-wider text-neutral-400">{c.l}</div>
            <div className="text-[11.5px] font-extrabold">{c.v}</div>
          </div>
        ))}
      </div>

      <div>
        <div className="mb-1.5 flex items-center gap-1.5">
          <IcDoc className="h-3.5 w-3.5 text-neutral-500" />
          <span className="text-[11px] font-extrabold">My Thesis</span>
        </div>
        <p className="text-[9.5px] font-medium leading-relaxed text-neutral-600">
          SOL is showing strong momentum after the recent ecosystem updates, with rising DEX volume and fresh
          inflows from on-chain smart money. I’m accumulating here for a potential continuation to $210.
        </p>
      </div>

      <div>
        <div className="mb-2 flex items-center gap-1.5">
          <IcDoc className="h-3.5 w-3.5 text-neutral-500" />
          <span className="text-[11px] font-extrabold">Trade Update</span>
        </div>
        <div className="relative flex flex-col gap-3 pl-4">
          <span className="absolute bottom-2 left-[3.5px] top-2 w-px bg-neutral-200" />
          <div className="relative">
            <span className="absolute -left-4 top-1 h-2 w-2 rounded-full bg-gain" />
            <div className="text-[9.5px] font-extrabold leading-tight">Bought 2,500 SOL at $168.40</div>
            <div className="text-[8.5px] font-medium text-neutral-400">2m ago</div>
          </div>
          <div className="relative">
            <span className="absolute -left-4 top-1 h-2 w-2 rounded-full bg-neutral-300" />
            <div className="text-[9.5px] font-bold text-neutral-600">Target: $210.00</div>
          </div>
          <div className="relative">
            <span className="absolute -left-4 top-1 h-2 w-2 rounded-full bg-neutral-300" />
            <div className="text-[9.5px] font-bold text-neutral-600">Stop: $154.00</div>
          </div>
        </div>
      </div>

      <div className="flex items-center gap-5 border-t border-neutral-100 pt-2.5 text-[10px] font-bold text-neutral-500">
        <span className="flex items-center gap-1.5">
          <IcHeart className="h-4 w-4" /> 342
        </span>
        <span className="flex items-center gap-1.5">
          <IcChat className="h-4 w-4" /> 56
        </span>
        <span className="flex items-center gap-1.5">
          <IcRep className="h-4 w-4" /> 34
        </span>
        <IcBookmark className="ml-auto h-4 w-4" />
      </div>

      <div className="flex items-center gap-2">
        <Avatar src={TRADERS.macro.img} name="you" size={30} />
        <input
          placeholder="Add a comment…"
          className="h-8 w-full rounded-full bg-neutral-100 px-3.5 text-[9.5px] font-medium outline-none placeholder:text-neutral-400"
        />
      </div>
    </div>
  );
}

/* ================= 5 · NOTIFICATIONS ================= */

const KIND_META: Record<Notif["kind"], { cls: string; Icon: (p: { className?: string }) => React.ReactNode }> = {
  buy: { cls: "bg-gain/10 text-gain", Icon: (p) => <IcTrendUp {...p} /> },
  sell: { cls: "bg-loss/10 text-loss", Icon: (p) => <IcTrendDown {...p} /> },
  long: { cls: "bg-sky-100 text-sky-600", Icon: (p) => <IcTrendUp {...p} /> },
  thesis: { cls: "bg-neutral-200/70 text-neutral-600", Icon: (p) => <IcDoc {...p} /> },
  follow: { cls: "bg-indigo-100 text-indigo-600", Icon: (p) => <IcUserPlus {...p} /> },
  mention: { cls: "bg-amber-100 text-amber-600", Icon: (p) => <IcChat {...p} /> },
};

export function NotificationsScreen() {
  const [tab, setTab] = useState("All");
  const filtered = NOTIFS.filter((nt) =>
    tab === "All" ? true : tab === "Trades" ? ["buy", "sell", "long"].includes(nt.kind) : tab === "Follows" ? nt.kind === "follow" : nt.kind === "mention"
  );
  const days: ("Today" | "Yesterday")[] = ["Today", "Yesterday"].filter((d) =>
    filtered.some((x) => x.day === d)
  ) as ("Today" | "Yesterday")[];

  return (
    <div className="flex h-full flex-col gap-3">
      <div className="flex items-center justify-between pt-0.5">
        <span className="font-display text-[20px] font-extrabold tracking-tight">Notifications</span>
        <IcGear className="h-5 w-5 text-ink" />
      </div>

      <TabPills tabs={["All", "Trades", "Follows", "Mentions"]} active={tab} onChange={setTab} />

      <div className="flex min-h-0 flex-1 flex-col">
        {days.map((d) => (
          <div key={d} className="mb-1.5">
            <div className="mb-1 text-[9px] font-extrabold uppercase tracking-[0.14em] text-neutral-400">{d}</div>
            <div className="flex flex-col divide-y divide-neutral-50">
              {filtered
                .filter((x) => x.day === d)
                .map((nt) => {
                  const meta = KIND_META[nt.kind];
                  const t = nt.trader ? TRADERS[nt.trader] : null;
                  return (
                    <div key={nt.id} className="flex items-center gap-2.5 py-2">
                      {t ? (
                        <Avatar src={t.img} name={t.name} size={32} />
                      ) : (
                        <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-ink text-white">
                          <IcUserPlus className="h-4 w-4" />
                        </span>
                      )}
                      <span className={cn("flex h-7 w-7 shrink-0 items-center justify-center rounded-full", meta.cls)}>
                        <meta.Icon className="h-3.5 w-3.5" />
                      </span>
                      <p className="min-w-0 flex-1 text-[9.5px] font-medium leading-snug text-neutral-700">{nt.text}</p>
                      <span className="shrink-0 text-[8px] font-semibold text-neutral-400">{nt.time}</span>
                    </div>
                  );
                })}
            </div>
          </div>
        ))}
        {filtered.length === 0 && (
          <div className="mt-8 text-center text-[10px] font-medium text-neutral-400">Nothing here yet.</div>
        )}
      </div>

      <BottomNav active="Profile" />
    </div>
  );
}
