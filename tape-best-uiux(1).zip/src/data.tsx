import React from "react";

export const av = (id: number, size = 160) =>
  `https://images.pexels.com/photos/${id}/pexels-photo-${id}.jpeg?auto=compress&cs=tinysrgb&fit=crop&w=${size}&h=${size}`;

export type Trader = {
  id: string;
  name: string;
  handle: string;
  img: string;
  pnl: string;
  followers: string;
  win?: string;
  bio?: string;
};

export const TRADERS: Record<string, Trader> = {
  kaito: {
    id: "kaito",
    name: "OxKaito",
    handle: "@OxKaito",
    img: av(31420959),
    pnl: "+482%",
    followers: "88.1K followers",
    win: "72%",
    bio: "Crypto Trader | On-chain Analyst | Macro & Narrative Plays",
  },
  degen: {
    id: "degen",
    name: "DegenWizard",
    handle: "@DegenWizard",
    img: av(33136738),
    pnl: "+297%",
    followers: "32.4K followers",
    win: "64%",
  },
  sis: {
    id: "sis",
    name: "CryptoSis",
    handle: "@CryptoSis",
    img: av(10230832),
    pnl: "+189%",
    followers: "41.2K followers",
    win: "61%",
  },
  macro: {
    id: "macro",
    name: "MacroMike",
    handle: "@MacroMike",
    img: av(33680674),
    pnl: "+176%",
    followers: "24.7K followers",
    win: "68%",
  },
  suumi: {
    id: "suumi",
    name: "OxSuumi",
    handle: "0x4f…9c2d",
    img: av(5308640),
    pnl: "+1,203%",
    followers: "9.1K followers",
    win: "74%",
  },
  smart: {
    id: "smart",
    name: "SmartMoney",
    handle: "0x91…f8a1",
    img: av(749091),
    pnl: "+756%",
    followers: "15.3K followers",
    win: "71%",
  },
  whale: {
    id: "whale",
    name: "WhaleAlpha",
    handle: "0x7e…2d90",
    img: av(33680709),
    pnl: "+611%",
    followers: "22.8K followers",
    win: "66%",
  },
};

export const HOME_TOP = ["kaito", "degen", "sis"] as const;
export const PLATFORM_TOP = ["degen", "kaito", "macro"] as const;
export const ONCHAIN_TOP = ["suumi", "smart", "whale"] as const;

export type CoinRow = {
  sym: string;
  name: string;
  price: string;
  change: string;
  up: boolean;
  points: number[];
};

export const TRENDING: CoinRow[] = [
  { sym: "BTC", name: "Bitcoin", price: "$112,430", change: "+1.88%", up: true, points: [2, 4, 3, 6, 5, 8, 7, 10] },
  { sym: "SOL", name: "Solana", price: "$168.40", change: "+3.20%", up: true, points: [1, 2, 4, 3, 6, 8, 7, 9] },
  { sym: "ETH", name: "Ethereum", price: "$4,071.20", change: "+2.34%", up: true, points: [3, 2, 5, 4, 6, 5, 8, 9] },
];
export const GAINERS: CoinRow[] = [
  { sym: "ARB", name: "Arbitrum", price: "$1.24", change: "+4.02%", up: true, points: [1, 3, 2, 5, 7, 6, 9, 11] },
  { sym: "SOL", name: "Solana", price: "$168.40", change: "+3.20%", up: true, points: [1, 2, 4, 3, 6, 8, 7, 9] },
  { sym: "ETH", name: "Ethereum", price: "$4,071.20", change: "+2.34%", up: true, points: [2, 3, 2, 5, 4, 7, 8, 10] },
];
export const LOSERS: CoinRow[] = [
  { sym: "DOGE", name: "Dogecoin", price: "$0.1621", change: "-0.88%", up: false, points: [10, 8, 9, 6, 7, 5, 4, 3] },
  { sym: "AVAX", name: "Avalanche", price: "$42.18", change: "-1.12%", up: false, points: [9, 10, 7, 8, 5, 6, 4, 3] },
  { sym: "LINK", name: "Chainlink", price: "$18.74", change: "-0.42%", up: false, points: [8, 9, 7, 8, 6, 5, 6, 4] },
];

export type Notif = {
  id: number;
  trader?: string;
  kind: "buy" | "sell" | "long" | "thesis" | "follow" | "mention";
  text: React.ReactNode;
  time: string;
  day: "Today" | "Yesterday";
};

export const NOTIFS: Notif[] = [
  {
    id: 1,
    trader: "kaito",
    kind: "buy",
    text: (
      <>
        <b className="font-bold">OxKaito</b> bought 2,500 SOL at $168.40
      </>
    ),
    time: "2m ago",
    day: "Today",
  },
  {
    id: 2,
    trader: "degen",
    kind: "sell",
    text: (
      <>
        <b className="font-bold">DegenWizard</b> sold 10.2 ETH at $3,842.00
      </>
    ),
    time: "14m ago",
    day: "Today",
  },
  {
    id: 3,
    trader: "macro",
    kind: "long",
    text: (
      <>
        <b className="font-bold">MacroMike</b> opened a long on BTC (10x)
      </>
    ),
    time: "26m ago",
    day: "Today",
  },
  {
    id: 4,
    trader: "sis",
    kind: "thesis",
    text: (
      <>
        <b className="font-bold">CryptoSis</b> published a new thesis: “Why I’m Bullish on AI Tokens”
      </>
    ),
    time: "41m ago",
    day: "Today",
  },
  {
    id: 5,
    trader: "suumi",
    kind: "buy",
    text: (
      <>
        <b className="font-bold">OxSuumi</b> bought 1.5M TAPE at $0.0042
      </>
    ),
    time: "9:24 PM",
    day: "Yesterday",
  },
  {
    id: 6,
    kind: "follow",
    text: <>You gained 128 new followers</>,
    time: "8:11 PM",
    day: "Yesterday",
  },
  {
    id: 7,
    trader: "sis",
    kind: "mention",
    text: (
      <>
        <b className="font-bold">CryptoSis</b> mentioned you in “AI tokens are the next leg up”
      </>
    ),
    time: "7:58 PM",
    day: "Yesterday",
  },
];

export const TICKER = [
  { sym: "BTC", price: "$112,430.00", chg: "+1.88%", up: true },
  { sym: "ETH", price: "$4,071.20", chg: "+2.34%", up: true },
  { sym: "SOL", price: "$168.40", chg: "+3.20%", up: true },
  { sym: "TAPE", price: "$0.0042", chg: "+212.0%", up: true },
  { sym: "ARB", price: "$1.24", chg: "+4.02%", up: true },
  { sym: "LINK", price: "$18.74", chg: "+0.64%", up: true },
  { sym: "AVAX", price: "$42.18", chg: "-1.12%", up: false },
  { sym: "DOGE", price: "$0.1621", chg: "-0.88%", up: false },
  { sym: "TON", price: "$5.41", chg: "+1.06%", up: true },
  { sym: "SUI", price: "$3.87", chg: "+2.81%", up: true },
];

export const LEADERBOARD = [
  { rank: 1, t: TRADERS.suumi, win: "74%", aum: "$4.2M", pnl: "+1,203%" },
  { rank: 2, t: TRADERS.smart, win: "71%", aum: "$2.9M", pnl: "+756%" },
  { rank: 3, t: TRADERS.whale, win: "66%", aum: "$6.8M", pnl: "+611%" },
  { rank: 4, t: TRADERS.kaito, win: "72%", aum: "$3.9M", pnl: "+482%" },
  { rank: 5, t: TRADERS.degen, win: "64%", aum: "$1.7M", pnl: "+297%" },
  { rank: 6, t: TRADERS.sis, win: "61%", aum: "$2.2M", pnl: "+189%" },
];

export const QUOTES = [
  {
    q: "I caught the SOL flip before it printed. This app is my edge now — I don’t trade a candle I haven’t seen in the feed first.",
    t: TRADERS.kaito,
    tag: "+482% 90D",
  },
  {
    q: "I stopped guessing and started following wallets that actually pay. One tracked wallet called the ARB bottom for me.",
    t: TRADERS.degen,
    tag: "+297% 90D",
  },
  {
    q: "The thesis feed alone is worth the download. You get the reasoning, the target, the stop — it’s like a research note with receipts.",
    t: TRADERS.sis,
    tag: "+189% 90D",
  },
];
