/**
 * Tape market data layer.
 *
 * One normalized contract in front of three very different upstreams:
 *   1. Tape native  -> our own API (social feed + connected exchange accounts)
 *   2. Pump.fun     -> PumpPortal stream, indexed by our backend
 *   3. On-chain     -> Birdeye / Helius / Dune wallets, indexed by our backend
 *
 * The browser NEVER calls provider APIs with secret keys. Each provider URL below is a
 * route on our own backend (or a serverless proxy) that holds the key, normalizes the
 * upstream payload and returns the contract documented in `ApiTrader`.
 * If a URL is not configured, the app runs clearly-labelled demo data.
 */
import { createContext, useCallback, useContext, useEffect, useState } from "react";
import type { ReactNode } from "react";
import { RANKED, type Period, type Ranked, type Source } from "../copytrade";
import { TRADERS } from "../data";

/* ================= provider config ================= */

export type Venue = "tape" | "pumpfun" | "onchain";
export type ProviderStatus = "live" | "demo" | "error" | "loading";

export type ProviderInfo = {
  id: Venue;
  label: string;
  powers: string;
  envKey: string;
  baseUrl?: string;
  status: ProviderStatus;
  lastSync?: number;
  error?: string;
  records: number;
  upstream: string[];
  chains: string;
  auth: string;
};

const ENV = import.meta.env;

export const SOURCE_CONFIG: Omit<ProviderInfo, "status" | "lastSync" | "error" | "records">[] = [
  {
    id: "tape",
    label: "Tape native",
    envKey: "VITE_TAPE_API_URL",
    baseUrl: ENV.VITE_TAPE_API_URL,
    powers: "Tape traders’ fills, theses, follower counts and 7/30/90D leaderboard.",
    upstream: [
      "GET /v1/leaderboard?window=7d|30d|90d",
      "GET /v1/trades?since=<cursor>",
      "WS /v1/stream (fills, alerts)",
    ],
    chains: "Tape accounts + linked CEX (Binance, Bybit) and wallets",
    auth: "Server-held key only. Trades are recorded via connected exchange/wallet accounts.",
  },
  {
    id: "pumpfun",
    label: "Pump.fun",
    envKey: "VITE_PUMPFUN_INDEXER_URL",
    baseUrl: ENV.VITE_PUMPFUN_INDEXER_URL,
    powers: "Launchpad wallets, memecoin entries, realized PnL and market-cap context.",
    upstream: [
      "WS wss://pumpportal.fun/api/data · subscribeAccountTrade",
      "WS · subscribeNewToken / subscribeMigration",
      "GET /trades?mint=<CA>&limit=100 (PumpPortal REST wrapper)",
    ],
    chains: "Solana bonding curve + PumpSwap",
    auth: "PumpPortal API key + funded wallet for account/token subscriptions — kept on the server.",
  },
  {
    id: "onchain",
    label: "On-chain wallets",
    envKey: "VITE_ONCHAIN_INDEXER_URL",
    baseUrl: ENV.VITE_ONCHAIN_INDEXER_URL,
    powers: "Smart-money wallets across Solana, BSC, Ethereum and Base.",
    upstream: [
      "Birdeye GET /wallet/v2/pnl/summary · /v1/wallet/tx_list",
      "Helius POST getSignaturesForAddress · getTransaction",
      "EVM: Alchemy / Moralis / Covalent wallet activity",
    ],
    chains: "Solana · BSC · Ethereum · Base",
    auth: "Birdeye/Helius keys server-side. Wallets are discovered, not connected.",
  },
];

/* ================= normalized contract ================= */

/** What our backend must return. Keep this stable — every screen reads it. */
export type ApiTrader = {
  id: string;
  venue: Venue;
  name: string;
  handle: string;
  avatar_url?: string;
  chain: string;
  verified?: boolean;
  followers?: number;
  win_rate?: number; // 0..1
  aum_usd?: number;
  pnl_7d?: number; // percent
  pnl_30d?: number;
  pnl_90d?: number;
  updated_at?: string;
};

type ApiPayload = { traders?: ApiTrader[]; data?: ApiTrader[] };

const FALLBACK_AVATARS = Object.values(TRADERS).map((t) => t.img);
const toSource = (v: Venue): Source => (v === "pumpfun" ? "Pump.fun" : v === "onchain" ? "On-chain" : "Tape");

function normalize(api: ApiTrader[], fallbackDemo = false): Ranked[] {
  return api.map((t, i) => ({
    id: fallbackDemo ? (RANKED.find((r) => r.name === t.name)?.id ?? t.id) : t.id,
    name: t.name,
    handle: t.handle,
    img: t.avatar_url || FALLBACK_AVATARS[i % FALLBACK_AVATARS.length],
    source: toSource(t.venue),
    chain: t.chain,
    followers:
      t.followers === undefined ? "—" : t.followers >= 1000 ? `${(t.followers / 1000).toFixed(1)}K` : String(t.followers),
    win: t.win_rate === undefined ? "—" : `${Math.round(t.win_rate * 100)}%`,
    aum: t.aum_usd === undefined ? "—" : `$${(t.aum_usd / 1_000_000).toFixed(1)}M`,
    p: {
      "7D": Math.round(t.pnl_7d ?? 0),
      "30D": Math.round(t.pnl_30d ?? 0),
      "90D": Math.round(t.pnl_90d ?? 0),
    },
  }));
}

function demoRows(): Ranked[] {
  return RANKED.map((r) => ({ ...r, p: { ...r.p } }));
}

const TIMEOUT_MS = 8000;

async function fetchProvider(cfg: (typeof SOURCE_CONFIG)[number]): Promise<Ranked[]> {
  if (!cfg.baseUrl) throw new Error("not-configured");
  const base = cfg.baseUrl.replace(/\/$/, "");
  const ctrl = new AbortController();
  const timer = window.setTimeout(() => ctrl.abort(), TIMEOUT_MS);
  try {
    const res = await fetch(`${base}/leaderboard?window=90d&limit=50`, {
      signal: ctrl.signal,
      headers: { Accept: "application/json" },
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const body = (await res.json()) as ApiPayload;
    const rows = body.traders ?? body.data ?? [];
    if (!Array.isArray(rows) || rows.length === 0) throw new Error("empty payload");
    return normalize(rows);
  } finally {
    window.clearTimeout(timer);
  }
}

/* ================= provider ================= */

export type Market = {
  rows: Ranked[];
  sources: ProviderInfo[];
  mode: "live" | "partial" | "demo";
  lastSync?: number;
  loading: boolean;
  refresh: () => void;
};

const MarketContext = createContext<Market | null>(null);

export function useMarket(): Market {
  const ctx = useContext(MarketContext);
  if (!ctx) throw new Error("useMarket must be used inside MarketProvider");
  return ctx;
}

/** Safe version for components rendered on the marketing site (outside the provider). */
export function useMarketOptional(): Market | null {
  return useContext(MarketContext);
}

export function MarketProvider({ children }: { children: ReactNode }) {
  const [rows, setRows] = useState<Ranked[]>(demoRows);
  const [sources, setSources] = useState<ProviderInfo[]>(
    SOURCE_CONFIG.map((c) => ({
      ...c,
      status: c.baseUrl ? "loading" : "demo",
      records: c.baseUrl ? 0 : c.id === "tape" ? 3 : c.id === "pumpfun" ? 1 : 3,
    }))
  );
  const [loading, setLoading] = useState(false);

  const refresh = useCallback(async () => {
    setLoading(true);
    const nextInfo: ProviderInfo[] = [];
    let merged: Ranked[] = [];
    let live = 0;
    let configured = 0;

    for (const cfg of SOURCE_CONFIG) {
      if (cfg.baseUrl) {
        configured += 1;
        try {
          const liveRows = await fetchProvider(cfg);
          merged = merged.concat(liveRows);
          live += 1;
          nextInfo.push({ ...cfg, status: "live", records: liveRows.length, lastSync: Date.now() });
        } catch (e) {
          nextInfo.push({
            ...cfg,
            status: "error",
            records: 0,
            lastSync: Date.now(),
            error: e instanceof Error ? e.message : "request failed",
          });
        }
      } else {
        nextInfo.push({
          ...cfg,
          status: "demo",
          records: cfg.id === "tape" ? 3 : cfg.id === "pumpfun" ? 1 : 3,
        });
      }
    }

    // Demo supplement keeps every source represented while integration is in progress.
    const demo = demoRows().filter((d) => !merged.some((m) => m.name.toLowerCase() === d.name.toLowerCase()));
    setRows([...merged, ...demo]);
    setSources(nextInfo);
    setLoading(false);
    return { live, configured };
  }, []);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  // Demo-only tick: nudges 7D/30D numbers so the wiring is visible before keys exist.
  const anyLive = sources.some((s) => s.status === "live");
  useEffect(() => {
    if (anyLive) return;
    const id = window.setInterval(() => {
      setRows((prev) =>
        prev.map((r) => {
          const delta = Math.random() < 0.5 ? -1 : 1;
          return { ...r, p: { ...r.p, "7D": Math.max(-99, r.p["7D"] + delta) } };
        })
      );
    }, 9000);
    return () => window.clearInterval(id);
  }, [anyLive]);

  const mode: Market["mode"] =
    sources.every((s) => s.status === "live")
      ? "live"
      : sources.some((s) => s.status === "live")
        ? "partial"
        : "demo";

  return (
    <MarketContext.Provider value={{ rows, sources, mode, loading, refresh: () => void refresh(), lastSync: Date.now() }}>
      {children}
    </MarketContext.Provider>
  );
}

/* ================= ranking helpers (shared by landing + app) ================= */

export function rankBy(rows: Ranked[], period: Period, source: "All" | Source): Ranked[] {
  return [...rows]
    .filter((r) => source === "All" || r.source === source)
    .sort((a, b) => b.p[period] - a.p[period]);
}

export function sourceHealth(sources: ProviderInfo[]) {
  const configured = sources.filter((s) => s.status !== "demo").length;
  const live = sources.filter((s) => s.status === "live").length;
  return { configured, live, total: sources.length };
}
