import React, { useState } from "react";
import { LogoMark } from "./icons";
import { DiscoverScreen, HomeScreen, NotificationsScreen, Phone, PostScreen, ProfileScreen } from "./phones";
import { CTASection, Features, Footer, HowItWorks, Quotes, StatsBand, Ticker } from "./sections";
import { CopyEngine, CopyLeaderboard } from "./copylanding";
import { Reveal } from "./ui";
import TapeApp from "./webapp";

const PHONES: { C: () => React.ReactElement; floatDelay: number }[] = [
  { C: HomeScreen, floatDelay: 0 },
  { C: DiscoverScreen, floatDelay: 0.9 },
  { C: ProfileScreen, floatDelay: 1.8 },
  { C: PostScreen, floatDelay: 2.7 },
  { C: NotificationsScreen, floatDelay: 3.6 },
];

function Hero({ onStart }: { onStart: () => void }) {
  return (
    <header className="relative overflow-hidden">
      <div className="absolute inset-0 bg-[radial-gradient(78%_62%_at_50%_-10%,#d7e1f5_0%,#e9edf5_48%,#f7f7f3_100%)]" />
      <div className="relative mx-auto max-w-[1440px] px-6 pt-12 md:pt-16">
        {/* logo lockup */}
        <div className="fadeup flex items-center justify-center gap-3 md:gap-4" style={{ "--d": "0.05s" } as React.CSSProperties}>
          <LogoMark className="h-14 w-14 text-ink md:h-[76px] md:w-[76px]" />
          <span className="font-display text-[64px] font-black leading-none tracking-[-0.045em] md:text-[96px]">TAPE</span>
        </div>

        {/* headline */}
        <h1 className="mx-auto mt-8 max-w-[1200px] text-center font-display text-[clamp(2.15rem,5.6vw,4.75rem)] font-black leading-[1.04] tracking-[-0.035em] md:mt-10">
          <span className="mask-line" style={{ "--d": "0.15s" } as React.CSSProperties}>
            <span>Follow Traders.</span>
          </span>{" "}
          <span className="mask-line" style={{ "--d": "0.3s" } as React.CSSProperties}>
            <span>See Trades.</span>
          </span>{" "}
          <span className="mask-line" style={{ "--d": "0.45s" } as React.CSSProperties}>
            <span>Trade Smarter.</span>
          </span>
        </h1>

        <p
          className="fadeup mx-auto mt-5 max-w-[660px] text-center text-[15px] font-medium leading-relaxed text-slate-500 md:text-[17px]"
          style={{ "--d": "0.6s" } as React.CSSProperties}
        >
          Discover and rank top traders across Tape, Pump.fun and on-chain wallets. Follow their trades and theses —
          or copy with your own allocation, take profit, stop loss and trailing stop.
        </p>

        {/* phone mockups */}
        <div className="relative mt-14 md:mt-16">
          <div className="pointer-events-none absolute -bottom-10 left-1/2 h-28 w-[92%] max-w-[1000px] -translate-x-1/2 rounded-full bg-ink/10 blur-3xl" />
          <div className="no-scrollbar snap-x snap-mandatory overflow-x-auto pb-4 [mask-image:linear-gradient(90deg,transparent_0,black_28px,black_calc(100%-28px),transparent_100%)]">
            <div className="mx-auto flex w-max snap-x gap-4 px-2 md:gap-5">
              {PHONES.map(({ C, floatDelay }, i) => (
                <div
                  key={i}
                  className="phone-rise snap-center"
                  style={{ "--d": `${0.25 + i * 0.1}s` } as React.CSSProperties}
                >
                  <div className="floaty" style={{ "--d": `${floatDelay}s` } as React.CSSProperties}>
                    <Phone>
                      <C />
                    </Phone>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* CTAs */}
        <div
          className="fadeup mt-10 flex flex-wrap items-center justify-center gap-3 pb-20"
          style={{ "--d": "1s" } as React.CSSProperties}
        >
          <button
            type="button"
            onClick={onStart}
            className="rounded-full bg-ink px-7 py-3.5 text-sm font-extrabold text-white shadow-[0_16px_30px_-12px_rgba(11,13,16,0.5)] transition-all duration-300 hover:-translate-y-0.5 hover:bg-neutral-800 active:scale-95"
          >
            Start trading
          </button>
          <a
            href="#how"
            className="rounded-full border border-neutral-300 bg-white px-7 py-3.5 text-sm font-extrabold text-ink transition-all duration-300 hover:-translate-y-0.5 hover:border-ink active:scale-95"
          >
            How it works
          </a>
        </div>
      </div>
    </header>
  );
}

export default function App() {
  const [view, setView] = useState<"landing" | "app">("landing");
  const openApp = () => setView("app");

  if (view === "app") {
    return (
      <div id="web" className="relative">
        <div className="noise pointer-events-none fixed inset-0 z-50 opacity-[0.04] mix-blend-multiply" />
        <TapeApp onExit={() => setView("landing")} />
      </div>
    );
  }

  return (
    <div id="top" className="relative min-h-screen">
      {/* grain over everything, purely textural */}
      <div className="noise pointer-events-none fixed inset-0 z-50 opacity-[0.05] mix-blend-multiply" />

      <Ticker />
      <Hero onStart={openApp} />

      <main>
        <StatsBand />
        <Features />
        <CopyEngine onStart={openApp} />
        <CopyLeaderboard onCopy={openApp} />
        <HowItWorks />
        <Quotes />
        <CTASection onWebApp={openApp} />
      </main>

      <Reveal>
        <Footer />
      </Reveal>
    </div>
  );
}
