import { createContext, useContext, useMemo, useState } from "react";
import type { ReactNode } from "react";
import { cn } from "./utils/cn";
import { TRADERS } from "./data";
import { Avatar, FollowButton, TabPills } from "./ui";
import {
  IcBolt,
  IcClose,
  IcCopy,
  IcShield,
  IcSliders,
  IcTrendDown,
  IcTrendUp,
  Verified,
} from "./icons";

/* ================= cross-platform data ================= */

export type Source = "Tape" | "Pump.fun" | "On-chain";
export type Period = "7D" | "30D" | "90D";

export const SOURCE_META: Record<Source, { cls: string; dot: string }> = {
  Tape: { cls: "bg-ink text-white", dot: "bg-ink" },
  "Pump.fun": { cls: "bg-[#c8fbe3] text-[#066b41]", dot: "bg-gain" },
  "On-chain": { cls: "bg-sky-100 text-sky-700", dot: "bg-sky-500" },
};

export type Ranked = {
  id: string;
  name: string;
  handle: string;
  img: string;
  source: Source;
  chain: string;
  p: Record<Period, number>;
  win: string;
  aum: string;
  followers: string;
};

export const RANKED: Ranked[] = [
  { id: "suumi", name: "OxSuumi", handle: "0x4f…9c2d", img: TRADERS.suumi.img, source: "On-chain", chain: "Solana", p: { "7D": 312, "30D": 684, "90D": 1203 }, win: "74%", aum: "$4.2M", followers: "9.1K" },
  { id: "smart", name: "SmartMoney", handle: "0x91…f8a1", img: TRADERS.smart.img, source: "On-chain", chain: "BSC", p: { "7D": 198, "30D": 412, "90D": 756 }, win: "71%", aum: "$2.9M", followers: "15.3K" },
  { id: "whale", name: "WhaleAlpha", handle: "0x7e…2d90", img: TRADERS.whale.img, source: "On-chain", chain: "Ethereum", p: { "7D": 141, "30D": 330, "90D": 611 }, win: "66%", aum: "$6.8M", followers: "22.8K" },
  { id: "degen", name: "DegenWizard", handle: "@DegenWizard", img: TRADERS.degen.img, source: "Pump.fun", chain: "Solana", p: { "7D": 88, "30D": 164, "90D": 297 }, win: "64%", aum: "$1.7M", followers: "32.4K" },
  { id: "kaito", name: "OxKaito", handle: "@OxKaito", img: TRADERS.kaito.img, source: "Tape", chain: "Solana", p: { "7D": 62, "30D": 181, "90D": 482 }, win: "72%", aum: "$3.9M", followers: "88.1K" },
  { id: "sis", name: "CryptoSis", handle: "@CryptoSis", img: TRADERS.sis.img, source: "Tape", chain: "Base", p: { "7D": 41, "30D": 98, "90D": 189 }, win: "61%", aum: "$2.2M", followers: "41.2K" },
  { id: "macro", name: "MacroMike", handle: "@MacroMike", img: TRADERS.macro.img, source: "Tape", chain: "Hyperliquid", p: { "7D": 33, "30D": 87, "90D": 176 }, win: "68%", aum: "$1.4M", followers: "24.7K" },
];

export function rankedById(id: string) {
  return RANKED.find((r) => r.id === id);
}
export const fmtPct = (n: number) => `+${n.toLocaleString()}%`;

export function SourceBadge({ source, className }: { source: Source; className?: string }) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-md px-1.5 py-0.5 text-[9px] font-extrabold tracking-wide",
        SOURCE_META[source].cls,
        className
      )}
    >
      <span className={cn("h-1 w-1 rounded-full", source === "Tape" ? "bg-white/70" : SOURCE_META[source].dot)} />
      {source}
    </span>
  );
}

/* ================= copy engine state ================= */

export type CopyConfig = {
  id: string;
  traderId: string;
  allocation: number;
  maxInvestment: number;
  takeProfit: number;
  stopLoss: number;
  trailingStop: number;
  independentExits: boolean;
  copyNewEntries: boolean;
  mirrorExits: boolean;
  paused: boolean;
  spent: number;
  pnl: number;
  trades: number;
  since: string;
};

export type LogKind = "entry" | "take-profit" | "stop-loss" | "trailing" | "skip";
export type LogEntry = {
  id: number;
  kind: LogKind;
  title: string;
  detail: string;
  time: string;
  traderId: string;
  independent?: boolean;
  traderHolding?: boolean;
};

const SEED_CONFIGS: CopyConfig[] = [
  {
    id: "c1",
    traderId: "suumi",
    allocation: 100,
    maxInvestment: 100,
    takeProfit: 100,
    stopLoss: 20,
    trailingStop: 15,
    independentExits: true,
    copyNewEntries: true,
    mirrorExits: false,
    paused: false,
    spent: 100,
    pnl: 101.4,
    trades: 3,
    since: "Mar 2",
  },
  {
    id: "c2",
    traderId: "degen",
    allocation: 50,
    maxInvestment: 250,
    takeProfit: 60,
    stopLoss: 25,
    trailingStop: 10,
    independentExits: true,
    copyNewEntries: true,
    mirrorExits: false,
    paused: false,
    spent: 150,
    pnl: -12.4,
    trades: 3,
    since: "Feb 26",
  },
  {
    id: "c3",
    traderId: "kaito",
    allocation: 25,
    maxInvestment: 100,
    takeProfit: 45,
    stopLoss: 15,
    trailingStop: 12,
    independentExits: true,
    copyNewEntries: true,
    mirrorExits: true,
    paused: true,
    spent: 25,
    pnl: 4.2,
    trades: 1,
    since: "Feb 18",
  },
];

const SEED_LOG: LogEntry[] = [
  {
    id: 1,
    kind: "take-profit",
    title: "Take profit hit · +100%",
    detail: "Auto-sold 0.5M TAPE at $200K mcap for $201.40. OxSuumi is still holding.",
    time: "2m ago",
    traderId: "suumi",
    independent: true,
    traderHolding: true,
  },
  {
    id: 2,
    kind: "entry",
    title: "Copied entry · $100 deployed",
    detail: "OxSuumi bought TAPE at a $100K mcap. Your allocation executed automatically.",
    time: "6m ago",
    traderId: "suumi",
  },
  {
    id: 3,
    kind: "trailing",
    title: "Trailing stop · 15% from high",
    detail: "Sold WIF at $2.38 after a 15% pullback. The trader never closed this position.",
    time: "42m ago",
    traderId: "degen",
    independent: true,
    traderHolding: true,
  },
  {
    id: 4,
    kind: "stop-loss",
    title: "Stop loss · -20%",
    detail: "Closed the ARB copy at $0.98. Your risk limit was respected automatically.",
    time: "3h ago",
    traderId: "degen",
  },
  {
    id: 5,
    kind: "skip",
    title: "Skipped · max investment reached",
    detail: "OxKaito bought SOL, but your $100 cap for this trader is fully deployed.",
    time: "5h ago",
    traderId: "kaito",
  },
];

type CopyDraft = Omit<CopyConfig, "id" | "paused" | "spent" | "pnl" | "trades" | "since">;

type Ctx = {
  configs: CopyConfig[];
  log: LogEntry[];
  openCopy: (traderId: string, existing?: CopyConfig) => void;
  closeCopy: () => void;
  save: (draft: CopyDraft, existingId?: string) => void;
  isCopying: (traderId: string) => boolean;
  togglePause: (id: string) => void;
  stop: (id: string) => void;
  notify: (msg: string) => void;
  editing: { traderId: string; existing?: CopyConfig } | null;
};

const CopyContext = createContext<Ctx | null>(null);

export function useCopy() {
  const ctx = useContext(CopyContext);
  if (!ctx) throw new Error("useCopy must be used inside CopyProvider");
  return ctx;
}

export function CopyProvider({ children }: { children: ReactNode }) {
  const [configs, setConfigs] = useState<CopyConfig[]>(SEED_CONFIGS);
  const [log, setLog] = useState<LogEntry[]>(SEED_LOG);
  const [editing, setEditing] = useState<{ traderId: string; existing?: CopyConfig } | null>(null);
  const [toast, setToast] = useState<string | null>(null);

  const notify = (msg: string) => {
    setToast(msg);
    window.setTimeout(() => setToast((cur) => (cur === msg ? null : cur)), 3600);
  };

  const value: Ctx = {
    configs,
    log,
    editing,
    openCopy: (traderId, existing) => setEditing({ traderId, existing }),
    closeCopy: () => setEditing(null),
    isCopying: (traderId) => configs.some((c) => c.traderId === traderId && !c.paused),
    togglePause: (id) =>
      setConfigs((prev) => prev.map((c) => (c.id === id ? { ...c, paused: !c.paused } : c))),
    stop: (id) =>
      setConfigs((prev) => {
        const cfg = prev.find((c) => c.id === id);
        if (cfg) notify(`Copy of ${TRADERS[cfg.traderId]?.name ?? "trader"} stopped. Open positions stay yours to close.`);
        return prev.filter((c) => c.id !== id);
      }),
    notify,
    save: (draft, existingId) => {
      const trader = TRADERS[draft.traderId] ?? TRADERS.kaito;
      if (existingId) {
        setConfigs((prev) => prev.map((c) => (c.id === existingId ? { ...c, ...draft } : c)));
      } else {
        const next: CopyConfig = {
          ...draft,
          id: `c${Date.now()}`,
          paused: false,
          spent: 0,
          pnl: 0,
          trades: 0,
          since: "Today",
        };
        setConfigs((prev) => [next, ...prev]);
        setLog((l) => [
          {
            id: Date.now(),
            kind: "entry",
            title: "Copy engine armed",
            detail: `$${draft.allocation} per ${trader.name} entry · TP +${draft.takeProfit}% · SL -${draft.stopLoss}% · trail ${draft.trailingStop}%.`,
            time: "just now",
            traderId: draft.traderId,
          },
          ...l,
        ]);
      }
      setEditing(null);
      notify(
        existingId
          ? `Risk settings saved for ${trader.name}.`
          : `Now copying ${trader.name}. First entry executes at your $${draft.allocation} allocation.`
      );
    },
  };

  return (
    <CopyContext.Provider value={value}>
      {children}
      {editing && <CopyModal />}
      {toast && (
        <div
          role="status"
          aria-live="polite"
          className="fixed bottom-24 right-4 z-[90] flex max-w-[340px] items-start gap-2.5 rounded-2xl bg-ink px-4 py-3.5 text-[12px] font-semibold leading-snug text-white shadow-[0_24px_50px_-20px_rgba(12,16,28,0.6)] md:bottom-8 md:right-8"
        >
          <span className="mt-0.5 flex h-4 w-4 shrink-0 items-center justify-center rounded-full bg-gain">
            <svg viewBox="0 0 12 12" className="h-2.5 w-2.5 text-ink" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="m2.5 6 2.4 2.4L9.5 3.6" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </span>
          {toast}
        </div>
      )}
    </CopyContext.Provider>
  );
}

/* ================= copy buttons ================= */

export function CopyButton({
  traderId,
  className,
  label = "Copy",
  existing,
}: {
  traderId: string;
  className?: string;
  label?: string;
  existing?: CopyConfig;
}) {
  const { openCopy, isCopying } = useCopy();
  const active = existing ? !existing.paused : isCopying(traderId);
  return (
    <button
      type="button"
      onClick={(e) => {
        e.stopPropagation();
        openCopy(traderId, existing);
      }}
      className={cn(
        "inline-flex shrink-0 items-center justify-center gap-1.5 rounded-full px-3.5 py-1.5 text-[10px] font-extrabold transition-all active:scale-95",
        active
          ? "bg-gain/15 text-[#0b6b3a] hover:bg-gain/25"
          : "bg-ink text-white shadow-sm hover:bg-neutral-700",
        className
      )}
      aria-label={`Copy ${TRADERS[traderId]?.name ?? traderId}`}
    >
      <IcCopy className="h-3 w-3" />
      {active ? "Copying" : label}
    </button>
  );
}

/* ================= modal ================= */

const inputCls =
  "w-full rounded-xl border border-neutral-200 bg-paper/60 px-3 py-2.5 text-[14px] font-extrabold outline-none transition-colors focus:border-ink";

function NumField({
  label,
  hint,
  value,
  onChange,
  prefix,
  suffix,
  min = 1,
  max,
}: {
  label: string;
  hint?: string;
  value: number;
  onChange: (v: number) => void;
  prefix?: string;
  suffix?: string;
  min?: number;
  max?: number;
}) {
  return (
    <label className="block">
      <span className="text-[10px] font-extrabold uppercase tracking-[0.12em] text-neutral-400">{label}</span>
      <span className="relative mt-1.5 flex items-center">
        {prefix && <span className="absolute left-3 text-[13px] font-extrabold text-neutral-400">{prefix}</span>}
        <input
          type="number"
          value={value}
          min={min}
          max={max}
          onChange={(e) => onChange(Number(e.target.value))}
          className={cn(inputCls, prefix && "pl-7", suffix && "pr-8")}
        />
        {suffix && <span className="absolute right-3 text-[13px] font-extrabold text-neutral-400">{suffix}</span>}
      </span>
      {hint && <span className="mt-1 block text-[10px] font-medium text-neutral-400">{hint}</span>}
    </label>
  );
}

function Presets({ values, onPick, fmt }: { values: number[]; onPick: (v: number) => void; fmt: (v: number) => string }) {
  return (
    <div className="mt-2 flex flex-wrap gap-1.5">
      {values.map((v) => (
        <button
          key={v}
          type="button"
          onClick={() => onPick(v)}
          className="rounded-full border border-neutral-200 bg-white px-2.5 py-1 text-[10px] font-bold text-neutral-500 transition-colors hover:border-ink hover:text-ink"
        >
          {fmt(v)}
        </button>
      ))}
    </div>
  );
}

function Toggle({
  on,
  onChange,
  title,
  desc,
  locked,
}: {
  on: boolean;
  onChange?: () => void;
  title: string;
  desc: string;
  locked?: boolean;
}) {
  return (
    <div className="flex items-start gap-3 py-3">
      <div className="min-w-0 flex-1">
        <div className="flex flex-wrap items-center gap-2">
          <span className="text-[12px] font-extrabold">{title}</span>
          {locked && (
            <span className="rounded-md bg-gain/15 px-1.5 py-0.5 text-[9px] font-extrabold text-[#0b6b3a]">
              Always on
            </span>
          )}
        </div>
        <p className="mt-0.5 text-[11px] font-medium leading-relaxed text-neutral-500">{desc}</p>
      </div>
      <button
        type="button"
        role="switch"
        aria-checked={on}
        aria-label={title}
        onClick={onChange}
        disabled={locked}
        className={cn(
          "relative mt-0.5 h-5 w-9 shrink-0 rounded-full transition-colors",
          on ? "bg-gain" : "bg-neutral-200",
          locked && "cursor-default opacity-90"
        )}
      >
        <span
          className={cn(
            "absolute top-0.5 h-4 w-4 rounded-full bg-white shadow transition-transform",
            on ? "translate-x-[18px]" : "translate-x-0.5"
          )}
        />
      </button>
    </div>
  );
}

function CopyModal() {
  const { editing, closeCopy, save, configs } = useCopy();
  const traderId = editing?.traderId ?? "kaito";
  const t = TRADERS[traderId] ?? TRADERS.kaito;
  const rank = rankedById(traderId);
  const existing = editing?.existing ?? configs.find((c) => c.traderId === traderId);

  const [allocation, setAllocation] = useState(existing?.allocation ?? 100);
  const [cap, setCap] = useState(existing?.maxInvestment ?? 100);
  const [tp, setTp] = useState(existing?.takeProfit ?? 100);
  const [sl, setSl] = useState(existing?.stopLoss ?? 20);
  const [trail, setTrail] = useState(existing?.trailingStop ?? 15);
  const [copyEntries, setCopyEntries] = useState(existing?.copyNewEntries ?? true);
  const [mirror, setMirror] = useState(existing?.mirrorExits ?? false);

  const safeAlloc = Number.isFinite(allocation) ? Math.max(1, allocation) : 100;
  const safeCap = Number.isFinite(cap) ? Math.max(safeAlloc, cap) : 100;
  const tpPrice = Math.round(100 * (1 + (tp || 0) / 100));
  const slPrice = Math.round(100 * (1 - (sl || 0) / 100));

  return (
    <div
      className="fixed inset-0 z-[80] flex items-end justify-center bg-ink/50 p-0 backdrop-blur-sm sm:items-center sm:p-6"
      onClick={closeCopy}
    >
      <div
        role="dialog"
        aria-modal="true"
        aria-label="Copy trading settings"
        onClick={(e) => e.stopPropagation()}
        className="max-h-[92vh] w-full max-w-[620px] overflow-y-auto rounded-t-3xl border border-neutral-200 bg-white shadow-[0_40px_80px_-30px_rgba(12,16,28,0.5)] sm:rounded-3xl"
      >
        {/* header */}
        <div className="sticky top-0 z-10 flex items-start gap-3 border-b border-neutral-100 bg-white/95 px-5 py-4 backdrop-blur md:px-6">
          <Avatar src={t.img} name={t.name} size={44} />
          <div className="min-w-0 flex-1">
            <div className="flex flex-wrap items-center gap-1.5">
              <span className="text-[15px] font-extrabold">{existing ? "Edit copy settings" : "Copy trader"}</span>
              <span className="text-[13px] font-bold text-neutral-400">· {t.name}</span>
              <Verified className="h-3.5 w-3.5" />
            </div>
            <div className="mt-1 flex flex-wrap items-center gap-1.5">
              {rank && <SourceBadge source={rank.source} />}
              {rank && (
                <>
                  <span className="text-[10px] font-bold text-gain">{fmtPct(rank.p["90D"])} 90D</span>
                  <span className="text-[10px] font-medium text-neutral-400">· {rank.win} win rate</span>
                </>
              )}
            </div>
          </div>
          <button
            type="button"
            onClick={closeCopy}
            className="flex h-8 w-8 items-center justify-center rounded-full bg-neutral-100 text-neutral-500 transition-colors hover:bg-neutral-200 hover:text-ink"
            aria-label="Close"
          >
            <IcClose className="h-4 w-4" />
          </button>
        </div>

        <div className="px-5 py-4 md:px-6">
          {/* allocation */}
          <div className="flex items-center gap-2">
            <span className="flex h-5 w-5 items-center justify-center rounded-full bg-ink text-[10px] font-extrabold text-white">
              1
            </span>
            <h3 className="text-[13px] font-extrabold">Your allocation</h3>
          </div>
          <div className="mt-3 grid gap-3 sm:grid-cols-2">
            <NumField label="Per trade" prefix="$" value={allocation} onChange={setAllocation} hint="Executed automatically on every new entry." />
            <NumField label="Maximum investment" prefix="$" value={cap} onChange={setCap} hint="Hard cap across this trader’s open copies." />
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            <Presets values={[25, 50, 100, 250]} onPick={setAllocation} fmt={(v) => `$${v}`} />
            <Presets values={[100, 250, 500, 1000]} onPick={setCap} fmt={(v) => `$${v} cap`} />
          </div>

          {/* exits */}
          <div className="mt-6 flex items-center gap-2">
            <span className="flex h-5 w-5 items-center justify-center rounded-full bg-ink text-[10px] font-extrabold text-white">
              2
            </span>
            <h3 className="text-[13px] font-extrabold">Your exit rules</h3>
            <span className="ml-auto rounded-md bg-neutral-100 px-1.5 py-0.5 text-[9px] font-extrabold text-neutral-500">
              Independent
            </span>
          </div>
          <div className="mt-3 grid gap-3 sm:grid-cols-3">
            <NumField label="Take profit" suffix="%" value={tp} onChange={setTp} />
            <NumField label="Stop loss" suffix="%" value={sl} onChange={setSl} />
            <NumField label="Trailing stop" suffix="%" value={trail} onChange={setTrail} />
          </div>
          <div className="grid gap-3 sm:grid-cols-3">
            <Presets values={[50, 100, 200]} onPick={setTp} fmt={(v) => `+${v}%`} />
            <Presets values={[10, 20, 30]} onPick={setSl} fmt={(v) => `-${v}%`} />
            <Presets values={[10, 15, 25]} onPick={setTrail} fmt={(v) => `${v}%`} />
          </div>
          <p className="mt-2 flex items-start gap-1.5 text-[10px] font-medium leading-relaxed text-neutral-400">
            <IcBolt className="mt-px h-3 w-3 shrink-0 text-gain" />
            Trailing stop exits after price pulls back that far from its high — without the trader needing to sell.
          </p>

          {/* toggles */}
          <div className="mt-6 flex items-center gap-2">
            <span className="flex h-5 w-5 items-center justify-center rounded-full bg-ink text-[10px] font-extrabold text-white">
              3
            </span>
            <h3 className="text-[13px] font-extrabold">Execution rules</h3>
          </div>
          <div className="mt-1 divide-y divide-neutral-100">
            <Toggle
              on={copyEntries}
              onChange={() => setCopyEntries((v) => !v)}
              title="Copy new entries"
              desc="Buy automatically when this trader opens a new position, at your per-trade size."
            />
            <Toggle
              on={mirror}
              onChange={() => setMirror((v) => !v)}
              title="Mirror their exits"
              desc="Also close when the trader closes. Off by default so your TP/SL/trail fully control the exit."
            />
            <Toggle
              on
              locked
              title="Independent exits"
              desc="Tape always runs your TP, SL and trailing stop, whether or not the original trader is still holding."
            />
          </div>

          {/* preview */}
          <div className="mt-5 overflow-hidden rounded-2xl bg-ink p-4 text-white">
            <div className="text-[9px] font-extrabold uppercase tracking-[0.16em] text-gain">If they buy at $100K mcap</div>
            <div className="mt-1.5 font-display text-[16px] font-extrabold leading-snug">
              Tape buys ${safeAlloc} for you.
            </div>
            <div className="mt-3 grid grid-cols-3 gap-2">
              <div className="rounded-xl bg-white/[0.07] p-2.5">
                <div className="text-[8.5px] font-bold uppercase tracking-wider text-gain">TP +{tp || 0}%</div>
                <div className="mt-0.5 text-[12px] font-extrabold">${tpPrice}K mcap</div>
              </div>
              <div className="rounded-xl bg-white/[0.07] p-2.5">
                <div className="text-[8.5px] font-bold uppercase tracking-wider text-rose-300">SL -{sl || 0}%</div>
                <div className="mt-0.5 text-[12px] font-extrabold">${slPrice}K mcap</div>
              </div>
              <div className="rounded-xl bg-white/[0.07] p-2.5">
                <div className="text-[8.5px] font-bold uppercase tracking-wider text-white/60">Trail</div>
                <div className="mt-0.5 text-[12px] font-extrabold">{trail || 0}% off high</div>
              </div>
            </div>
            <div className="mt-2.5 flex items-center gap-1.5 text-[10px] font-semibold text-white/50">
              <IcShield className="h-3.5 w-3.5 shrink-0 text-gain" />
              Max exposure ${safeCap}. Exits execute even if {t.name} keeps holding.
            </div>
          </div>
        </div>

        {/* footer */}
        <div className="sticky bottom-0 flex items-center gap-2 border-t border-neutral-100 bg-white/95 px-5 py-3.5 backdrop-blur md:px-6">
          <button
            type="button"
            onClick={closeCopy}
            className="rounded-full border border-neutral-200 bg-white px-4 py-2.5 text-[12px] font-extrabold text-neutral-500 transition-colors hover:border-neutral-400 hover:text-ink"
          >
            Cancel
          </button>
          <button
            type="button"
            onClick={() =>
              save(
                {
                  traderId,
                  allocation: safeAlloc,
                  maxInvestment: safeCap,
                  takeProfit: Math.max(1, tp || 1),
                  stopLoss: Math.max(1, sl || 1),
                  trailingStop: Math.min(90, Math.max(0, trail || 0)),
                  independentExits: true,
                  copyNewEntries: copyEntries,
                  mirrorExits: mirror,
                },
                existing?.id
              )
            }
            className="flex flex-1 items-center justify-center gap-1.5 rounded-full bg-ink py-2.5 text-[12px] font-extrabold text-white transition-all hover:bg-neutral-700 active:scale-[0.98]"
          >
            <IcCopy className="h-3.5 w-3.5" />
            {existing ? "Save risk settings" : "Start copying"}
          </button>
        </div>
      </div>
    </div>
  );
}

/* ================= leaderboard (7D / 30D / 90D + sources) ================= */

export function RankedBoard({
  compact = false,
  onOpenTrader,
  rows: externalRows,
  live = false,
}: {
  compact?: boolean;
  onOpenTrader?: (id: string) => void;
  /** Normalized rows from the market data layer. Falls back to bundled demo data. */
  rows?: Ranked[];
  live?: boolean;
}) {
  const [period, setPeriod] = useState<Period>("90D");
  const [source, setSource] = useState<"All" | Source>("All");
  const rows = useMemo(
    () =>
      [...(externalRows ?? RANKED)]
        .filter((r) => source === "All" || r.source === source)
        .sort((a, b) => b.p[period] - a.p[period])
        .slice(0, compact ? 5 : 7),
    [period, source, compact, externalRows]
  );

  return (
    <div className="rounded-3xl border border-neutral-200 bg-white p-5 md:p-6">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h2 className="text-[15px] font-extrabold tracking-tight">Cross-platform leaderboard</h2>
          <p className="mt-0.5 text-[11px] font-medium text-neutral-400">
            Tape · Pump.fun · on-chain wallets (SOL, BSC, ETH) — aggregated and ranked.
          </p>
        </div>
        <div className="flex rounded-full bg-paper p-0.5">
          {(["7D", "30D", "90D"] as Period[]).map((p) => (
            <button
              key={p}
              type="button"
              onClick={() => setPeriod(p)}
              className={cn(
                "rounded-full px-3 py-1.5 text-[10px] font-extrabold transition-all",
                period === p ? "bg-ink text-white shadow-sm" : "text-neutral-500 hover:text-ink"
              )}
            >
              {p}
            </button>
          ))}
        </div>
      </div>

      <div className="mt-3 flex flex-wrap items-center gap-1.5">
        {(["All", "Tape", "Pump.fun", "On-chain"] as const).map((s) => (
          <button
            key={s}
            type="button"
            onClick={() => setSource(s)}
            className={cn(
              "rounded-full border px-2.5 py-1 text-[10px] font-bold transition-colors",
              source === s
                ? "border-ink bg-ink text-white"
                : "border-neutral-200 bg-white text-neutral-500 hover:border-neutral-400 hover:text-ink"
            )}
          >
            {s}
          </button>
        ))}
        <span className="ml-auto hidden items-center gap-1.5 text-[10px] font-bold text-neutral-400 sm:flex">
          <span className="relative flex h-1.5 w-1.5">
            <span className={cn("ping-ring absolute h-full w-full rounded-full", live ? "bg-gain" : "bg-amber-400")} />
            <span className={cn("relative h-1.5 w-1.5 rounded-full", live ? "bg-gain" : "bg-amber-400")} />
          </span>
          {live ? "Live PnL" : "Demo feed"}
        </span>
      </div>

      <div className="mt-3 flex flex-col divide-y divide-neutral-100">
        {rows.map((r, i) => (
          <div key={r.id} className="flex items-center gap-2.5 py-3">
            <span
              className={cn(
                "w-5 shrink-0 text-center font-display text-[13px] font-black",
                i === 0 ? "text-ink" : "text-neutral-300"
              )}
            >
              {i + 1}
            </span>
            <button type="button" onClick={() => onOpenTrader?.(r.id)} className="shrink-0">
              <Avatar src={r.img} name={r.name} size={36} />
            </button>
            <button
              type="button"
              onClick={() => onOpenTrader?.(r.id)}
              className="min-w-0 flex-1 text-left"
            >
              <div className="flex items-center gap-1">
                <span className="truncate text-[12px] font-extrabold leading-tight">{r.name}</span>
                <Verified className="h-3 w-3 shrink-0" />
              </div>
              <div className="mt-0.5 flex flex-wrap items-center gap-1">
                <SourceBadge source={r.source} />
                <span className="text-[9px] font-semibold text-neutral-400">{r.chain}</span>
              </div>
            </button>
            <div className="hidden text-right sm:block">
              <div className="text-[12px] font-extrabold leading-tight">{r.win}</div>
              <div className="text-[9px] font-medium text-neutral-400">win rate</div>
            </div>
            <div className="w-[70px] text-right">
              <div className="text-[13px] font-extrabold leading-tight text-gain">{fmtPct(r.p[period])}</div>
              <div className="text-[9px] font-medium text-neutral-400">{period}</div>
            </div>
            <FollowButton className="hidden px-3 py-1.5 text-[10px] md:block" />
            <CopyButton traderId={r.id} className="px-3 py-1.5" />
          </div>
        ))}
      </div>
      <p className="mt-2 text-[10px] font-medium text-neutral-400">
        Follow to watch theses and alerts. Copy to auto-execute with your own allocation, TP, SL and trailing stop.
      </p>
    </div>
  );
}

/* ================= copies page ================= */

const LOG_META: Record<LogKind, { label: string; cls: string; Icon: (p: { className?: string }) => ReactNode }> = {
  entry: { label: "Entry", cls: "bg-gain/10 text-gain", Icon: (p) => <IcTrendUp {...p} /> },
  "take-profit": { label: "Take profit", cls: "bg-gain/15 text-[#0b6b3a]", Icon: (p) => <IcTrendUp {...p} /> },
  "stop-loss": { label: "Stop loss", cls: "bg-loss/10 text-loss", Icon: (p) => <IcTrendDown {...p} /> },
  trailing: { label: "Trailing", cls: "bg-sky-100 text-sky-700", Icon: (p) => <IcBolt {...p} /> },
  skip: { label: "Skipped", cls: "bg-neutral-100 text-neutral-500", Icon: (p) => <IcShield {...p} /> },
};

export function CopiesPage({ onDiscover }: { onDiscover: () => void }) {
  const { configs, log, notify, togglePause, stop } = useCopy();
  const [tab, setTab] = useState("Active copies");

  const active = configs.filter((c) => !c.paused);
  const deployed = configs.reduce((s, c) => s + c.spent, 0);
  const pnl = configs.reduce((s, c) => s + c.pnl, 0);
  const autonomous = log.filter((l) => l.independent).length;

  return (
    <div className="fadeup flex flex-col gap-5">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="font-display text-[28px] font-extrabold tracking-tight">Copy trading</h1>
          <p className="mt-1 max-w-xl text-[12px] font-medium leading-relaxed text-neutral-500">
            Copy the trader, own the exit. Tape executes their entries at your allocation and closes on your TP, SL or
            trailing stop — even while they&rsquo;re still holding.
          </p>
        </div>
        <button
          type="button"
          onClick={onDiscover}
          className="inline-flex items-center gap-1.5 rounded-full bg-ink px-4 py-2.5 text-[12px] font-extrabold text-white transition-all hover:bg-neutral-700 active:scale-95"
        >
          <IcSliders className="h-3.5 w-3.5" /> Find traders to copy
        </button>
      </div>

      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">
        {[
          { l: "Active copies", v: String(active.length), s: "engine armed" },
          { l: "Deployed", v: `$${deployed.toLocaleString()}`, s: "across strategies" },
          { l: "Auto PnL", v: `${pnl >= 0 ? "+" : "-"}$${Math.abs(pnl).toFixed(2)}`, s: "realized + open", g: pnl >= 0 },
          { l: "Autonomous exits", v: String(autonomous), s: "trader still holding" },
        ].map((s) => (
          <div key={s.l} className="rounded-2xl border border-neutral-200 bg-white p-4">
            <div className="text-[9px] font-extrabold uppercase tracking-[0.14em] text-neutral-400">{s.l}</div>
            <div className={cn("mt-1 font-display text-[22px] font-extrabold tracking-tight", s.g && "text-gain")}>
              {s.v}
            </div>
            <div className="text-[10px] font-medium text-neutral-400">{s.s}</div>
          </div>
        ))}
      </div>

      <div className="rounded-2xl border border-neutral-200 bg-white p-4">
        <div className="flex flex-wrap items-center gap-2">
          <IcShield className="h-4 w-4 text-gain" />
          <span className="text-[12px] font-extrabold">Your risk parameters run every position.</span>
          <span className="text-[11px] font-medium text-neutral-500">
            The original trader can hold forever — your exits are yours.
          </span>
        </div>
        <div className="mt-3 flex flex-wrap gap-1.5">
          {["Allocation per trade", "Max investment", "Take profit", "Stop loss", "Trailing stop", "Independent exits"].map(
            (x) => (
              <span
                key={x}
                className="rounded-full border border-neutral-200 bg-paper px-2.5 py-1 text-[10px] font-bold text-neutral-500"
              >
                {x}
              </span>
            )
          )}
        </div>
      </div>

      <TabPills
        tabs={["Active copies", "Execution log", "Sources"]}
        active={tab}
        onChange={setTab}
        className="justify-start"
      />

      {tab === "Active copies" && (
        <div className="grid gap-4 xl:grid-cols-2">
          {configs.length === 0 && (
            <div className="rounded-3xl border border-dashed border-neutral-300 bg-white p-10 text-center xl:col-span-2">
              <p className="text-[13px] font-extrabold">No copy strategies armed yet.</p>
              <p className="mt-1 text-[12px] font-medium text-neutral-500">
                Pick any trader from the leaderboard and set your allocation and exits.
              </p>
              <button
                type="button"
                onClick={onDiscover}
                className="mt-4 rounded-full bg-ink px-4 py-2.5 text-[12px] font-extrabold text-white"
              >
                Browse top traders
              </button>
            </div>
          )}
          {configs.map((c) => {
            const tr = TRADERS[c.traderId] ?? TRADERS.kaito;
            const rank = rankedById(c.traderId);
            return (
              <div key={c.id} className="rounded-3xl border border-neutral-200 bg-white p-5">
                <div className="flex items-center gap-2.5">
                  <Avatar src={tr.img} name={tr.name} size={40} />
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-1.5">
                      <span className="text-[13px] font-extrabold">{tr.name}</span>
                      <Verified className="h-3.5 w-3.5" />
                      {rank && <SourceBadge source={rank.source} />}
                    </div>
                    <div className="text-[10px] font-medium text-neutral-400">
                      Copying since {c.since} · {c.trades} trades
                    </div>
                  </div>
                  <label className="flex shrink-0 cursor-pointer items-center gap-1.5">
                    <input
                      type="checkbox"
                      checked={!c.paused}
                      onChange={() => toggle(c.id)}
                      className="peer sr-only"
                      aria-label={c.paused ? `Resume ${tr.name}` : `Pause ${tr.name}`}
                    />
                    <span className="relative h-5 w-9 rounded-full bg-neutral-200 transition-colors peer-checked:bg-gain">
                      <span
                        className={cn(
                          "absolute top-0.5 h-4 w-4 rounded-full bg-white shadow transition-transform",
                          c.paused ? "translate-x-0.5" : "translate-x-[18px]"
                        )}
                      />
                    </span>
                    <span className="text-[9px] font-extrabold uppercase tracking-wider text-neutral-400">
                      {c.paused ? "Paused" : "Live"}
                    </span>
                  </label>
                </div>

                <div className="mt-3 grid grid-cols-2 gap-x-3 gap-y-2 rounded-2xl bg-paper p-3 sm:grid-cols-4">
                  {[
                    { l: "Allocation", v: `$${c.allocation}` },
                    { l: "Max", v: `$${c.maxInvestment}` },
                    { l: "Take profit", v: `+${c.takeProfit}%`, g: true },
                    { l: "Stop loss", v: `-${c.stopLoss}%`, r: true },
                  ].map((x) => (
                    <div key={x.l}>
                      <div className="text-[8.5px] font-bold uppercase tracking-wider text-neutral-400">{x.l}</div>
                      <div
                        className={cn(
                          "text-[12px] font-extrabold",
                          x.g && "text-gain",
                          x.r && "text-loss"
                        )}
                      >
                        {x.v}
                      </div>
                    </div>
                  ))}
                </div>
                <div className="mt-2 flex flex-wrap items-center gap-2 text-[10px] font-bold text-neutral-500">
                  <span className="rounded-md bg-sky-100 px-1.5 py-0.5 text-sky-700">Trail {c.trailingStop}%</span>
                  <span className="rounded-md bg-gain/10 px-1.5 py-0.5 text-[#0b6b3a]">Independent exits on</span>
                  {c.mirrorExits && <span className="rounded-md bg-neutral-100 px-1.5 py-0.5">Mirrors exits</span>}
                </div>

                <div className="mt-3">
                  <div className="flex items-center justify-between text-[10px] font-bold text-neutral-400">
                    <span>
                      ${c.spent} of ${c.maxInvestment} deployed
                    </span>
                    <span className={cn("font-extrabold", c.pnl >= 0 ? "text-gain" : "text-loss")}>
                      {c.pnl >= 0 ? "+" : "-"}${Math.abs(c.pnl).toFixed(2)}
                    </span>
                  </div>
                  <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-neutral-100">
                    <span
                      className="block h-full rounded-full bg-gain"
                      style={{ width: `${Math.min(100, (c.spent / Math.max(1, c.maxInvestment)) * 100)}%` }}
                    />
                  </div>
                </div>

                <div className="mt-4 flex items-center gap-2">
                  <CopyButton
                    traderId={c.traderId}
                    existing={c}
                    label="Edit risk"
                    className="!bg-ink px-4 py-2 !text-white hover:!bg-neutral-700"
                  />
                  <button
                    type="button"
                    onClick={() => stop(c.id)}
                    className="rounded-full border border-neutral-200 px-3.5 py-2 text-[10px] font-extrabold text-neutral-500 transition-colors hover:border-loss hover:text-loss"
                  >
                    Stop copying
                  </button>
                  <span className="ml-auto text-[10px] font-semibold text-neutral-400">{c.paused ? "Engine paused" : "Engine live"}</span>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {tab === "Execution log" && (
        <div className="rounded-3xl border border-neutral-200 bg-white p-5 md:p-6">
          <div className="flex items-center justify-between">
            <h2 className="text-[15px] font-extrabold">What Tape did for you</h2>
            <span className="rounded-full bg-gain/10 px-2 py-0.5 text-[9px] font-extrabold text-[#0b6b3a]">
              Auto-executed
            </span>
          </div>
          <div className="mt-3 flex flex-col">
            {log.map((l) => {
              const meta = LOG_META[l.kind];
              const tr = TRADERS[l.traderId] ?? TRADERS.kaito;
              return (
                <div key={l.id} className="flex gap-3 border-b border-neutral-100 py-3 last:border-0">
                  <span className={cn("mt-0.5 flex h-8 w-8 shrink-0 items-center justify-center rounded-full", meta.cls)}>
                    <meta.Icon className="h-4 w-4" />
                  </span>
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-1.5">
                      <span className="text-[12px] font-extrabold">{l.title}</span>
                      {l.independent && (
                        <span className="rounded-md bg-sky-100 px-1.5 py-0.5 text-[9px] font-extrabold text-sky-700">
                          Independent exit
                        </span>
                      )}
                      {l.traderHolding && (
                        <span className="rounded-md bg-neutral-100 px-1.5 py-0.5 text-[9px] font-bold text-neutral-500">
                          trader still holding
                        </span>
                      )}
                    </div>
                    <p className="mt-0.5 text-[11px] font-medium leading-snug text-neutral-500">{l.detail}</p>
                    <div className="mt-1 flex items-center gap-1.5 text-[9px] font-bold text-neutral-400">
                      <Avatar src={tr.img} name={tr.name} size={14} /> {tr.name} · {l.time}
                    </div>
                  </div>
                  <span className="hidden text-[9px] font-extrabold uppercase tracking-wider text-neutral-300 sm:block">
                    {meta.label}
                  </span>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {tab === "Sources" && (
        <div className="grid gap-4 md:grid-cols-3">
          {[
            {
              s: "Tape" as Source,
              d: "Native Tape traders — every fill, thesis and alert published to the social feed in real time.",
              n: "3 ranked traders",
            },
            {
              s: "Pump.fun" as Source,
              d: "Early memecoin wallets, ranked on realized PnL with token mcap context on every entry.",
              n: "1,240 tracked wallets",
            },
            {
              s: "On-chain" as Source,
              d: "Smart-money wallets across Solana, BSC, Ethereum and Base. No account needed — we index the chain.",
              n: "38,700 indexed wallets",
            },
          ].map((s) => (
            <div key={s.s} className="rounded-3xl border border-neutral-200 bg-white p-5">
              <SourceBadge source={s.s} className="px-2 py-1 text-[10px]" />
              <div className="mt-3 text-[12px] font-medium leading-relaxed text-neutral-500">{s.d}</div>
              <div className="mt-3 text-[10px] font-extrabold uppercase tracking-wider text-neutral-400">{s.n}</div>
            </div>
          ))}
          <div className="rounded-3xl border border-neutral-200 bg-ink p-5 text-white md:col-span-3">
            <div className="text-[9px] font-extrabold uppercase tracking-[0.16em] text-gain">One feed, every venue</div>
            <p className="mt-1.5 max-w-2xl text-[12px] font-medium leading-relaxed text-white/70">
              Tape aggregates and ranks performance across Tape, Pump.fun and raw on-chain wallets over 7, 30 and 90
              days. Follow to watch, Copy to execute — or ignore both and trade independently from the same wallet.
            </p>
          </div>
        </div>
      )}
    </div>
  );

  function toggle(id: string) {
    const cfg = configs.find((x) => x.id === id);
    if (!cfg) return;
    togglePause(id);
    notify(`${TRADERS[cfg.traderId]?.name ?? "Trader"} copy ${cfg.paused ? "resumed" : "paused"}.`);
  }
}
