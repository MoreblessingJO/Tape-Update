import React from "react";

type P = { className?: string; style?: React.CSSProperties };

const base = (p: P) => ({
  className: p.className,
  style: p.style,
  fill: "none",
  stroke: "currentColor",
  strokeWidth: 1.8,
  strokeLinecap: "round" as const,
  strokeLinejoin: "round" as const,
  viewBox: "0 0 24 24",
});

export const IcBell = (p: P) => (
  <svg {...base(p)}>
    <path d="M18 8a6 6 0 1 0-12 0c0 7-3 8-3 8h18s-3-1-3-8" />
    <path d="M13.7 21a2 2 0 0 1-3.4 0" />
  </svg>
);
export const IcEye = (p: P) => (
  <svg {...base(p)}>
    <path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7-10-7-10-7Z" />
    <circle cx="12" cy="12" r="3" />
  </svg>
);
export const IcPlus = (p: P) => (
  <svg {...base(p)}>
    <path d="M12 5v14M5 12h14" />
  </svg>
);
export const IcSearch = (p: P) => (
  <svg {...base(p)}>
    <circle cx="11" cy="11" r="7" />
    <path d="m20 20-3.5-3.5" />
  </svg>
);
export const IcBack = (p: P) => (
  <svg {...base(p)}>
    <path d="m14 6-6 6 6 6" />
  </svg>
);
export const IcMore = (p: P) => (
  <svg {...base(p)}>
    <circle cx="5" cy="12" r="1.4" fill="currentColor" stroke="none" />
    <circle cx="12" cy="12" r="1.4" fill="currentColor" stroke="none" />
    <circle cx="19" cy="12" r="1.4" fill="currentColor" stroke="none" />
  </svg>
);
export const IcShare = (p: P) => (
  <svg {...base(p)}>
    <path d="M12 3v12M8 7l4-4 4 4" />
    <path d="M5 12v7a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-7" />
  </svg>
);
export const IcHeart = (p: P) => (
  <svg {...base(p)}>
    <path d="M19 14c1.5-1.5 2.5-3.2 2.5-5A4.5 4.5 0 0 0 12 5.5 4.5 4.5 0 0 0 2.5 9c0 1.8 1 3.5 2.5 5l7 6.5Z" />
  </svg>
);
export const IcChat = (p: P) => (
  <svg {...base(p)}>
    <path d="M21 12a8 8 0 0 1-8 8H4l2-3a8 8 0 1 1 15-5Z" />
  </svg>
);
export const IcRep = (p: P) => (
  <svg {...base(p)}>
    <path d="M17 2l4 4-4 4" />
    <path d="M3 11V9a4 4 0 0 1 4-4h14" />
    <path d="M7 22l-4-4 4-4" />
    <path d="M21 13v2a4 4 0 0 1-4 4H3" />
  </svg>
);
export const IcBookmark = (p: P) => (
  <svg {...base(p)}>
    <path d="M6 4a2 2 0 0 1 2-2h8a2 2 0 0 1 2 2v18l-6-4-6 4Z" />
  </svg>
);
export const IcGear = (p: P) => (
  <svg {...base(p)}>
    <circle cx="12" cy="12" r="3" />
    <path d="M19.4 15a1.7 1.7 0 0 0 .34 1.87l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.7 1.7 0 0 0-1.87-.34 1.7 1.7 0 0 0-1 1.55V21a2 2 0 1 1-4 0v-.09a1.7 1.7 0 0 0-1-1.55 1.7 1.7 0 0 0-1.87.34l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.7 1.7 0 0 0 .34-1.87 1.7 1.7 0 0 0-1.55-1H3a2 2 0 1 1 0-4h.09a1.7 1.7 0 0 0 1.55-1 1.7 1.7 0 0 0-.34-1.87l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.7 1.7 0 0 0 1.87.34h.01a1.7 1.7 0 0 0 1-1.55V3a2 2 0 1 1 4 0v.09a1.7 1.7 0 0 0 1 1.55 1.7 1.7 0 0 0 1.87-.34l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.7 1.7 0 0 0-.34 1.87v.01a1.7 1.7 0 0 0 1.55 1H21a2 2 0 1 1 0 4h-.09a1.7 1.7 0 0 0-1.55 1Z" />
  </svg>
);
export const IcHome = (p: P) => (
  <svg {...base(p)}>
    <path d="M3 10.5 12 3l9 7.5" />
    <path d="M5 9.5V21h14V9.5" />
    <path d="M10 21v-6h4v6" />
  </svg>
);
export const IcPulse = (p: P) => (
  <svg {...base(p)}>
    <path d="M2 12h4l3-8 4 16 3-8h6" />
  </svg>
);
export const IcWallet = (p: P) => (
  <svg {...base(p)}>
    <rect x="3" y="6" width="18" height="14" rx="3" />
    <path d="M3 10h18" />
    <circle cx="17" cy="15" r="1.2" fill="currentColor" stroke="none" />
  </svg>
);
export const IcUser = (p: P) => (
  <svg {...base(p)}>
    <circle cx="12" cy="8" r="4" />
    <path d="M4 21c1.5-4 4.5-6 8-6s6.5 2 8 6" />
  </svg>
);
export const IcUserPlus = (p: P) => (
  <svg {...base(p)}>
    <circle cx="10" cy="8" r="4" />
    <path d="M3 21c1.3-3.6 3.9-5.5 7-5.5s5.7 1.9 7 5.5" />
    <path d="M19 6v6M16 9h6" />
  </svg>
);
export const IcChevR = (p: P) => (
  <svg {...base(p)}>
    <path d="m9 6 6 6-6 6" />
  </svg>
);
export const IcDoc = (p: P) => (
  <svg {...base(p)}>
    <path d="M6 2h8l5 5v13a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2Z" />
    <path d="M14 2v5h5M9 13h7M9 17h7M9 9h2" />
  </svg>
);
export const IcTrendUp = (p: P) => (
  <svg {...base(p)}>
    <path d="M3 17l6-6 4 4 8-8" />
    <path d="M15 7h6v6" />
  </svg>
);
export const IcTrendDown = (p: P) => (
  <svg {...base(p)}>
    <path d="M3 7l6 6 4-4 8 8" />
    <path d="M15 17h6v-6" />
  </svg>
);
export const IcBolt = (p: P) => (
  <svg {...base(p)}>
    <path d="M13 2 4 14h6l-1 8 9-12h-6l1-8Z" />
  </svg>
);
export const IcCopy = (p: P) => (
  <svg {...base(p)}>
    <rect x="9" y="9" width="12" height="12" rx="2" />
    <path d="M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1" />
  </svg>
);
export const IcShield = (p: P) => (
  <svg {...base(p)}>
    <path d="M12 2 4 5.5V11c0 5 3.4 9.3 8 11 4.6-1.7 8-6 8-11V5.5Z" />
    <path d="m9 11.5 2.2 2.2L15.5 9" />
  </svg>
);
export const IcApple = (p: P) => (
  <svg viewBox="0 0 24 24" className={p.className} style={p.style} fill="currentColor">
    <path d="M16.6 12.9c0-2.4 2-3.6 2.1-3.7-1.1-1.7-2.9-1.9-3.5-1.9-1.5-.2-2.9.9-3.7.9-.8 0-2-.9-3.2-.8-1.7 0-3.2 1-4 2.4-1.7 3-.4 7.4 1.2 9.8.8 1.2 1.8 2.5 3 2.4 1.2 0 1.7-.8 3.2-.8s1.9.8 3.2.8c1.3 0 2.2-1.2 3-2.4.9-1.4 1.3-2.7 1.3-2.8-.1 0-2.6-1-2.6-3.9ZM14.3 5.6c.7-.8 1.1-1.9 1-3-1 0-2.1.6-2.8 1.4-.6.7-1.2 1.8-1 2.9 1.1.1 2.2-.5 2.8-1.3Z" />
  </svg>
);
export const IcClose = (p: P) => (
  <svg {...base(p)}>
    <path d="m6 6 12 12M18 6 6 18" />
  </svg>
);
export const IcSliders = (p: P) => (
  <svg {...base(p)}>
    <path d="M4 6h9M17 6h3M4 12h3M11 12h9M4 18h9M17 18h3" />
    <circle cx="15" cy="6" r="2" />
    <circle cx="9" cy="12" r="2" />
    <circle cx="15" cy="18" r="2" />
  </svg>
);
export const IcSwap = (p: P) => (
  <svg {...base(p)}>
    <path d="M4 8h13l-3-3M20 16H7l3 3" />
  </svg>
);
export const IcPlay = (p: P) => (
  <svg viewBox="0 0 24 24" className={p.className} style={p.style} fill="currentColor">
    <path d="M4 3.4v17.2c0 .5.5.9 1 .7l15.2-8.6c.5-.3.5-1 0-1.2L5 2.7c-.5-.2-1 .2-1 .7Z" />
  </svg>
);

export const Verified = ({ className }: P) => (
  <svg viewBox="0 0 20 20" className={className} aria-label="verified">
    <circle cx="10" cy="10" r="10" fill="#1d9bf0" />
    <path d="m5.8 10.3 2.6 2.6 5.8-5.7" stroke="#fff" strokeWidth="2.1" fill="none" strokeLinecap="round" strokeLinejoin="round" />
  </svg>
);

export const LogoMark = ({ className }: P) => (
  <svg viewBox="0 0 48 48" className={className} aria-hidden>
    <rect width="48" height="48" rx="12" fill="currentColor" />
    <path d="M10 10h28l-2.5 7h-8v21h-7V17H10Z" fill="#fff" />
  </svg>
);

export const IcGoogle = ({ className }: P) => (
  <svg viewBox="0 0 24 24" className={className} aria-hidden>
    <path
      fill="#4285f4"
      d="M23.5 12.27c0-.85-.08-1.66-.22-2.45H12v4.64h6.46a5.52 5.52 0 0 1-2.4 3.62v3h3.88c2.27-2.09 3.56-5.17 3.56-8.81Z"
    />
    <path
      fill="#34a853"
      d="M12 24c3.24 0 5.96-1.07 7.94-2.91l-3.88-3c-1.08.72-2.45 1.15-4.06 1.15-3.13 0-5.78-2.11-6.72-4.95H1.27v3.11A12 12 0 0 0 12 24Z"
    />
    <path
      fill="#fbbc05"
      d="M5.28 14.29A7.2 7.2 0 0 1 4.9 12c0-.8.14-1.57.38-2.29V6.6H1.27a12 12 0 0 0 0 10.8l4.01-3.11Z"
    />
    <path
      fill="#ea4335"
      d="M12 4.77c1.76 0 3.34.6 4.58 1.79l3.44-3.44A11.97 11.97 0 0 0 12 0 12 12 0 0 0 1.27 6.6l4.01 3.11C6.22 6.87 8.87 4.77 12 4.77Z"
    />
  </svg>
);

const COIN_STYLES: Record<string, { bg: string; glyph: string; color: string }> = {
  BTC: { bg: "#f7931a", glyph: "₿", color: "#fff" },
  ETH: { bg: "#627eea", glyph: "◆", color: "#fff" },
  SOL: { bg: "linear-gradient(135deg,#9945ff,#14f195)", glyph: "≋", color: "#fff" },
  TAPE: { bg: "#0b0d10", glyph: "T", color: "#fff" },
  ARB: { bg: "#28a0f0", glyph: "A", color: "#fff" },
  LINK: { bg: "#2a5ada", glyph: "L", color: "#fff" },
  AVAX: { bg: "#e84142", glyph: "A", color: "#fff" },
  DOGE: { bg: "#c2a633", glyph: "D", color: "#fff" },
  TON: { bg: "#0098ea", glyph: "T", color: "#fff" },
  SUI: { bg: "#4da2ff", glyph: "S", color: "#fff" },
};

export function CoinBadge({ sym, className }: { sym: string; className?: string }) {
  const s = COIN_STYLES[sym] ?? { bg: "#555", glyph: sym[0], color: "#fff" };
  return (
    <span
      className={`inline-flex items-center justify-center rounded-full font-bold select-none ${className ?? ""}`}
      style={{ background: s.bg, color: s.color }}
      aria-hidden
    >
      <span className="leading-none">{s.glyph}</span>
    </span>
  );
}

export const StatusBarRight = () => (
  <span className="flex items-center gap-[3px]">
    <span className="flex items-end gap-[1.5px]">
      {[3, 4.5, 6, 7.5].map((h) => (
        <span key={h} className="w-[2.5px] rounded-[1px] bg-neutral-900" style={{ height: h }} />
      ))}
    </span>
    <svg width="13" height="11" viewBox="0 0 16 12" fill="none" className="text-neutral-900">
      <path d="M1.5 4.6c4-3.2 9-3.2 13 0" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
      <path d="M4 7.2c2.4-1.9 5.6-1.9 8 0" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" />
      <circle cx="8" cy="10" r="1.4" fill="currentColor" />
    </svg>
    <span className="flex items-center gap-[2px]">
      <span className="flex h-[9px] w-[17px] items-center rounded-[3px] border border-neutral-900/50 p-[1.5px]">
        <span className="h-full w-[70%] rounded-[1.5px] bg-neutral-900" />
      </span>
    </span>
  </span>
);
