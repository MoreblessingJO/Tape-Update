import { useState } from "react";
import type { FormEvent, MouseEvent } from "react";
import { cn } from "./utils/cn";
import { AppShell } from "./appshell";
import { CopyProvider } from "./copytrade";
import { MarketProvider } from "./api/market";
import { CoinBadge, IcApple, IcGoogle, LogoMark } from "./icons";
import { Sparkline } from "./ui";

type User = { name: string; email: string };

/* ================= auth screen ================= */

function AuthScreen({ onExit, onAuthed }: { onExit: () => void; onAuthed: (u: User) => void }) {
  const [mode, setMode] = useState<"signin" | "signup">("signin");
  const [busy, setBusy] = useState(false);

  const submit = (e: FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    if (busy) return;
    setBusy(true);
    const fd = new FormData(e.currentTarget);
    const email = String(fd.get("email") || "");
    const name = mode === "signup" ? String(fd.get("name") || "") : email.split("@")[0];
    window.setTimeout(() => onAuthed({ name: name || "Trader", email }), 750);
  };

  const social = (e: MouseEvent) => {
    e.preventDefault();
    if (busy) return;
    setBusy(true);
    window.setTimeout(() => onAuthed({ name: "Trader", email: "trader@tape.trade" }), 750);
  };

  return (
    <div className="flex min-h-screen bg-paper">
      {/* brand panel */}
      <div className="relative hidden w-[46%] flex-col justify-between overflow-hidden bg-ink p-12 text-white lg:flex">
        <div className="absolute -right-24 top-1/4 h-[420px] w-[420px] rounded-full bg-gain/20 blur-[110px]" />
        <div className="noise pointer-events-none absolute inset-0 opacity-[0.08]" />
        <div className="relative flex items-center gap-3">
          <LogoMark className="h-10 w-10 text-white" />
          <span className="font-display text-[28px] font-black tracking-[-0.03em]">TAPE</span>
        </div>
        <div className="relative">
          <h1 className="font-display text-[clamp(2rem,3.2vw,3rem)] font-black leading-[1.03] tracking-[-0.03em]">
            Trade the tape,
            <br />
            not the noise.
          </h1>
          <p className="mt-4 max-w-sm text-[14px] leading-relaxed text-white/60">
            The live feed of top crypto traders — every fill, every thesis, every alert — in the browser. No
            download required.
          </p>
          <div className="mt-8 w-[300px] max-w-full rounded-2xl border border-white/10 bg-white/[0.06] p-4">
            <div className="flex items-center gap-2">
              <span className="rounded-md bg-gain px-1.5 py-0.5 text-[10px] font-extrabold text-ink">BUY</span>
              <CoinBadge sym="SOL" className="h-6 w-6 text-[9px]" />
              <span className="font-display text-[14px] font-extrabold">$168.40</span>
              <span className="text-[10px] font-extrabold text-gain">+3.2%</span>
            </div>
            <div className="mt-1 text-[10px] font-bold text-white/60">OxKaito · bought 2,500 SOL · 2m ago</div>
            <div className="mt-3">
              <Sparkline points={[2, 4, 3, 7, 6, 9, 8, 12, 11, 15]} w={252} h={44} id="auth-spark" delay={0.4} />
            </div>
          </div>
        </div>
        <div className="relative text-[11px] font-semibold text-white/40">
          2.4M followers · $1.8B volume tracked · 142K alerts daily
        </div>
      </div>

      {/* form panel */}
      <div className="flex flex-1 flex-col">
        <div className="flex items-center justify-between p-5 lg:justify-end">
          <div className="flex items-center gap-2 lg:hidden">
            <LogoMark className="h-7 w-7 text-ink" />
            <span className="font-display text-[18px] font-black tracking-[-0.02em]">TAPE</span>
          </div>
          <button
            type="button"
            onClick={onExit}
            className="text-[13px] font-bold text-neutral-500 transition-colors hover:text-ink"
          >
            ← Back to tape.trade
          </button>
        </div>
        <div className="flex flex-1 items-center justify-center px-6 pb-16">
          <div className="w-full max-w-[420px] rounded-3xl border border-neutral-200 bg-white p-8 shadow-[0_30px_60px_-30px_rgba(12,16,28,0.3)]">
            <div className="flex rounded-full bg-neutral-100 p-1">
              {(["signin", "signup"] as const).map((m) => (
                <button
                  key={m}
                  type="button"
                  onClick={() => setMode(m)}
                  className={cn(
                    "flex-1 rounded-full py-2 text-[12px] font-extrabold transition-all",
                    mode === m ? "bg-ink text-white shadow-sm" : "text-neutral-500 hover:text-ink"
                  )}
                >
                  {m === "signin" ? "Sign in" : "Create account"}
                </button>
              ))}
            </div>

            <h2 className="mt-6 font-display text-[26px] font-black tracking-tight">
              {mode === "signin" ? "Welcome back." : "Start trading free."}
            </h2>
            <p className="mt-1.5 text-[13px] font-medium text-neutral-500">
              {mode === "signin"
                ? "Pick up where the tape left off."
                : "Follow top traders, get live alerts, copy in one tap. No card required."}
            </p>

            <div className="mt-6 flex flex-col gap-2.5">
              <a
                href="#web"
                onClick={social}
                className="flex items-center justify-center gap-2.5 rounded-xl border border-neutral-200 bg-white py-2.5 text-[13px] font-extrabold transition-all hover:border-neutral-400 active:scale-[0.98]"
              >
                <IcGoogle className="h-4.5 w-4.5" /> Continue with Google
              </a>
              <a
                href="#web"
                onClick={social}
                className="flex items-center justify-center gap-2.5 rounded-xl bg-ink py-2.5 text-[13px] font-extrabold text-white transition-all hover:bg-neutral-700 active:scale-[0.98]"
              >
                <IcApple className="h-4.5 w-4.5" /> Continue with Apple
              </a>
            </div>

            <div className="my-5 flex items-center gap-3 text-[11px] font-bold uppercase tracking-wider text-neutral-300">
              <span className="h-px flex-1 bg-neutral-200" />
              or continue with email
              <span className="h-px flex-1 bg-neutral-200" />
            </div>

            <form onSubmit={submit} className="flex flex-col gap-3">
              {mode === "signup" && (
                <input
                  name="name"
                  required
                  placeholder="Display name"
                  className="rounded-xl border border-neutral-200 bg-paper/60 px-4 py-3 text-[14px] font-semibold outline-none transition-colors placeholder:font-medium placeholder:text-neutral-400 focus:border-ink"
                />
              )}
              <input
                name="email"
                type="email"
                required
                placeholder="Email address"
                className="rounded-xl border border-neutral-200 bg-paper/60 px-4 py-3 text-[14px] font-semibold outline-none transition-colors placeholder:font-medium placeholder:text-neutral-400 focus:border-ink"
              />
              <input
                name="password"
                type="password"
                required
                minLength={8}
                placeholder={mode === "signup" ? "Create a password (8+ characters)" : "Password"}
                className="rounded-xl border border-neutral-200 bg-paper/60 px-4 py-3 text-[14px] font-semibold outline-none transition-colors placeholder:font-medium placeholder:text-neutral-400 focus:border-ink"
              />
              <button
                type="submit"
                disabled={busy}
                className={cn(
                  "mt-1 flex items-center justify-center gap-2 rounded-xl bg-ink py-3.5 text-[14px] font-extrabold text-white transition-all hover:bg-neutral-700 active:scale-[0.98]",
                  busy && "opacity-70"
                )}
              >
                {busy && (
                  <span className="h-4 w-4 animate-spin rounded-full border-2 border-white/30 border-t-white" />
                )}
                {busy ? "One sec…" : mode === "signin" ? "Sign in to your tape" : "Create my account"}
              </button>
            </form>

            <p className="mt-5 text-center text-[11px] font-medium leading-relaxed text-neutral-400">
              {mode === "signup" ? "By creating an account you agree to the" : "By signing in you agree to the"}{" "}
              <a href="#web" className="font-bold text-neutral-600 hover:text-ink">Terms</a> and{" "}
              <a href="#web" className="font-bold text-neutral-600 hover:text-ink">Privacy Policy</a>.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ================= root ================= */

export function TapeApp({ onExit }: { onExit: () => void }) {
  const [user, setUser] = useState<User | null>(null);

  if (!user) return <AuthScreen onExit={onExit} onAuthed={setUser} />;
  return (
    <MarketProvider>
      <CopyProvider>
        <AppShell onExit={onExit} />
      </CopyProvider>
    </MarketProvider>
  );
}

export default TapeApp;
