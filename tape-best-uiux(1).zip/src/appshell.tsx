import { useEffect, useState } from "react";
import type { CSSProperties, ReactNode } from "react";
import { cn } from "./utils/cn";
import {
  GAINERS,
  HOME_TOP,
  LOSERS,
  NOTIFS,
  ONCHAIN_TOP,
  PLATFORM_TOP,
  TRADERS,
  TRENDING,
  type Notif,
  type Trader,
} from "./data";
import { Avatar, FollowButton, Sparkline, TabPills, useTick } from "./ui";
import { CopiesPage, CopyButton, RankedBoard, useCopy } from "./copytrade";
import { useMarket } from "./api/market";
import { DataSourcesPage } from "./DataSource";
import {
  CoinBadge,
  IcBell,
  IcBookmark,
  IcChat,
  IcChevR,
  IcCopy,
  IcDoc,
  IcEye,
  IcHeart,
  IcHome,
  IcMore,
  IcPlus,
  IcPulse,
  IcRep,
  IcSearch,
  IcShare,
  IcTrendDown,
  IcTrendUp,
  IcUser,
  IcUserPlus,
  IcWallet,
  LogoMark,
  Verified,
} from "./icons";

/* ================= shared bits ================= */

type Page = "home" | "discover" | "trade" | "copy" | "wallet" | "profile" | "notifications" | "sources";
type Nav = (page: Page, traderId?: string) => void;

const NAV_ITEMS: { id: Page; label: string; Icon: (p: { className?: string }) => ReactNode }[] = [
  { id: "home", label: "Home", Icon: IcHome },
  { id: "discover", label: "Discover", Icon: IcSearch },
  { id: "trade", label: "Trade", Icon: IcPulse },
  { id: "copy", label: "Copy", Icon: IcCopy },
  { id: "wallet", label: "Wallet", Icon: IcWallet },
  { id: "profile", label: "Profile", Icon: IcUser },
];

const KIND_META: Record<Notif["kind"], { cls: string; Icon: (p: { className?: string }) => ReactNode }> = {
  buy: { cls: "bg-gain/10 text-gain", Icon: (p) => <IcTrendUp {...p} /> },
  sell: { cls: "bg-loss/10 text-loss", Icon: (p) => <IcTrendDown {...p} /> },
  long: { cls: "bg-sky-100 text-sky-600", Icon: (p) => <IcTrendUp {...p} /> },
  thesis: { cls: "bg-neutral-200/70 text-neutral-600", Icon: (p) => <IcDoc {...p} /> },
  follow: { cls: "bg-indigo-100 text-indigo-600", Icon: (p) => <IcUserPlus {...p} /> },
  mention: { cls: "bg-amber-100 text-amber-600", Icon: (p) => <IcChat {...p} /> },
};

function Card({ children, className }: { children: ReactNode; className?: string }) {
  return (
    <div className={cn("rounded-3xl border border-neutral-200 bg-white p-5 md:p-6", className)}>{children}</div>
  );
}

function SectionHead({
  title,
  action,
  onAction,
}: {
  title: string;
  action?: string;
  onAction?: () => void;
}) {
  return (
    <div className="flex items-center justify-between">
      <h2 className="text-[15px] font-extrabold tracking-tight">{title}</h2>
      {action && (
        <button
          type="button"
          onClick={onAction}
          className="text-[11px] font-bold text-neutral-400 transition-colors hover:text-ink"
        >
          {action}
        </button>
      )}
    </div>
  );
}

function TraderCard({ t, onOpen }: { t: Trader; onOpen: (id: string) => void }) {
  return (
    <div className="rounded-2xl px-2 py-2.5 transition-colors hover:bg-paper">
      <div className="flex items-center gap-2.5">
        <button type="button" onClick={() => onOpen(t.id)} className="relative shrink-0" aria-label={t.name}>
          <Avatar src={t.img} name={t.name} size={44} />
          <span className="absolute -bottom-0.5 -right-0.5 flex h-4 w-4 items-center justify-center rounded-full bg-ink text-white ring-2 ring-white">
            <IcPlus className="h-2.5 w-2.5" />
          </span>
        </button>
        <button type="button" onClick={() => onOpen(t.id)} className="min-w-0 flex-1 text-left">
          <div className="flex items-center gap-1">
            <span className="truncate text-[13px] font-extrabold leading-tight">{t.name}</span>
            <Verified className="h-3.5 w-3.5 shrink-0" />
          </div>
          <div className="text-[11px] font-extrabold leading-tight text-gain">{t.pnl} (90D)</div>
          <div className="truncate text-[10px] font-medium text-neutral-400">{t.followers}</div>
        </button>
      </div>
      <div className="mt-2 flex items-center gap-1.5">
        <FollowButton className="flex-1 px-3 py-1.5 text-[10px]" />
        <CopyButton traderId={t.id} className="flex-1 px-3 py-1.5" />
      </div>
    </div>
  );
}

function CoinLine({ row }: { row: (typeof TRENDING)[number] }) {
  return (
    <div className="flex items-center gap-3 rounded-xl px-1 py-2 transition-colors hover:bg-paper/70">
      <CoinBadge sym={row.sym} className="h-10 w-10 text-[14px]" />
      <div className="w-24">
        <div className="text-[13px] font-extrabold leading-tight">{row.sym}</div>
        <div className="truncate text-[10px] font-medium text-neutral-400">{row.name}</div>
      </div>
      <Sparkline points={row.points} w={70} h={30} up={row.up} id={`wl-${row.sym}`} delay={0.4} className="hidden sm:block" />
      <div className="ml-auto text-right">
        <div className="text-[13px] font-extrabold leading-tight">{row.price}</div>
        <div className={cn("text-[10px] font-extrabold", row.up ? "text-gain" : "text-loss")}>{row.change}</div>
      </div>
      <IcChevR className="h-4 w-4 text-neutral-300" />
    </div>
  );
}

/* ================= rail ================= */

function LiveAlerts({ nav }: { nav: Nav }) {
  return (
    <Card className="p-5">
      <div className="flex items-center gap-2">
        <h2 className="text-[15px] font-extrabold tracking-tight">Live alerts</h2>
        <span className="relative flex h-2 w-2">
          <span className="ping-ring absolute h-full w-full rounded-full bg-gain" />
          <span className="relative h-2 w-2 rounded-full bg-gain" />
        </span>
        <button
          type="button"
          onClick={() => nav("notifications")}
          className="ml-auto text-[11px] font-bold text-neutral-400 transition-colors hover:text-ink"
        >
          View all
        </button>
      </div>
      <div className="mt-2 flex flex-col divide-y divide-neutral-100">
        {NOTIFS.slice(0, 4).map((nt) => {
          const meta = KIND_META[nt.kind];
          const t = nt.trader ? TRADERS[nt.trader] : null;
          return (
            <div key={nt.id} className="flex items-center gap-2.5 py-3">
              {t ? (
                <Avatar src={t.img} name={t.name} size={30} />
              ) : (
                <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-ink text-white">
                  <IcUserPlus className="h-3.5 w-3.5" />
                </span>
              )}
              <span className={cn("flex h-6 w-6 shrink-0 items-center justify-center rounded-full", meta.cls)}>
                <meta.Icon className="h-3 w-3" />
              </span>
              <p className="min-w-0 flex-1 text-[11px] font-medium leading-snug text-neutral-700">{nt.text}</p>
              <span className="shrink-0 text-[9px] font-semibold text-neutral-400">{nt.time}</span>
            </div>
          );
        })}
      </div>
    </Card>
  );
}

function TrendingCard({ nav }: { nav: Nav }) {
  return (
    <Card className="p-5">
      <SectionHead title="Trending now" action="See all" onAction={() => nav("discover")} />
      <div className="mt-2 flex flex-col divide-y divide-neutral-100">
        {TRENDING.map((r) => (
          <div key={r.sym} className="flex items-center gap-2.5 py-3">
            <CoinBadge sym={r.sym} className="h-8 w-8 text-[11px]" />
            <div>
              <div className="text-[12px] font-extrabold leading-tight">{r.sym}</div>
              <div className="text-[9.5px] font-medium text-neutral-400">{r.name}</div>
            </div>
            <Sparkline points={r.points} w={52} h={24} up={r.up} id={`rail-${r.sym}`} delay={0.4} />
            <div className="ml-auto text-right">
              <div className="text-[12px] font-extrabold leading-tight">{r.price}</div>
              <div className={cn("text-[9.5px] font-extrabold", r.up ? "text-gain" : "text-loss")}>{r.change}</div>
            </div>
          </div>
        ))}
      </div>
    </Card>
  );
}

function CopyRailCard({ nav }: { nav: Nav }) {
  const { configs } = useCopy();
  const active = configs.filter((c) => !c.paused);
  const deployed = configs.reduce((s, c) => s + c.spent, 0);
  return (
    <div className="relative overflow-hidden rounded-3xl bg-ink p-5 text-white">
      <div className="absolute -right-10 -top-10 h-28 w-28 rounded-full bg-gain/25 blur-2xl" />
      <div className="relative">
        <div className="flex items-center gap-2">
          <IcCopy className="h-4 w-4 text-gain" />
          <h2 className="text-[13px] font-extrabold tracking-tight">Copy engine</h2>
          <span className="ml-auto rounded-full bg-gain/15 px-2 py-0.5 text-[9px] font-extrabold text-gain">
            {active.length} live
          </span>
        </div>
        <div className="mt-1.5 font-display text-[22px] font-extrabold tracking-tight">
          ${deployed.toLocaleString()} deployed
        </div>
        <p className="mt-0.5 text-[10.5px] font-medium leading-snug text-white/50">
          Your TP, SL and trailing exits run even when the trader keeps holding.
        </p>
        <button
          type="button"
          onClick={() => nav("copy")}
          className="mt-3 w-full rounded-full bg-white py-2 text-[11px] font-extrabold text-ink transition-all hover:bg-gain active:scale-95"
        >
          Manage copies
        </button>
      </div>
    </div>
  );
}

function MyThesis({ nav }: { nav: Nav }) {
  return (
    <Card className="p-5">
      <div className="flex items-center gap-1.5">
        <IcDoc className="h-4 w-4 text-neutral-500" />
        <h2 className="text-[15px] font-extrabold tracking-tight">My Thesis</h2>
      </div>
      <p className="mt-2 text-[12px] font-medium leading-relaxed text-neutral-600">
        SOL is showing strong momentum after the recent ecosystem updates, with rising DEX volume and fresh inflows
        from on-chain smart money. I&rsquo;m accumulating here for a potential continuation to $210.
      </p>
      <div className="mt-3 flex flex-wrap gap-1.5">
        <span className="rounded-md bg-gain/10 px-2 py-1 text-[10px] font-extrabold text-gain">Target $210</span>
        <span className="rounded-md bg-loss/10 px-2 py-1 text-[10px] font-extrabold text-loss">Stop $154</span>
      </div>
      <button
        type="button"
        onClick={() => nav("trade")}
        className="mt-4 w-full rounded-full bg-ink py-2.5 text-[12px] font-extrabold text-white transition-all hover:bg-neutral-700 active:scale-95"
      >
        Open trade update
      </button>
    </Card>
  );
}

/* ================= home ================= */

function HomePage({ nav }: { nav: Nav }) {
  const [feed, setFeed] = useState("For You");
  const [wl, setWl] = useState("Watchlist");
  const [sub, setSub] = useState("Trending");
  const { v, dir, n } = useTick(12480.2, 14);
  const rows = sub === "Gainers" ? GAINERS : sub === "Losers" ? LOSERS : TRENDING;

  return (
    <div className="grid gap-5 lg:grid-cols-[minmax(0,1fr)_340px]">
      <div className="flex flex-col gap-5">
        {/* balance — exactly the phone header row */}
        <div className="fadeup flex items-center gap-3" style={{ "--d": "0.05s" } as CSSProperties}>
          <button
            type="button"
            onClick={() => nav("wallet")}
            className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-ink text-white transition-all hover:bg-neutral-700 active:scale-95"
            aria-label="Add funds"
          >
            <IcPlus className="h-5 w-5" />
          </button>
          <div className="min-w-0">
            <div
              key={n}
              className={cn(
                "inline-flex items-center gap-2 px-0.5",
                dir === 1 && "tick-up",
                dir === -1 && "tick-down"
              )}
            >
              <span className="font-display text-[26px] font-extrabold tracking-tight md:text-[30px]">
                ${v.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
              </span>
              <IcEye className="h-4 w-4 text-neutral-400" />
            </div>
            <div className="text-[11px] font-extrabold text-gain">+8.24% (24H)</div>
          </div>
        </div>

        <TabPills tabs={["For You", "Following", "Trending"]} active={feed} onChange={setFeed} />

        {/* green hero banner */}
        <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-[#04291a] via-[#0a5a33] to-[#12a457] p-6">
          <svg
            className="pointer-events-none absolute -right-2 bottom-1 h-20 w-40 text-white/60"
            viewBox="0 0 100 50"
            fill="none"
            aria-hidden
          >
            <path d="M2 46 L32 28 L52 36 L88 8" stroke="currentColor" strokeWidth="4" strokeLinecap="round" />
            <path
              d="M76 5 L92 5 L90 21"
              stroke="currentColor"
              strokeWidth="4"
              strokeLinecap="round"
              strokeLinejoin="round"
            />
          </svg>
          <div className="relative">
            <div className="font-display text-[24px] font-extrabold leading-[1.1] text-white md:text-[28px]">
              Trade With
              <br />
              Top Traders
            </div>
            <div className="mt-2 max-w-[78%] text-[12px] font-medium leading-snug text-white/75 md:max-w-[60%]">
              Follow real traders, see their trades, and trade smarter.
            </div>
            <button
              type="button"
              onClick={() => nav("discover")}
              className="mt-4 rounded-full bg-white px-4 py-2 text-[11px] font-extrabold text-ink transition-all hover:bg-gain active:scale-95"
            >
              Find traders
            </button>
          </div>
        </div>

        {/* top traders */}
        <Card>
          <SectionHead title="Top Traders to Follow" action="See All" onAction={() => nav("discover")} />
          <div className="mt-3 grid grid-cols-1 gap-1 sm:grid-cols-3">
            {HOME_TOP.map((id) => (
              <TraderCard key={id} t={TRADERS[id]} onOpen={(t) => nav("profile", t)} />
            ))}
          </div>
        </Card>

        <div className="flex flex-col gap-3">
          <TabPills tabs={["Watchlist", "Spots", "Futures", "Memes"]} active={wl} onChange={setWl} />
          <div className="flex flex-wrap gap-1.5">
            {["Trending", "Gainers", "Losers"].map((s) => (
              <button
                key={s}
                type="button"
                onClick={() => setSub(s)}
                className={cn(
                  "rounded-full px-3.5 py-1.5 text-[10px] font-bold transition-colors",
                  sub === s ? "bg-ink text-white" : "border border-neutral-200 bg-white text-neutral-500 hover:text-ink"
                )}
              >
                {s}
              </button>
            ))}
          </div>
        </div>

        <Card className="p-3 md:p-4">
          <div className="flex flex-col gap-1">
            {rows.map((r) => (
              <CoinLine key={r.sym} row={r} />
            ))}
          </div>
        </Card>
      </div>

      <aside className="flex flex-col gap-5">
        <CopyRailCard nav={nav} />
        <LiveAlerts nav={nav} />
        <TrendingCard nav={nav} />
      </aside>
    </div>
  );
}

/* ================= discover ================= */

function DiscoverPage({ nav }: { nav: Nav }) {
  const [tab, setTab] = useState("Traders");
  const [q, setQ] = useState("");
  const market = useMarket();

  const matches = (t: Trader) =>
    !q || t.name.toLowerCase().includes(q.toLowerCase()) || t.handle.toLowerCase().includes(q.toLowerCase());
  const platform = PLATFORM_TOP.map((id) => TRADERS[id]).filter(matches);
  const onchain = ONCHAIN_TOP.map((id) => TRADERS[id]).filter(matches);

  return (
    <div className="fadeup mx-auto flex max-w-[1060px] flex-col gap-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h1 className="font-display text-[28px] font-extrabold tracking-tight">Discover</h1>
        <span className="hidden items-center gap-2 rounded-full border border-neutral-200 bg-white px-3.5 py-2 text-[11px] font-bold text-neutral-500 sm:inline-flex">
          <span className="relative flex h-2 w-2">
            <span className="ping-ring absolute h-full w-full rounded-full bg-gain" />
            <span className="relative h-2 w-2 rounded-full bg-gain" />
          </span>
          Live · updated every fill
        </span>
      </div>

      <label className="flex items-center gap-2.5 rounded-xl border border-neutral-200 bg-white px-4 py-3">
        <IcSearch className="h-4 w-4 text-neutral-400" />
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Search traders, tokens, wallets…"
          className="w-full bg-transparent text-[13px] font-medium outline-none placeholder:text-neutral-400"
        />
      </label>

      <RankedBoard rows={market.rows} live={market.mode !== "demo"} onOpenTrader={(id) => nav("profile", id)} />

      <TabPills tabs={["Traders", "Wallets", "Tokens", "Lists"]} active={tab} onChange={setTab} />

      {tab === "Traders" && (
        <div className="grid gap-5 md:grid-cols-2">
          <Card>
            <SectionHead title="Top Platform Traders" action="See All" onAction={() => setTab("Wallets")} />
            <div className="mt-2 flex flex-col">
              {platform.map((t) => (
                <TraderCard key={t.id} t={t} onOpen={(id) => nav("profile", id)} />
              ))}
              {platform.length === 0 && <Empty />}
            </div>
          </Card>
          <Card>
            <SectionHead title="Top On-chain Traders" action="See All" onAction={() => setTab("Wallets")} />
            <div className="mt-2 flex flex-col">
              {onchain.map((t) => (
                <TraderCard key={t.id} t={t} onOpen={(id) => nav("profile", id)} />
              ))}
              {onchain.length === 0 && <Empty />}
            </div>
          </Card>
        </div>
      )}

      {tab === "Wallets" && (
        <Card>
          <SectionHead title="Smart money wallets" />
          <div className="mt-3 flex flex-col gap-1">
            {ONCHAIN_TOP.map((id) => {
              const t = TRADERS[id];
              return (
                <div key={id} className="flex items-center gap-3 rounded-xl px-2 py-3 transition-colors hover:bg-paper">
                  <Avatar src={t.img} name={t.name} size={40} />
                  <div className="min-w-0">
                    <div className="truncate font-mono text-[12px] font-bold">{t.handle}</div>
                    <div className="text-[10px] font-medium text-neutral-400">Ethereum · 312 trades (90D)</div>
                  </div>
                  <span className="ml-auto text-[12px] font-extrabold text-gain">{t.pnl}</span>
                  <FollowButton className="ml-2 px-3 py-1.5 text-[10px]" />
                  <CopyButton traderId={id} className="px-3 py-1.5" />
                </div>
              );
            })}
          </div>
        </Card>
      )}

      {tab === "Tokens" && (
        <Card>
          <SectionHead title="Trending tokens" />
          <div className="mt-2 flex flex-col sm:grid sm:grid-cols-2 sm:gap-x-6">
            {[...TRENDING, ...GAINERS].map((r, i) => (
              <CoinLine key={`${r.sym}-${i}`} row={r} />
            ))}
          </div>
        </Card>
      )}

      {tab === "Lists" && (
        <div className="grid gap-3 sm:grid-cols-3">
          {[
            { n: "AI Narratives", d: "42 tokens · +318% avg 90D", sym: "ETH" },
            { n: "L2 Blue Chips", d: "18 tokens · +124% avg 90D", sym: "ARB" },
            { n: "Fresh Degen Bets", d: "9 tokens · +97% avg 90D", sym: "SOL" },
          ].map((l) => (
            <Card key={l.n} className="p-4 transition-shadow hover:shadow-[0_20px_40px_-30px_rgba(12,16,28,0.4)]">
              <CoinBadge sym={l.sym} className="h-9 w-9 text-[12px]" />
              <div className="mt-3 text-[13px] font-extrabold">{l.n}</div>
              <div className="text-[11px] font-medium text-neutral-400">{l.d}</div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}

function Empty() {
  return <div className="py-6 text-center text-[12px] font-medium text-neutral-400">No results.</div>;
}

/* ================= profile ================= */

const POSITIONS = [
  { sym: "SOL", pct: "42.5%", val: "$164,630", pnl: "+18.7%" },
  { sym: "BTC", pct: "28.1%", val: "$108,850", pnl: "+6.4%" },
  { sym: "ETH", pct: "12.6%", val: "$48,790", pnl: "+9.1%" },
];
const MINI_TRADES = [
  { side: "BUY", txt: "2,500 SOL @ $168.40", time: "2m ago" },
  { side: "SELL", txt: "10.2 ETH @ $3,842.00", time: "3h ago" },
  { side: "LONG", txt: "5.1 BTC (10x)", time: "1d ago" },
];

function ProfilePage({ traderId, nav }: { traderId: string; nav: Nav }) {
  const t = TRADERS[traderId] ?? TRADERS.kaito;
  const [tab, setTab] = useState("Portfolio");
  const bio = t.bio ?? "Crypto Trader | On-chain Analyst | Macro & Narrative Plays";
  const win = t.win ?? "72%";

  return (
    <div className="fadeup grid gap-5 lg:grid-cols-[minmax(0,1fr)_340px]">
      <div className="flex flex-col gap-5">
        <Card>
          <div className="flex flex-wrap items-start gap-4">
            <Avatar src={t.img} name={t.name} size={72} />
            <div className="min-w-0 flex-1">
              <div className="flex items-center gap-1.5">
                <h1 className="font-display text-[22px] font-extrabold tracking-tight">{t.name}</h1>
                <Verified className="h-4 w-4" />
              </div>
              <div className="text-[12px] font-medium text-neutral-400">{t.handle}</div>
              <p className="mt-2 max-w-lg text-[12px] font-medium leading-relaxed text-neutral-500">{bio}</p>
            </div>
            <div className="flex items-center gap-2">
              <FollowButton label="Follow" className="px-5 py-2.5 text-[12px]" />
              <CopyButton traderId={t.id} className="px-5 py-2.5 text-[12px]" label="Copy trader" />
            </div>
          </div>

          <div className="mt-5 grid grid-cols-3 divide-x divide-neutral-100 rounded-2xl border border-neutral-100 py-3">
            {[
              { v: t.followers.replace(" followers", ""), l: "Followers" },
              { v: "420", l: "Following" },
              { v: t.pnl, l: "90D PnL", g: true },
            ].map((s) => (
              <div key={s.l} className="px-3 text-center">
                <div className={cn("font-display text-[17px] font-extrabold", s.g && "text-gain")}>{s.v}</div>
                <div className="text-[9px] font-bold uppercase tracking-wider text-neutral-400">{s.l}</div>
              </div>
            ))}
          </div>
        </Card>

        <Card className="bg-neutral-50/70">
          <div className="flex items-start justify-between gap-3">
            <div>
              <div className="text-[10px] font-bold uppercase tracking-wider text-neutral-400">Total PnL (90D)</div>
              <div className="font-display text-[28px] font-extrabold tracking-tight text-gain">
                {t.pnl.endsWith("%") ? `${t.pnl.replace("%", "")}.3%` : t.pnl}
              </div>
            </div>
            <Sparkline
              points={[2, 4, 3, 7, 5, 9, 8, 12, 10, 15, 13, 18, 16, 22]}
              w={190}
              h={56}
              id={`app-profile-${t.id}`}
              delay={0.4}
              className="shrink-0"
            />
          </div>
          <div className="mt-3 grid grid-cols-3 divide-x divide-neutral-200/70 border-t border-neutral-200/70 pt-3 text-center">
            {[
              { l: "Win Rate", v: win },
              { l: "Total Trades", v: "1,264" },
              { l: "Avg. R:R", v: "1:3.8" },
            ].map((s) => (
              <div key={s.l}>
                <div className="text-[9.5px] font-bold text-neutral-400">{s.l}</div>
                <div className="text-[13px] font-extrabold">{s.v}</div>
              </div>
            ))}
          </div>
        </Card>

        <TabPills tabs={["Portfolio", "Trades", "Thesis", "About"]} active={tab} onChange={setTab} />

        <Card>
          {tab === "Portfolio" && (
            <>
              <div className="mb-3 flex items-center justify-between">
                <span className="text-[13px] font-extrabold">Portfolio ($387,420)</span>
                <span className="text-[12px] font-extrabold text-gain">+12.4%</span>
              </div>
              <div className="flex flex-col divide-y divide-neutral-100">
                {POSITIONS.map((p) => (
                  <div key={p.sym} className="flex items-center gap-3 py-3">
                    <CoinBadge sym={p.sym} className="h-9 w-9 text-[12px]" />
                    <div>
                      <div className="text-[12px] font-extrabold leading-tight">{p.sym}</div>
                      <div className="text-[10px] font-medium text-neutral-400">{p.pct}</div>
                    </div>
                    <div className="ml-auto text-right">
                      <div className="text-[12px] font-extrabold leading-tight">{p.val}</div>
                      <div className="text-[10px] font-extrabold text-gain">{p.pnl}</div>
                    </div>
                  </div>
                ))}
              </div>
            </>
          )}
          {tab === "Trades" && (
            <div className="flex flex-col gap-2">
              {MINI_TRADES.map((tr) => (
                <div key={tr.txt} className="flex items-center gap-3 rounded-xl bg-paper px-3 py-2.5">
                  <span
                    className={cn(
                      "rounded-md px-1.5 py-0.5 text-[9px] font-extrabold",
                      tr.side === "SELL" ? "bg-loss/10 text-loss" : "bg-gain/10 text-gain"
                    )}
                  >
                    {tr.side}
                  </span>
                  <span className="text-[12px] font-bold">{tr.txt}</span>
                  <span className="ml-auto text-[10px] font-medium text-neutral-400">{tr.time}</span>
                </div>
              ))}
            </div>
          )}
          {tab === "Thesis" && (
            <p className="text-[12px] font-medium leading-relaxed text-neutral-600">
              SOL is showing strong momentum after the recent ecosystem updates. I&rsquo;m accumulating on dips while
              DEX volume stays elevated. Macro window into Q3 looks constructive — target $210, invalid below $150.
            </p>
          )}
          {tab === "About" && (
            <div className="flex flex-col gap-2 text-[12px] font-medium">
              <div className="text-neutral-600">{bio}</div>
              {[
                ["Joined", "March 2024"],
                ["Focus", "L1 · L2 · AI"],
                ["Exchange", "Binance · Bybit"],
              ].map(([l, v]) => (
                <div key={l} className="flex justify-between border-t border-neutral-100 pt-2">
                  <span className="text-neutral-400">{l}</span>
                  <span className="font-bold">{v}</span>
                </div>
              ))}
            </div>
          )}
        </Card>
      </div>

      <aside className="flex flex-col gap-5">
        <MyThesis nav={nav} />
        <Card className="p-5">
          <SectionHead title="Recent trades" action="Open feed" onAction={() => nav("trade")} />
          <div className="mt-2 flex flex-col divide-y divide-neutral-100">
            {MINI_TRADES.map((tr) => (
              <div key={tr.txt} className="flex items-center gap-2 py-3">
                <span
                  className={cn(
                    "rounded-md px-1.5 py-0.5 text-[9px] font-extrabold",
                    tr.side === "SELL" ? "bg-loss/10 text-loss" : "bg-gain/10 text-gain"
                  )}
                >
                  {tr.side}
                </span>
                <span className="text-[11px] font-bold">{tr.txt}</span>
                <span className="ml-auto text-[9px] font-medium text-neutral-400">{tr.time}</span>
              </div>
            ))}
          </div>
        </Card>
        <TrendingCard nav={nav} />
      </aside>
    </div>
  );
}

/* ================= trade feed / post ================= */

const COMMENTS = [
  { t: TRADERS.degen, time: "1m ago", txt: "Same read. Funding reset + OI climbing — I'm in at $167." },
  { t: TRADERS.sis, time: "just now", txt: "That $210 target looks clean if DEX volume holds." },
];

const TRADE_COINS = [
  { sym: "SOL", price: 168.4 },
  { sym: "ETH", price: 4071.2 },
  { sym: "BTC", price: 112430 },
  { sym: "TAPE", price: 0.0042 },
];

function TradeTicket() {
  const { notify } = useCopy();
  const [side, setSide] = useState<"Buy" | "Sell" | "Swap">("Buy");
  const [amount, setAmount] = useState("100");
  const [coin, setCoin] = useState("SOL");
  const [slippage, setSlippage] = useState("1.0");
  const [useExits, setUseExits] = useState(true);
  const [tp, setTp] = useState("100");
  const [sl, setSl] = useState("20");

  const c = TRADE_COINS.find((x) => x.sym === coin) ?? TRADE_COINS[0];
  const usd = Math.max(0, Number(amount) || 0);
  const qty = usd / c.price;
  const receive = qty >= 1 ? qty.toLocaleString(undefined, { maximumFractionDigits: 4 }) : qty.toFixed(6);

  const place = () => {
    if (usd <= 0) return;
    notify(
      `${side} filled · $${usd.toLocaleString()} of ${coin} at $${c.price.toLocaleString(undefined, {
        maximumFractionDigits: 4,
      })}. Independent trade, no copy attached.`
    );
  };

  return (
    <Card className="p-5">
      <div className="flex items-center justify-between">
        <h2 className="text-[15px] font-extrabold tracking-tight">Trade independently</h2>
        <span className="rounded-md bg-neutral-100 px-1.5 py-0.5 text-[9px] font-extrabold text-neutral-500">
          Your call
        </span>
      </div>

      <div className="mt-3 flex rounded-full bg-paper p-0.5">
        {(["Buy", "Sell", "Swap"] as const).map((s) => (
          <button
            key={s}
            type="button"
            onClick={() => setSide(s)}
            className={cn(
              "flex-1 rounded-full py-1.5 text-[11px] font-extrabold transition-all",
              side === s
                ? s === "Sell"
                  ? "bg-loss text-white"
                  : "bg-ink text-white"
                : "text-neutral-500 hover:text-ink"
            )}
          >
            {s}
          </button>
        ))}
      </div>

      <div className="mt-3 flex flex-wrap gap-1.5">
        {TRADE_COINS.map((tc) => (
          <button
            key={tc.sym}
            type="button"
            onClick={() => setCoin(tc.sym)}
            className={cn(
              "flex items-center gap-1.5 rounded-full border py-1 pl-1 pr-2.5 transition-colors",
              coin === tc.sym ? "border-ink bg-ink text-white" : "border-neutral-200 bg-white text-neutral-600"
            )}
          >
            <CoinBadge sym={tc.sym} className="h-5 w-5 text-[8px]" />
            <span className="text-[10px] font-extrabold">{tc.sym}</span>
          </button>
        ))}
      </div>

      <label className="mt-3 block">
        <span className="text-[9px] font-extrabold uppercase tracking-[0.12em] text-neutral-400">
          {side === "Sell" ? "Amount to sell" : "Amount to spend"}
        </span>
        <span className="mt-1 flex items-center gap-2 rounded-xl border border-neutral-200 bg-paper/60 px-3 py-2.5 focus-within:border-ink">
          <span className="text-[15px] font-extrabold text-neutral-400">$</span>
          <input
            type="number"
            min={1}
            value={amount}
            onChange={(e) => setAmount(e.target.value)}
            className="min-w-0 flex-1 bg-transparent text-[16px] font-extrabold outline-none"
            aria-label="Trade amount in USD"
          />
          <span className="text-[10px] font-extrabold text-neutral-400">USD</span>
        </span>
      </label>
      <div className="mt-1.5 flex gap-1.5">
        {[25, 50, 100, 250].map((v) => (
          <button
            key={v}
            type="button"
            onClick={() => setAmount(String(v))}
            className="flex-1 rounded-lg border border-neutral-200 bg-white py-1 text-[10px] font-bold text-neutral-500 transition-colors hover:border-ink hover:text-ink"
          >
            ${v}
          </button>
        ))}
      </div>

      <div className="mt-3 space-y-1.5 rounded-xl bg-paper p-3">
        <div className="flex items-center justify-between text-[11px]">
          <span className="font-medium text-neutral-500">Market price</span>
          <span className="font-extrabold">
            ${c.price.toLocaleString(undefined, { maximumFractionDigits: 4 })}
          </span>
        </div>
        <div className="flex items-center justify-between text-[11px]">
          <span className="font-medium text-neutral-500">You receive (est.)</span>
          <span className="font-extrabold">
            {receive} {coin}
          </span>
        </div>
        <div className="flex items-center justify-between text-[11px]">
          <span className="font-medium text-neutral-500">Slippage</span>
          <span className="flex gap-1">
            {["0.5", "1.0", "2.0"].map((s) => (
              <button
                key={s}
                type="button"
                onClick={() => setSlippage(s)}
                className={cn(
                  "rounded px-1 py-0.5 text-[9px] font-extrabold transition-colors",
                  slippage === s ? "bg-ink text-white" : "bg-white text-neutral-400"
                )}
              >
                {s}%
              </button>
            ))}
          </span>
        </div>
      </div>

      <div className="mt-3 flex items-center gap-2">
        <button
          type="button"
          onClick={() => setUseExits((v) => !v)}
          role="switch"
          aria-checked={useExits}
          aria-label="Attach exit rules"
          className={cn(
            "relative h-5 w-9 shrink-0 rounded-full transition-colors",
            useExits ? "bg-gain" : "bg-neutral-200"
          )}
        >
          <span
            className={cn(
              "absolute top-0.5 h-4 w-4 rounded-full bg-white shadow transition-transform",
              useExits ? "translate-x-[18px]" : "translate-x-0.5"
            )}
          />
        </button>
        <span className="text-[11px] font-bold text-neutral-500">Attach my TP / SL</span>
        {useExits && (
          <span className="ml-auto flex items-center gap-1">
            <input
              type="number"
              value={tp}
              onChange={(e) => setTp(e.target.value)}
              className="w-[52px] rounded-lg border border-neutral-200 bg-white px-1.5 py-1 text-[10px] font-extrabold outline-none focus:border-ink"
              aria-label="Take profit percent"
            />
            <span className="text-[9px] font-extrabold text-neutral-400">% TP</span>
            <input
              type="number"
              value={sl}
              onChange={(e) => setSl(e.target.value)}
              className="w-[52px] rounded-lg border border-neutral-200 bg-white px-1.5 py-1 text-[10px] font-extrabold outline-none focus:border-ink"
              aria-label="Stop loss percent"
            />
            <span className="text-[9px] font-extrabold text-neutral-400">%
              SL</span>
          </span>
        )}
      </div>

      <button
        type="button"
        onClick={place}
        className={cn(
          "mt-3 w-full rounded-full py-2.5 text-[12px] font-extrabold transition-all active:scale-[0.98]",
          side === "Sell" ? "bg-loss text-white hover:brightness-110" : "bg-ink text-white hover:bg-neutral-700"
        )}
      >
        {side === "Buy" ? `Buy ${coin}` : side === "Sell" ? `Sell ${coin}` : `Swap to ${coin}`}
      </button>
      <p className="mt-2 text-center text-[9.5px] font-medium leading-relaxed text-neutral-400">
        Independent DEX trade — not linked to any copy strategy.
        {useExits ? ` Exit at +${tp || 0}% / -${sl || 0}%.` : ""}
      </p>
    </Card>
  );
}

function TradePage({ nav }: { nav: Nav }) {
  const t = TRADERS.kaito;
  const { v, dir, n } = useTick(168.4, 0.4);
  const [liked, setLiked] = useState(false);

  return (
    <div className="fadeup grid gap-5 lg:grid-cols-[minmax(0,1fr)_340px]">
      <div className="flex flex-col gap-5">
        <Card>
          <div className="flex items-center gap-2.5">
            <button
              type="button"
              onClick={() => nav("profile")}
              className="flex min-w-0 flex-1 items-center gap-2.5 text-left"
            >
              <Avatar src={t.img} name={t.name} size={44} />
              <div className="min-w-0">
                <div className="flex items-center gap-1">
                  <span className="text-[14px] font-extrabold">{t.name}</span>
                  <Verified className="h-3.5 w-3.5" />
                </div>
                <div className="text-[11px] font-medium text-neutral-400">2m ago · Trade update</div>
              </div>
            </button>
            <FollowButton className="px-4 py-2 text-[11px]" />
            <button type="button" className="text-neutral-400 hover:text-ink" aria-label="Share trade">
              <IcShare className="h-4.5 w-4.5" />
            </button>
            <button type="button" className="text-neutral-400 hover:text-ink" aria-label="More options">
              <IcMore className="h-4.5 w-4.5" />
            </button>
          </div>

          <div className="mt-4 flex flex-wrap items-center gap-2.5">
            <span className="rounded-full bg-gain px-2.5 py-1 text-[10px] font-extrabold tracking-wide text-white">
              BUY
            </span>
            <CoinBadge sym="SOL" className="h-7 w-7 text-[10px]" />
            <span
              key={n}
              className={cn(
                "font-display text-[19px] font-extrabold tracking-tight",
                dir === 1 && "tick-up",
                dir === -1 && "tick-down"
              )}
            >
              ${v.toFixed(2)}
            </span>
            <span className="text-[12px] font-extrabold text-gain">+3.2%</span>
          </div>

          <div className="mt-4 grid grid-cols-2 gap-x-4 gap-y-3 rounded-2xl bg-paper p-4 sm:grid-cols-4">
            {[
              { l: "Position Size", v: "$50,000" },
              { l: "Entry", v: "$168.40" },
              { l: "Target", v: "$210.00" },
              { l: "Stop", v: "$154.00" },
            ].map((c) => (
              <div key={c.l}>
                <div className="text-[9px] font-bold uppercase tracking-wider text-neutral-400">{c.l}</div>
                <div className="mt-0.5 text-[14px] font-extrabold">{c.v}</div>
              </div>
            ))}
          </div>

          <div className="mt-5">
            <div className="mb-2 flex items-center gap-1.5">
              <IcDoc className="h-4 w-4 text-neutral-500" />
              <span className="text-[14px] font-extrabold">My Thesis</span>
            </div>
            <p className="text-[13px] font-medium leading-relaxed text-neutral-600">
              SOL is showing strong momentum after the recent ecosystem updates, with rising DEX volume and fresh
              inflows from on-chain smart money. I&rsquo;m accumulating here for a potential continuation to $210.
            </p>
          </div>

          <div className="mt-5">
            <div className="mb-3 flex items-center gap-1.5">
              <IcDoc className="h-4 w-4 text-neutral-500" />
              <span className="text-[14px] font-extrabold">Trade Update</span>
            </div>
            <div className="relative flex flex-col gap-4 pl-5">
              <span className="absolute bottom-2 left-[3.5px] top-2 w-px bg-neutral-200" />
              <div className="relative">
                <span className="absolute -left-5 top-1 h-2 w-2 rounded-full bg-gain" />
                <div className="text-[12px] font-extrabold leading-tight">Bought 2,500 SOL at $168.40</div>
                <div className="text-[10px] font-medium text-neutral-400">2m ago</div>
              </div>
              <div className="relative">
                <span className="absolute -left-5 top-1 h-2 w-2 rounded-full bg-neutral-300" />
                <div className="text-[12px] font-bold text-neutral-600">Target: $210.00</div>
              </div>
              <div className="relative">
                <span className="absolute -left-5 top-1 h-2 w-2 rounded-full bg-neutral-300" />
                <div className="text-[12px] font-bold text-neutral-600">Stop: $154.00</div>
              </div>
            </div>
          </div>

          <div className="mt-5 flex items-center gap-5 border-t border-neutral-100 pt-4 text-[12px] font-bold text-neutral-500">
            <button
              type="button"
              onClick={() => setLiked((x) => !x)}
              className={cn("flex items-center gap-1.5 transition-colors", liked ? "text-loss" : "hover:text-ink")}
            >
              <IcHeart className={cn("h-4 w-4", liked && "fill-current")} /> {342 + (liked ? 1 : 0)}
            </button>
            <button type="button" className="flex items-center gap-1.5 hover:text-ink">
              <IcChat className="h-4 w-4" /> 56
            </button>
            <button type="button" className="flex items-center gap-1.5 hover:text-ink">
              <IcRep className="h-4 w-4" /> 34
            </button>
            <button type="button" className="ml-auto text-neutral-400 hover:text-ink" aria-label="Save trade">
              <IcBookmark className="h-4 w-4" />
            </button>
          </div>
        </Card>

        <Card>
          <SectionHead title="Comments" action="56 replies" />
          <div className="mt-3 flex items-center gap-2.5">
            <Avatar src={TRADERS.macro.img} name="you" size={32} />
            <input
              placeholder="Add a comment…"
              className="h-10 w-full rounded-full bg-paper px-4 text-[12px] font-medium outline-none placeholder:text-neutral-400 focus:ring-1 focus:ring-neutral-300"
            />
            <button
              type="button"
              className="shrink-0 rounded-full bg-ink px-4 py-2.5 text-[11px] font-extrabold text-white transition-colors hover:bg-neutral-700"
            >
              Post
            </button>
          </div>
          <div className="mt-4 flex flex-col divide-y divide-neutral-100">
            {COMMENTS.map((c) => (
              <div key={c.txt} className="flex gap-2.5 py-3">
                <Avatar src={c.t.img} name={c.t.name} size={30} />
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-[11px] font-extrabold">{c.t.name}</span>
                    <Verified className="h-3 w-3" />
                    <span className="text-[9px] font-medium text-neutral-400">{c.time}</span>
                  </div>
                  <p className="mt-0.5 text-[11px] font-medium leading-snug text-neutral-600">{c.txt}</p>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>

      <aside className="flex flex-col gap-5">
        <TradeTicket />
        <Card className="p-5">
          <SectionHead title="All trades" action="View feed" onAction={() => nav("home")} />
          <div className="mt-2 flex flex-col gap-3">
            {NOTIFS.filter((x) => ["buy", "sell", "long"].includes(x.kind)).slice(0, 3).map((nt) => {
              const meta = KIND_META[nt.kind];
              const tr = nt.trader ? TRADERS[nt.trader] : null;
              return (
                <div key={nt.id} className="flex items-center gap-2.5">
                  {tr && <Avatar src={tr.img} name={tr.name} size={30} />}
                  <p className="min-w-0 flex-1 text-[11px] font-medium leading-snug text-neutral-700">{nt.text}</p>
                  <span className={cn("flex h-6 w-6 shrink-0 items-center justify-center rounded-full", meta.cls)}>
                    <meta.Icon className="h-3 w-3" />
                  </span>
                </div>
              );
            })}
          </div>
        </Card>
        <Card className="p-5">
          <SectionHead title="Copy with your exits" />
          <p className="mt-1 text-[11px] font-medium leading-relaxed text-neutral-500">
            Let Tape execute OxKaito&rsquo;s entries at your size, then close on your TP, SL or trailing stop — even
            if he keeps holding.
          </p>
          <div className="mt-3 flex flex-wrap gap-1.5">
            <span className="rounded-md bg-gain/10 px-1.5 py-1 text-[9.5px] font-extrabold text-[#0b6b3a]">
              Allocation
            </span>
            <span className="rounded-md bg-gain/10 px-1.5 py-1 text-[9.5px] font-extrabold text-[#0b6b3a]">
              TP / SL
            </span>
            <span className="rounded-md bg-sky-100 px-1.5 py-1 text-[9.5px] font-extrabold text-sky-700">
              Trailing stop
            </span>
            <span className="rounded-md bg-neutral-100 px-1.5 py-1 text-[9.5px] font-extrabold text-neutral-500">
              Max investment
            </span>
          </div>
          <CopyButton
            traderId="kaito"
            label="Set up copy"
            className="mt-3 w-full justify-center rounded-full bg-gain py-2.5 !text-ink hover:!bg-gain/80"
          />
        </Card>
        <TrendingCard nav={nav} />
      </aside>
    </div>
  );
}

/* ================= notifications ================= */

function NotificationsPage({ nav }: { nav: Nav }) {
  const [tab, setTab] = useState("All");
  const filtered = NOTIFS.filter((nt) =>
    tab === "All"
      ? true
      : tab === "Trades"
        ? ["buy", "sell", "long"].includes(nt.kind)
        : tab === "Follows"
          ? nt.kind === "follow"
          : nt.kind === "mention"
  );
  const days = (["Today", "Yesterday"] as const).filter((d) => filtered.some((x) => x.day === d));

  return (
    <div className="fadeup mx-auto flex max-w-[820px] flex-col gap-5">
      <div className="flex items-center justify-between">
        <h1 className="font-display text-[28px] font-extrabold tracking-tight">Notifications</h1>
        <button
          type="button"
          onClick={() => nav("profile")}
          className="rounded-full border border-neutral-200 bg-white px-3.5 py-2 text-[11px] font-bold text-neutral-500 transition-colors hover:text-ink"
        >
          Notification settings
        </button>
      </div>

      <TabPills tabs={["All", "Trades", "Follows", "Mentions"]} active={tab} onChange={setTab} />

      {days.map((d) => (
        <Card key={d}>
          <div className="mb-2 text-[10px] font-extrabold uppercase tracking-[0.14em] text-neutral-400">{d}</div>
          <div className="flex flex-col divide-y divide-neutral-100">
            {filtered
              .filter((x) => x.day === d)
              .map((nt) => {
                const meta = KIND_META[nt.kind];
                const t = nt.trader ? TRADERS[nt.trader] : null;
                return (
                  <div key={nt.id} className="flex items-center gap-3 py-3">
                    {t ? (
                      <Avatar src={t.img} name={t.name} size={34} />
                    ) : (
                      <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-ink text-white">
                        <IcUserPlus className="h-4 w-4" />
                      </span>
                    )}
                    <span className={cn("flex h-8 w-8 shrink-0 items-center justify-center rounded-full", meta.cls)}>
                      <meta.Icon className="h-4 w-4" />
                    </span>
                    <p className="min-w-0 flex-1 text-[12px] font-medium leading-snug text-neutral-700">{nt.text}</p>
                    <span className="shrink-0 text-[10px] font-semibold text-neutral-400">{nt.time}</span>
                  </div>
                );
              })}
          </div>
        </Card>
      ))}
      {filtered.length === 0 && (
        <Card>
          <div className="py-6 text-center text-[12px] font-medium text-neutral-400">Nothing here yet.</div>
        </Card>
      )}
    </div>
  );
}

/* ================= wallet ================= */

function WalletPage({ nav }: { nav: Nav }) {
  const { v, dir, n } = useTick(12480.2, 10);
  const [panel, setPanel] = useState<"deposit" | "withdraw" | null>(null);
  const [copied, setCopied] = useState(false);

  return (
    <div className="fadeup grid gap-5 lg:grid-cols-[minmax(0,1fr)_340px]">
      <div className="flex flex-col gap-5">
        <Card>
          <div className="flex flex-wrap items-start justify-between gap-4">
            <div>
              <div className="text-[10px] font-bold uppercase tracking-[0.16em] text-neutral-400">Wallet balance</div>
              <div
                key={n}
                className={cn(
                  "mt-1 inline-flex items-center gap-2 px-0.5",
                  dir === 1 && "tick-up",
                  dir === -1 && "tick-down"
                )}
              >
                <span className="font-display text-[30px] font-extrabold tracking-tight">
                  ${v.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                </span>
                <IcEye className="h-4 w-4 text-neutral-400" />
              </div>
              <div className="text-[11px] font-extrabold text-gain">+8.24% (24H)</div>
            </div>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setPanel("deposit")}
                className="rounded-full bg-ink px-5 py-2.5 text-[12px] font-extrabold text-white transition-all hover:bg-neutral-700 active:scale-95"
              >
                Deposit
              </button>
              <button
                type="button"
                onClick={() => setPanel("withdraw")}
                className="rounded-full border border-neutral-300 bg-white px-5 py-2.5 text-[12px] font-extrabold text-ink transition-all hover:border-ink active:scale-95"
              >
                Withdraw
              </button>
            </div>
          </div>

          <div className="mt-5 flex h-2.5 overflow-hidden rounded-full">
            <span className="w-[48%] bg-gain" />
            <span className="w-[33%] bg-ink" />
            <span className="w-[19%] bg-neutral-300" />
          </div>
          <div className="mt-2 flex flex-wrap gap-4 text-[10px] font-bold text-neutral-500">
            <span className="flex items-center gap-1.5">
              <span className="h-2 w-2 rounded-full bg-gain" /> SOL 48%
            </span>
            <span className="flex items-center gap-1.5">
              <span className="h-2 w-2 rounded-full bg-ink" /> BTC 33%
            </span>
            <span className="flex items-center gap-1.5">
              <span className="h-2 w-2 rounded-full bg-neutral-300" /> ETH 19%
            </span>
          </div>

          {panel && (
            <div className="mt-4 rounded-2xl bg-paper p-4">
              <div className="text-[11px] font-extrabold">
                {panel === "deposit" ? "Deposit USDC on Solana" : "Withdraw to an external wallet"}
              </div>
              <p className="mt-1 text-[11px] font-medium text-neutral-500">
                {panel === "deposit"
                  ? "Send only USDC (SPL) to this address. Funds appear after 1 confirmation."
                  : "Paste a destination address. Withdrawals are reviewed and settle in ~2 minutes."}
              </p>
              <div className="mt-2.5 flex items-center gap-2">
                <code className="min-w-0 flex-1 truncate rounded-lg bg-white px-3 py-2 font-mono text-[11px] font-bold text-neutral-600">
                  {panel === "deposit" ? "7xKqTape4mNc9dLp2sVf8Ro3uYh6Wa1" : "0x4f…9c2d"}
                </code>
                <button
                  type="button"
                  onClick={() => {
                    setCopied(true);
                    window.setTimeout(() => setCopied(false), 1400);
                  }}
                  className="shrink-0 rounded-lg bg-ink px-3 py-2 text-[10px] font-extrabold text-white"
                >
                  {copied ? "Copied" : "Copy"}
                </button>
                <button
                  type="button"
                  onClick={() => setPanel(null)}
                  className="shrink-0 text-[10px] font-bold text-neutral-400 hover:text-ink"
                >
                  Close
                </button>
              </div>
            </div>
          )}
        </Card>

        <Card>
          <SectionHead title="Holdings" action="Buy more" onAction={() => nav("discover")} />
          <div className="mt-2 flex flex-col divide-y divide-neutral-100">
            {POSITIONS.map((p) => (
              <div key={p.sym} className="flex items-center gap-3 py-3">
                <CoinBadge sym={p.sym} className="h-10 w-10 text-[13px]" />
                <div>
                  <div className="text-[13px] font-extrabold leading-tight">{p.sym}</div>
                  <div className="text-[10px] font-medium text-neutral-400">{p.pct} of portfolio</div>
                </div>
                <div className="ml-auto text-right">
                  <div className="text-[13px] font-extrabold leading-tight">{p.val}</div>
                  <div className="text-[10px] font-extrabold text-gain">{p.pnl}</div>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>

      <aside className="flex flex-col gap-5">
        <Card className="p-5">
          <SectionHead title="Recent activity" action="View all" onAction={() => nav("notifications")} />
          <div className="mt-2 flex flex-col divide-y divide-neutral-100">
            {NOTIFS.filter((x) => ["buy", "sell", "long"].includes(x.kind)).map((nt) => {
              const meta = KIND_META[nt.kind];
              return (
                <div key={nt.id} className="flex items-center gap-2.5 py-3">
                  <span className={cn("flex h-7 w-7 shrink-0 items-center justify-center rounded-full", meta.cls)}>
                    <meta.Icon className="h-3.5 w-3.5" />
                  </span>
                  <p className="min-w-0 flex-1 text-[11px] font-medium leading-snug text-neutral-700">{nt.text}</p>
                  <span className="shrink-0 text-[9px] font-semibold text-neutral-400">{nt.time}</span>
                </div>
              );
            })}
          </div>
        </Card>
        <TrendingCard nav={nav} />
      </aside>
    </div>
  );
}

/* ================= shell ================= */

export function AppShell({ onExit }: { onExit: () => void }) {
  const [page, setPage] = useState<Page>("home");
  const [traderId, setTraderId] = useState("kaito");
  const market = useMarket();
  const sourcesMode = market.mode;

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, [page, traderId]);

  const nav: Nav = (p, t) => {
    if (t) setTraderId(t);
    setPage(p);
  };

  return (
    <div className="min-h-screen bg-paper">
      {/* top bar — the phone's nav, scaled for the web */}
      <div className="sticky top-0 z-40 border-b border-neutral-200/80 bg-paper/85 backdrop-blur">
        <div className="mx-auto flex h-16 max-w-[1240px] items-center gap-2 px-4 md:gap-4 md:px-6">
          <button type="button" onClick={() => nav("home")} className="flex shrink-0 items-center gap-2.5">
            <LogoMark className="h-8 w-8 text-ink" />
            <span className="hidden font-display text-[20px] font-black tracking-[-0.03em] sm:block">TAPE</span>
          </button>

          <nav className="ml-1 hidden items-center gap-0.5 md:flex">
            {NAV_ITEMS.map(({ id, label, Icon }) => (
              <button
                key={id}
                type="button"
                onClick={() => nav(id)}
                className={cn(
                  "flex items-center gap-2 rounded-full px-3.5 py-2 text-[12px] font-extrabold transition-colors",
                  page === id ? "bg-ink text-white" : "text-neutral-500 hover:bg-white hover:text-ink"
                )}
              >
                <Icon className="h-4 w-4" />
                {label}
              </button>
            ))}
          </nav>

          <div className="ml-auto flex items-center gap-2 md:gap-3">
            <button
              type="button"
              onClick={() => nav("sources")}
              className="hidden items-center gap-1.5 rounded-full border border-neutral-200 bg-white px-3 py-1.5 text-[10px] font-extrabold text-neutral-500 transition-colors hover:border-neutral-400 hover:text-ink sm:inline-flex"
              title="Where the market data comes from"
            >
              <span className={cn("h-1.5 w-1.5 rounded-full", sourcesMode === "demo" ? "bg-amber-400" : "bg-gain")} />
              {sourcesMode === "demo" ? "Demo data" : sourcesMode === "live" ? "Live" : "Partial live"}
            </button>
            <button
              type="button"
              onClick={() => nav("discover")}
              className="flex h-9 w-9 items-center justify-center rounded-full border border-neutral-200 bg-white text-neutral-600 transition-colors hover:text-ink"
              aria-label="Search"
            >
              <IcSearch className="h-4 w-4" />
            </button>
            <button
              type="button"
              onClick={() => nav("notifications")}
              className="relative flex h-9 w-9 items-center justify-center rounded-full border border-neutral-200 bg-white text-neutral-700 transition-colors hover:text-ink"
              aria-label="Notifications"
            >
              <IcBell className="h-4 w-4" />
              {page !== "notifications" && (
                <span className="absolute right-1.5 top-1.5 h-2 w-2 rounded-full bg-gain ring-2 ring-white" />
              )}
            </button>
            <button
              type="button"
              onClick={() => nav("profile")}
              className={cn(
                "rounded-full transition-all",
                page === "profile" ? "ring-2 ring-ink ring-offset-2 ring-offset-paper" : "hover:opacity-80"
              )}
              aria-label="Your profile"
            >
              <Avatar src={TRADERS.kaito.img} name="you" size={34} />
            </button>
            <button
              type="button"
              onClick={onExit}
              className="hidden rounded-full border border-neutral-200 bg-white px-3 py-1.5 text-[11px] font-extrabold text-neutral-500 transition-colors hover:border-neutral-400 hover:text-ink sm:block"
            >
              Sign out
            </button>
          </div>
        </div>
      </div>

      <main className="mx-auto max-w-[1240px] px-4 pb-28 pt-6 md:px-6 md:pb-12">
        {page === "home" && <HomePage nav={nav} />}
        {page === "discover" && <DiscoverPage nav={nav} />}
        {page === "trade" && <TradePage nav={nav} />}
        {page === "copy" && <CopiesPage onDiscover={() => nav("discover")} />}
        {page === "wallet" && <WalletPage nav={nav} />}
        {page === "profile" && <ProfilePage traderId={traderId} nav={nav} />}
        {page === "notifications" && <NotificationsPage nav={nav} />}
        {page === "sources" && <DataSourcesPage onFindTraders={() => nav("discover")} />}
      </main>

      {/* mobile nav — identical to the phone screens */}
      <div className="fixed inset-x-0 bottom-0 z-40 border-t border-neutral-200 bg-white/95 backdrop-blur md:hidden">
        <div className="mx-auto flex max-w-[520px] items-center justify-around px-2 pb-2 pt-2">
          {NAV_ITEMS.map(({ id, label, Icon }) => (
            <button
              key={id}
              type="button"
              onClick={() => nav(id)}
              className={cn(
                "flex flex-col items-center gap-[3px] px-2 py-1 transition-colors",
                page === id ? "text-ink" : "text-neutral-300 hover:text-neutral-500"
              )}
            >
              <Icon className="h-[21px] w-[21px]" />
              <span className="text-[9px] font-bold">{label}</span>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}

export default AppShell;
