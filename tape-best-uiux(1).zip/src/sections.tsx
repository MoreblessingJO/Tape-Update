import { cn } from "./utils/cn";
import { LEADERBOARD, QUOTES, TICKER } from "./data";
import { Avatar, CountUp, FollowButton, Kicker, Reveal, Sparkline } from "./ui";
import {
  CoinBadge,
  IcApple,
  IcBolt,
  IcCopy,
  IcDoc,
  IcPlay,
  IcShield,
  IcTrendUp,
  IcWallet,
  LogoMark,
  Verified,
} from "./icons";

/* ================= live ticker ================= */

function Tri({ up }: { up: boolean }) {
  return (
    <svg
      className={cn("h-2 w-2 shrink-0", up ? "" : "rotate-180")}
      viewBox="0 0 10 10"
      fill="currentColor"
      aria-hidden
    >
      <path d="M5 1.2 9.3 8.4H.7Z" />
    </svg>
  );
}

export function Ticker() {
  const items = [...TICKER, ...TICKER];
  return (
    <div className="marquee relative z-30 overflow-hidden border-b border-neutral-800/60 bg-ink py-2.5">
      <div className="marquee-track flex w-max items-center">
        {items.map((t, i) => (
          <span key={i} className="flex items-center gap-2 whitespace-nowrap px-6 text-[11px] font-bold tracking-wide">
            <span className="text-neutral-500">{t.sym}</span>
            <span className="text-white/90">{t.price}</span>
            <span className={cn("flex items-center gap-1", t.up ? "text-gain" : "text-rose-400")}>
              <Tri up={t.up} />
              {t.chg}
            </span>
            <span className="pl-4 text-neutral-700">•</span>
          </span>
        ))}
      </div>
    </div>
  );
}

/* ================= stats band ================= */

const STATS = [
  { to: 2.4, decimals: 1, suffix: "M+", label: "Followers on platform" },
  { to: 1.8, decimals: 1, prefix: "$", suffix: "B", label: "Traded volume tracked (90D)" },
  { to: 18240, label: "Verified pro traders" },
  { to: 142, suffix: "K", label: "Alerts delivered daily" },
];

export function StatsBand() {
  return (
    <section className="relative overflow-hidden bg-ink text-white">
      <div className="noise pointer-events-none absolute inset-0 opacity-[0.07]" />
      <div className="absolute -top-32 left-1/2 h-72 w-[720px] -translate-x-1/2 rounded-full bg-gain/15 blur-[120px]" />
      <div className="relative mx-auto grid max-w-[1400px] grid-cols-2 gap-x-6 gap-y-12 px-6 py-16 md:grid-cols-4 md:py-20">
        {STATS.map((s, i) => (
          <Reveal key={s.label} delay={i * 0.08} className="text-center md:text-left">
            <div className="font-display text-[40px] font-black leading-none tracking-tight md:text-[52px]">
              <CountUp to={s.to} decimals={s.decimals ?? 0} prefix={s.prefix ?? ""} suffix={s.suffix ?? ""} />
              <span className="text-gain">.</span>
            </div>
            <div className="mt-3 text-[11px] font-bold uppercase tracking-[0.16em] text-neutral-500">{s.label}</div>
          </Reveal>
        ))}
      </div>
    </section>
  );
}

/* ================= features (sticky two-column) ================= */

const FEATURES = [
  {
    n: "01",
    Icon: IcBolt,
    title: "Real-time trade alerts",
    copy: "The second a trader you follow opens or closes a position, the ping lands in your feed — token, size, and PnL context attached. No stale screenshots, no delay.",
    visual: (
      <div className="flex flex-col gap-2">
        <div className="flex items-center gap-2 rounded-xl bg-white/10 p-2.5">
          <span className="rounded-md bg-gain/20 px-1.5 py-0.5 text-[9px] font-extrabold text-gain">BUY</span>
          <span className="text-[11px] font-extrabold">SOL · 2,500</span>
          <span className="ml-auto text-[9px] font-bold text-gain">+3.2%</span>
        </div>
        <div className="flex items-center gap-2 rounded-xl bg-white/10 p-2.5">
          <span className="rounded-md bg-rose-400/20 px-1.5 py-0.5 text-[9px] font-extrabold text-rose-300">SELL</span>
          <span className="text-[11px] font-extrabold">ETH · 10.2</span>
          <span className="ml-auto text-[9px] font-bold text-rose-300">-0.8%</span>
        </div>
        <div className="px-1 text-right text-[9px] font-bold text-white/40">just now · 2 more</div>
      </div>
    ),
  },
  {
    n: "02",
    Icon: IcDoc,
    title: "Thesis on every position",
    copy: "Naked signals are how accounts die. Every trade on Tape ships with the trader's reasoning, target, and stop — you read the trade like a research note before deciding.",
    visual: (
      <div className="rounded-xl bg-white/10 p-3">
        <div className="text-[9px] font-extrabold uppercase tracking-wider text-gain">Thesis · SOL long</div>
        <div className="mt-2 space-y-1.5">
          {[92, 100, 78, 96, 60].map((w, i) => (
            <div key={i} className="h-1.5 rounded-full bg-white/25" style={{ width: `${w}%` }} />
          ))}
        </div>
        <div className="mt-3 flex gap-2 text-[9px] font-bold">
          <span className="rounded-md bg-gain/20 px-1.5 py-0.5 text-gain">Target $210</span>
          <span className="rounded-md bg-rose-400/20 px-1.5 py-0.5 text-rose-300">Stop $154</span>
        </div>
      </div>
    ),
  },
  {
    n: "03",
    Icon: IcWallet,
    title: "On-chain wallet tracking",
    copy: "Follow the wallets, not just the accounts. Tape indexes on-chain movement so you can watch smart money accumulate before it ever shows up on your chart.",
    visual: (
      <div className="flex flex-col gap-2">
        <div className="flex items-center gap-2 rounded-xl bg-white/10 p-2.5">
          <span className="font-mono text-[10px] font-bold">0x4f…9c2d</span>
          <span className="ml-auto flex items-center gap-1 text-[9px] font-extrabold text-gain">
            <IcTrendUp className="h-3 w-3" /> +1,203%
          </span>
        </div>
        <div className="flex items-center gap-2 rounded-xl bg-white/10 p-2.5">
          <CoinBadge sym="TAPE" className="h-5 w-5 text-[8px]" />
          <span className="text-[10px] font-bold">bought 1.5M TAPE</span>
          <span className="ml-auto text-[9px] font-bold text-white/40">2m</span>
        </div>
      </div>
    ),
  },
  {
    n: "04",
    Icon: IcCopy,
    title: "Copy with your own exits",
    copy: "Mirror any trader with your own max investment, take profit, stop loss and trailing stop. Tape exits on your rules — even while the original trader is still holding.",
    visual: (
      <div className="flex flex-col gap-1.5">
        <div className="grid grid-cols-2 gap-1.5">
          {[
            { l: "Allocation", v: "$100", c: "" },
            { l: "Max cap", v: "$100", c: "" },
            { l: "Take profit", v: "+100%", c: "text-gain" },
            { l: "Stop loss", v: "-20%", c: "text-rose-300" },
          ].map((x) => (
            <div key={x.l} className="rounded-lg bg-white/10 p-2">
              <div className="text-[8px] font-bold uppercase tracking-wider text-white/40">{x.l}</div>
              <div className={cn("text-[11px] font-extrabold", x.c || "text-white")}>{x.v}</div>
            </div>
          ))}
        </div>
        <div className="flex items-center justify-between rounded-lg bg-white/10 px-2 py-1.5">
          <span className="text-[9px] font-bold uppercase tracking-wider text-white/40">Trailing stop</span>
          <span className="text-[10px] font-extrabold text-sky-300">15%</span>
        </div>
        <div className="flex items-center gap-1.5 rounded-lg bg-gain/15 px-2 py-1.5 text-[9px] font-extrabold text-gain">
          <IcCopy className="h-3 w-3" /> Exits independently, trader still holding
        </div>
      </div>
    ),
  },
];

export function Features() {
  return (
    <section id="features" className="mx-auto max-w-[1400px] px-6 py-24 md:py-32">
      <div className="grid gap-14 lg:grid-cols-[minmax(0,5fr)_minmax(0,7fr)] lg:gap-20">
        <div className="lg:sticky lg:top-16 lg:self-start">
          <Reveal>
            <Kicker>Why Tape</Kicker>
            <h2 className="mt-6 font-display text-[clamp(2rem,4vw,3.4rem)] font-black leading-[1.02] tracking-[-0.03em]">
              See the move before it&rsquo;s obvious.
            </h2>
            <p className="mt-5 max-w-md text-[15px] leading-relaxed text-neutral-500">
              Tape turns the best crypto traders into a live feed of receipts — every entry, exit, and the thinking
              behind it. You&rsquo;re not guessing at candles anymore; you&rsquo;re reading the book the market is
              actually trading off.
            </p>
            <div className="mt-8 flex items-center gap-3 rounded-2xl border border-neutral-200 bg-white p-4">
              <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-ink text-white">
                <IcShield className="h-5 w-5" />
              </span>
              <div>
                <div className="text-[13px] font-extrabold">Every follower vetted</div>
                <div className="text-[12px] font-medium text-neutral-500">
                  90-day PnL, win rate, and max drawdown — checked before the follow button works.
                </div>
              </div>
            </div>
          </Reveal>
        </div>

        <div className="flex flex-col gap-6">
          {FEATURES.map((f, i) => (
            <Reveal key={f.n} delay={i * 0.06}>
              <article className="group flex flex-col gap-6 rounded-3xl border border-neutral-200 bg-white p-6 transition-all duration-300 hover:-translate-y-1.5 hover:border-neutral-300 hover:shadow-[0_30px_60px_-30px_rgba(12,16,28,0.35)] sm:flex-row sm:p-7">
                <div className="relative order-2 w-full shrink-0 overflow-hidden rounded-2xl bg-ink p-4 sm:order-1 sm:w-[240px]">
                  <div className="noise pointer-events-none absolute inset-0 opacity-10" />
                  <div className="absolute -right-10 -top-10 h-32 w-32 rounded-full bg-gain/20 blur-2xl transition-all duration-500 group-hover:bg-gain/30" />
                  <div className="relative">{f.visual}</div>
                </div>
                <div className="order-1 sm:order-2">
                  <div className="flex items-center gap-3">
                    <span className="font-display text-[13px] font-black text-gain">{f.n}</span>
                    <f.Icon className="h-4 w-4 text-neutral-400" />
                  </div>
                  <h3 className="mt-2 font-display text-[22px] font-extrabold tracking-tight">{f.title}</h3>
                  <p className="mt-2.5 text-[14px] leading-relaxed text-neutral-500">{f.copy}</p>
                </div>
              </article>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ================= leaderboard ================= */

const ROW_SPARKS = [
  [2, 5, 4, 8, 7, 12, 10, 16],
  [3, 4, 7, 5, 9, 8, 12, 14],
  [2, 6, 3, 5, 8, 6, 10, 11],
  [1, 4, 3, 6, 5, 9, 8, 12],
  [2, 3, 5, 4, 6, 8, 7, 10],
  [3, 5, 4, 3, 6, 5, 8, 9],
];

export function Leaderboard() {
  return (
    <section id="traders" className="border-y border-neutral-200 bg-white">
      <div className="mx-auto max-w-[1400px] px-6 py-24 md:py-28">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <Reveal>
            <Kicker>The leaderboard</Kicker>
            <h2 className="mt-6 font-display text-[clamp(2rem,4vw,3.4rem)] font-black leading-[1.02] tracking-[-0.03em]">
              Follow the receipts.
            </h2>
            <p className="mt-4 max-w-lg text-[15px] leading-relaxed text-neutral-500">
              Ranked live by 90-day PnL on audited, on-chain verified accounts. No cherry-picked weeklies, no
              unaudited screenshots.
            </p>
          </Reveal>
          <Reveal delay={0.1} className="hidden md:block">
            <span className="inline-flex items-center gap-2 rounded-full border border-neutral-200 bg-paper px-4 py-2 text-[11px] font-bold text-neutral-500">
              <span className="relative flex h-2 w-2">
                <span className="ping-ring absolute h-full w-full rounded-full bg-gain" />
                <span className="relative h-2 w-2 rounded-full bg-gain" />
              </span>
              Updated every fill · live
            </span>
          </Reveal>
        </div>

        <Reveal delay={0.12} className="mt-12">
          <div className="overflow-x-auto rounded-3xl border border-neutral-200 bg-paper/60">
            <table className="w-full min-w-[760px] text-left">
              <thead>
                <tr className="border-b border-neutral-200 text-[10px] font-extrabold uppercase tracking-[0.16em] text-neutral-400">
                  <th className="px-6 py-4">#</th>
                  <th className="px-4 py-4">Trader</th>
                  <th className="px-4 py-4">Win rate</th>
                  <th className="px-4 py-4">90D PnL</th>
                  <th className="px-4 py-4">Tracked AUM</th>
                  <th className="px-4 py-4">90D curve</th>
                  <th className="px-6 py-4 text-right">Follow</th>
                </tr>
              </thead>
              <tbody>
                {LEADERBOARD.map((row, i) => (
                  <tr key={row.t.id} className="border-b border-neutral-200/70 transition-colors last:border-0 hover:bg-white">
                    <td className="px-6 py-4 font-display text-[15px] font-black text-neutral-300">
                      {String(row.rank).padStart(2, "0")}
                    </td>
                    <td className="px-4 py-4">
                      <div className="flex items-center gap-3">
                        <Avatar src={row.t.img} name={row.t.name} size={38} />
                        <div>
                          <div className="flex items-center gap-1.5">
                            <span className="text-[14px] font-extrabold">{row.t.name}</span>
                            <Verified className="h-3.5 w-3.5" />
                          </div>
                          <div className="font-mono text-[11px] font-medium text-neutral-400">{row.t.handle}</div>
                        </div>
                      </div>
                    </td>
                    <td className="px-4 py-4 text-[13px] font-bold text-neutral-600">{row.win}</td>
                    <td className="px-4 py-4 font-display text-[16px] font-black text-gain">{row.pnl}</td>
                    <td className="px-4 py-4 text-[13px] font-bold text-neutral-600">{row.aum}</td>
                    <td className="px-4 py-4">
                      <Sparkline points={ROW_SPARKS[i]} w={90} h={30} id={`lb-${i}`} delay={0.5 + i * 0.1} />
                    </td>
                    <td className="px-6 py-4 text-right">
                      <FollowButton label="Follow" className="px-4 py-2 text-[11px]" />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

/* ================= how it works ================= */

const STEPS = [
  {
    n: "01",
    title: "Find traders with receipts",
    copy: "Sort the leaderboard by 90-day PnL, win rate, and drawdown. If the track record doesn't check out, you don't follow it.",
  },
  {
    n: "02",
    title: "Follow the thesis, not the ticker",
    copy: "Every position ships with reasoning, a target, and a stop. You read each trade like a research note before you act on it.",
  },
  {
    n: "03",
    title: "Get pinged the second it prints",
    copy: "Buy, sell, size change — the alert lands before the candle does. Copy the position or just watch the pros work.",
  },
];

export function HowItWorks() {
  return (
    <section id="how" className="mx-auto max-w-[1400px] px-6 py-24 md:py-32">
      <Reveal>
        <Kicker>How it works</Kicker>
        <h2 className="mt-6 max-w-2xl font-display text-[clamp(2rem,4vw,3.4rem)] font-black leading-[1.02] tracking-[-0.03em]">
          From zero to front row in three steps.
        </h2>
      </Reveal>
      <div className="mt-14 grid gap-10 md:grid-cols-3 md:gap-8">
        {STEPS.map((s, i) => (
          <Reveal key={s.n} delay={i * 0.1}>
            <div className="group relative border-t-2 border-dashed border-neutral-300 pt-8 transition-colors duration-300 hover:border-ink">
              <span className="font-display text-[52px] font-black leading-none tracking-tight text-neutral-200 transition-colors duration-300 group-hover:text-ink">
                {s.n}
              </span>
              <h3 className="mt-4 font-display text-[19px] font-extrabold tracking-tight">{s.title}</h3>
              <p className="mt-2.5 max-w-xs text-[14px] leading-relaxed text-neutral-500">{s.copy}</p>
            </div>
          </Reveal>
        ))}
      </div>
    </section>
  );
}

/* ================= quotes / scattered postcards ================= */

export function Quotes() {
  const tilts = ["md:-rotate-2", "md:rotate-2 md:translate-y-4", "md:-rotate-1"];
  return (
    <section className="overflow-hidden border-y border-neutral-200 bg-white">
      <div className="mx-auto max-w-[1400px] px-6 py-24 md:py-32">
        <Reveal className="text-center">
          <Kicker className="mx-auto">Straight from the feed</Kicker>
          <h2 className="mt-6 font-display text-[clamp(2rem,4vw,3.4rem)] font-black leading-[1.02] tracking-[-0.03em]">
            Traders talk. Numbers back it up.
          </h2>
        </Reveal>
        <div className="mt-16 grid gap-8 md:grid-cols-3 md:gap-6">
          {QUOTES.map((q, i) => (
            <Reveal key={q.t.id} delay={i * 0.1}>
              <figure
                className={cn(
                  "flex h-full flex-col rounded-3xl border border-neutral-200 bg-paper p-7 shadow-[0_20px_40px_-28px_rgba(12,16,28,0.4)] transition-all duration-500 hover:rotate-0 hover:shadow-[0_30px_60px_-28px_rgba(12,16,28,0.5)]",
                  tilts[i]
                )}
              >
                <span className="font-display text-[44px] font-black leading-none text-gain">&ldquo;</span>
                <blockquote className="-mt-3 flex-1 text-[15px] font-medium leading-relaxed text-neutral-700">
                  {q.q}
                </blockquote>
                <figcaption className="mt-6 flex items-center gap-3 border-t border-neutral-200 pt-5">
                  <Avatar src={q.t.img} name={q.t.name} size={40} />
                  <div className="min-w-0">
                    <div className="flex items-center gap-1.5">
                      <span className="truncate text-[13px] font-extrabold">{q.t.name}</span>
                      <Verified className="h-3.5 w-3.5" />
                    </div>
                    <span className="mt-0.5 inline-block rounded-md bg-gain/10 px-1.5 py-0.5 text-[10px] font-extrabold text-gain">
                      {q.tag}
                    </span>
                  </div>
                </figcaption>
              </figure>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

/* ================= CTA ================= */

function StoreBadge({ store }: { store: "apple" | "play" }) {
  return (
    <a
      href="#top"
      className={cn(
        "group flex items-center gap-3 rounded-2xl px-6 py-3.5 transition-all duration-300 active:scale-95",
        store === "apple"
          ? "bg-white text-ink hover:bg-gain"
          : "border border-white/25 text-white hover:border-white hover:bg-white/10"
      )}
    >
      {store === "apple" ? <IcApple className="h-7 w-7" /> : <IcPlay className="h-6 w-6" />}
      <span className="text-left leading-tight">
        <span className="block text-[10px] font-bold uppercase tracking-wider opacity-60">
          {store === "apple" ? "Download on the" : "Get it on"}
        </span>
        <span className="block font-display text-[17px] font-extrabold">
          {store === "apple" ? "App Store" : "Google Play"}
        </span>
      </span>
    </a>
  );
}

export function CTASection({ onWebApp }: { onWebApp?: () => void }) {
  return (
    <section className="mx-auto max-w-[1400px] px-6 py-24 md:py-28">
      <Reveal>
        <div className="relative overflow-hidden rounded-[40px] bg-ink px-8 py-16 text-white md:px-16 md:py-24">
          <div className="absolute -right-32 -top-32 h-[420px] w-[420px] rounded-full bg-gain/20 blur-[110px]" />
          <div className="absolute -bottom-40 -left-24 h-[360px] w-[360px] rounded-full bg-sky-500/10 blur-[110px]" />
          <div className="noise pointer-events-none absolute inset-0 opacity-[0.08]" />
          <div className="relative grid items-center gap-10 lg:grid-cols-[minmax(0,7fr)_minmax(0,5fr)]">
            <div>
              <span className="inline-flex items-center gap-2 rounded-full border border-white/15 px-4 py-1.5 text-[11px] font-extrabold uppercase tracking-[0.18em] text-white/60">
                <span className="h-1.5 w-1.5 rounded-full bg-gain" />
                Free to follow
              </span>
              <h2 className="mt-6 font-display text-[clamp(2.4rem,5.4vw,4.4rem)] font-black leading-[0.98] tracking-[-0.03em]">
                Stop watching
                <br />
                from the outside.
              </h2>
              <p className="mt-5 max-w-md text-[15px] leading-relaxed text-white/60">
                Join 2.4M traders following the wallets, theses, and fills that actually move the market. Your
                first alert could be in sixty seconds.
              </p>
              <div className="mt-9 flex flex-wrap gap-3">
                <StoreBadge store="apple" />
                <StoreBadge store="play" />
              </div>
              <div className="mt-6 text-[12px] font-semibold text-white/40">
                Free to follow · Pro alerts from $9/mo · No card required
              </div>
              {onWebApp && (
                <button
                  type="button"
                  onClick={onWebApp}
                  className="mt-5 inline-flex items-center gap-2 text-[13px] font-extrabold text-gain transition-colors hover:text-white"
                >
                  Prefer the browser? Start trading on the web app
                  <span aria-hidden>→</span>
                </button>
              )}
            </div>
            <div className="hidden lg:block">
              <div className="relative mx-auto w-[250px]">
                <div className="absolute inset-0 -z-10 scale-110 rounded-[40px] bg-gain/20 blur-3xl" />
                <div className="rotate-3 rounded-[36px] border border-white/10 bg-white/[0.06] p-5 backdrop-blur transition-transform duration-500 hover:rotate-0">
                  <div className="flex items-center gap-2.5">
                    <span className="rounded-md bg-gain px-2 py-1 text-[10px] font-extrabold text-ink">BUY</span>
                    <CoinBadge sym="SOL" className="h-7 w-7 text-[10px]" />
                    <span className="font-display text-[16px] font-extrabold text-white">$168.40</span>
                    <span className="text-[11px] font-extrabold text-gain">+3.2%</span>
                  </div>
                  <div className="mt-3 text-[11px] font-bold text-white/70">OxKaito · bought 2,500 SOL</div>
                  <div className="text-[10px] font-medium text-white/40">alert · 2m ago · 88.1K following</div>
                  <div className="mt-4">
                    <Sparkline points={[2, 4, 3, 7, 6, 9, 8, 12, 11, 15]} w={200} h={52} id="cta-spark" delay={0.6} />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Reveal>
    </section>
  );
}

/* ================= footer ================= */

const FOOT_COLS = [
  { h: "Product", links: ["Discover", "Trade alerts", "Wallets", "Token lists", "Mobile app"] },
  { h: "Company", links: ["About", "Careers", "Press kit", "Contact"] },
  { h: "Legal", links: ["Terms of service", "Privacy", "Disclosures"] },
];

export function Footer() {
  return (
    <footer className="border-t border-neutral-200 bg-paper">
      <div className="mx-auto max-w-[1400px] px-6 py-16">
        <div className="grid gap-12 md:grid-cols-[minmax(0,4fr)_minmax(0,8fr)]">
          <div>
            <div className="flex items-center gap-3">
              <LogoMark className="h-9 w-9 text-ink" />
              <span className="font-display text-[26px] font-black tracking-[-0.03em]">TAPE</span>
            </div>
            <p className="mt-4 max-w-xs text-[13px] leading-relaxed text-neutral-500">
              Follow traders. See trades. Trade smarter. Built for the front seat of the market.
            </p>
            <div className="mt-6 inline-flex items-center gap-2 rounded-full border border-neutral-200 bg-white px-4 py-2 text-[11px] font-bold text-neutral-500">
              <span className="relative flex h-2 w-2">
                <span className="ping-ring absolute h-full w-full rounded-full bg-gain" />
                <span className="relative h-2 w-2 rounded-full bg-gain" />
              </span>
              Markets open · feeds live
            </div>
          </div>
          <div className="grid grid-cols-2 gap-8 sm:grid-cols-3">
            {FOOT_COLS.map((c) => (
              <div key={c.h}>
                <div className="text-[11px] font-extrabold uppercase tracking-[0.16em] text-neutral-400">{c.h}</div>
                <ul className="mt-4 flex flex-col gap-2.5">
                  {c.links.map((l) => (
                    <li key={l}>
                      <a href="#top" className="text-[13px] font-semibold text-neutral-600 transition-colors hover:text-ink">
                        {l}
                      </a>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
        <div className="mt-14 flex flex-col gap-3 border-t border-neutral-200 pt-8 text-[12px] font-medium text-neutral-400 md:flex-row md:items-center md:justify-between">
          <span>© 2026 Tape Labs. All rights reserved.</span>
          <span>Crypto is volatile. Nothing on Tape is financial advice — never trade what you can&rsquo;t lose.</span>
        </div>
      </div>
    </footer>
  );
}
