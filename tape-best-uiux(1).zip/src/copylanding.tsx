import { useState } from "react";
import { cn } from "./utils/cn";
import { TRADERS } from "./data";
import { RANKED, SourceBadge, fmtPct } from "./copytrade";
import type { Period, Source } from "./copytrade";
import { Avatar, FollowButton, Kicker, Reveal, Sparkline } from "./ui";
import { CoinBadge, IcBolt, IcChevR, IcCopy, IcShield, IcSliders, IcTrendUp, Verified } from "./icons";

/* ================= copy engine explainer ================= */

const RULES = [
  { l: "Allocation", v: "$100", d: "per copied entry" },
  { l: "Take profit", v: "+100%", d: "auto-sell on target", g: true },
  { l: "Stop loss", v: "-20%", d: "risk capped", r: true },
  { l: "Trailing stop", v: "15%", d: "off the high", b: true },
];

export function CopyEngine({ onStart }: { onStart: () => void }) {
  return (
    <section id="copy" className="border-y border-neutral-200 bg-white">
      <div className="mx-auto max-w-[1400px] px-6 py-24 md:py-32">
        <div className="grid items-center gap-12 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.05fr)] lg:gap-16">
          <Reveal>
            <Kicker>Intelligent copy trading</Kicker>
            <h2 className="mt-6 font-display text-[clamp(2rem,4vw,3.4rem)] font-black leading-[1.02] tracking-[-0.03em]">
              Copy the trader.
              <br />
              Own the exit.
            </h2>
            <p className="mt-5 max-w-lg text-[15px] leading-relaxed text-neutral-500">
              Tape tracks live trades across <strong className="font-bold text-ink">Tape</strong>,{" "}
              <strong className="font-bold text-ink">Pump.fun</strong> and{" "}
              <strong className="font-bold text-ink">on-chain wallets</strong> on Solana, BSC, Ethereum and beyond — then
              ranks performance over 7, 30 and 90 days. Follow to watch, or Copy to auto-execute with guardrails the
              original trader doesn&rsquo;t control.
            </p>

            <div className="mt-7 flex flex-wrap gap-2">
              <span className="inline-flex items-center gap-1.5 rounded-full border border-neutral-200 bg-paper px-3 py-1.5 text-[11px] font-extrabold">
                <span className="h-1.5 w-1.5 rounded-full bg-ink" /> Tape
              </span>
              <span className="inline-flex items-center gap-1.5 rounded-full border border-neutral-200 bg-paper px-3 py-1.5 text-[11px] font-extrabold">
                <span className="h-1.5 w-1.5 rounded-full bg-gain" /> Pump.fun
              </span>
              <span className="inline-flex items-center gap-1.5 rounded-full border border-neutral-200 bg-paper px-3 py-1.5 text-[11px] font-extrabold">
                <span className="h-1.5 w-1.5 rounded-full bg-sky-500" /> On-chain wallets
              </span>
              <span className="inline-flex items-center rounded-full bg-neutral-100 px-3 py-1.5 text-[11px] font-bold text-neutral-500">
                SOL · BSC · ETH · Base
              </span>
            </div>

            <div className="mt-8 flex flex-col gap-3.5">
              {[
                {
                  Icon: IcSliders,
                  t: "Your allocation, your cap",
                  d: "Choose what every copied entry spends and the maximum exposure per trader.",
                },
                {
                  Icon: IcTrendUp,
                  t: "TP, SL and trailing stop",
                  d: "Set the exits once. Tape enforces them on every position automatically.",
                },
                {
                  Icon: IcShield,
                  t: "Independent execution",
                  d: "Your exits run even if the original trader is still holding the token.",
                },
                {
                  Icon: IcBolt,
                  t: "Or trade completely solo",
                  d: "Use the same wallet to buy, sell and swap on your own decision — no copy attached.",
                },
              ].map((x) => (
                <div key={x.t} className="flex items-start gap-3">
                  <span className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-paper text-ink">
                    <x.Icon className="h-4 w-4" />
                  </span>
                  <div>
                    <div className="text-[13px] font-extrabold">{x.t}</div>
                    <div className="text-[12.5px] leading-relaxed text-neutral-500">{x.d}</div>
                  </div>
                </div>
              ))}
            </div>

            <button
              type="button"
              onClick={onStart}
              className="mt-8 inline-flex items-center gap-2 rounded-full bg-ink px-6 py-3 text-sm font-extrabold text-white transition-all duration-300 hover:-translate-y-0.5 hover:bg-neutral-800 active:scale-95"
            >
              Set up a copy in the web app <IcChevR className="h-4 w-4" />
            </button>
          </Reveal>

          {/* config card */}
          <Reveal delay={0.1}>
            <div className="relative">
              <div className="absolute -inset-4 -z-10 rounded-[40px] bg-gradient-to-br from-gain/15 via-transparent to-sky-200/40 blur-2xl" />
              <div className="overflow-hidden rounded-3xl border border-neutral-200 bg-paper shadow-[0_40px_80px_-40px_rgba(12,16,28,0.45)]">
                <div className="flex items-center gap-3 border-b border-neutral-200 bg-white px-5 py-4">
                  <Avatar src={TRADERS.suumi.img} name="OxSuumi" size={40} />
                  <div className="min-w-0 flex-1">
                    <div className="flex flex-wrap items-center gap-1.5">
                      <span className="text-[13px] font-extrabold">OxSuumi</span>
                      <Verified className="h-3.5 w-3.5" />
                      <SourceBadge source="On-chain" />
                    </div>
                    <div className="text-[10px] font-semibold text-neutral-400">
                      Solana · +1,203% 90D · 74% win rate
                    </div>
                  </div>
                  <span className="rounded-full bg-gain/15 px-2 py-1 text-[9px] font-extrabold text-[#0b6b3a]">
                    COPY LIVE
                  </span>
                </div>

                <div className="p-5">
                  <div className="grid grid-cols-2 gap-2.5">
                    {RULES.map((r) => (
                      <div key={r.l} className="rounded-xl border border-neutral-200 bg-white p-3">
                        <div className="text-[9px] font-extrabold uppercase tracking-[0.12em] text-neutral-400">
                          {r.l}
                        </div>
                        <div
                          className={cn(
                            "mt-0.5 font-display text-[20px] font-extrabold tracking-tight",
                            r.g && "text-gain",
                            r.r && "text-loss",
                            r.b && "text-sky-600"
                          )}
                        >
                          {r.v}
                        </div>
                        <div className="text-[9px] font-medium text-neutral-400">{r.d}</div>
                      </div>
                    ))}
                  </div>

                  <div className="mt-3 flex items-center gap-2 rounded-xl border border-neutral-200 bg-white p-3">
                    <CoinBadge sym="TAPE" className="h-7 w-7 text-[10px]" />
                    <div className="min-w-0">
                      <div className="text-[11px] font-extrabold">They buy at $100K mcap</div>
                      <div className="text-[10px] font-medium text-neutral-400">
                        Tape deploys your $100 automatically
                      </div>
                    </div>
                    <span className="ml-auto shrink-0 rounded-md bg-ink px-2 py-1 text-[9px] font-extrabold text-white">
                      AUTO
                    </span>
                  </div>

                  <div className="mt-2 flex flex-col gap-1.5 rounded-xl bg-ink p-3.5 text-white">
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-[10px] font-bold text-white/50">Their position</span>
                      <span className="text-[10px] font-extrabold text-white">Still holding</span>
                    </div>
                    <div className="flex items-center justify-between gap-2">
                      <span className="text-[10px] font-bold text-white/50">Your position</span>
                      <span className="flex items-center gap-1.5 rounded-md bg-gain/20 px-2 py-0.5 text-[10px] font-extrabold text-gain">
                        <IcTrendUp className="h-3 w-3" /> TP hit at +100% · exited
                      </span>
                    </div>
                    <div className="mt-1 flex items-center gap-1.5 border-t border-white/10 pt-2 text-[9.5px] font-semibold text-white/40">
                      <IcShield className="h-3 w-3 text-gain" /> Independent exits — enabled
                    </div>
                  </div>

                  <div className="mt-3 flex items-center justify-between rounded-xl border border-neutral-200 bg-white px-3 py-2.5">
                    <div>
                      <div className="text-[9px] font-extrabold uppercase tracking-wider text-neutral-400">
                        Realized on this copy
                      </div>
                      <div className="text-[14px] font-extrabold text-gain">+$101.40</div>
                    </div>
                    <Sparkline
                      points={[2, 4, 3, 7, 6, 9, 8, 12, 11, 15, 14, 18]}
                      w={120}
                      h={38}
                      id="copy-engine-spark"
                      delay={0.4}
                    />
                  </div>

                  <button
                    type="button"
                    onClick={onStart}
                    className="mt-3 w-full rounded-full bg-ink py-2.5 text-[12px] font-extrabold text-white transition-colors hover:bg-neutral-700"
                  >
                    Start copying
                  </button>
                  <p className="mt-2 text-center text-[9.5px] font-medium text-neutral-400">
                    Illustration. Exits run independently of the trader&rsquo;s position.
                  </p>
                </div>
              </div>
            </div>
          </Reveal>
        </div>
      </div>
    </section>
  );
}

/* ================= ranked leaderboard with Copy ================= */

const SPARKS = [
  [2, 5, 4, 8, 7, 12, 10, 16],
  [3, 4, 7, 5, 9, 8, 12, 14],
  [2, 6, 3, 5, 8, 6, 10, 11],
  [1, 4, 3, 6, 5, 9, 8, 12],
  [2, 3, 5, 4, 6, 8, 7, 10],
  [3, 5, 4, 3, 6, 5, 8, 9],
  [2, 4, 3, 5, 7, 6, 9, 11],
];

export function CopyLeaderboard({ onCopy }: { onCopy: () => void }) {
  const [period, setPeriod] = useState<Period>("90D");
  const [source, setSource] = useState<"All" | Source>("All");
  const rows = [...RANKED]
    .filter((r) => source === "All" || r.source === source)
    .sort((a, b) => b.p[period] - a.p[period]);

  return (
    <section id="traders" className="border-y border-neutral-200 bg-paper">
      <div className="mx-auto max-w-[1400px] px-6 py-24 md:py-28">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <Reveal>
            <Kicker>Cross-platform leaderboard</Kicker>
            <h2 className="mt-6 max-w-[620px] font-display text-[clamp(2rem,4vw,3.4rem)] font-black leading-[1.02] tracking-[-0.03em]">
              Follow the receipts.
              <br />
              Copy the exits.
            </h2>
            <p className="mt-4 max-w-xl text-[15px] leading-relaxed text-neutral-500">
              The best traders from Tape, Pump.fun and raw on-chain wallets — aggregated, ranked and verified. Every
              profile gets a Follow and a Copy button. Copy runs on the allocation and exits you choose.
            </p>
          </Reveal>
          <Reveal delay={0.1}>
            <span className="inline-flex items-center gap-2 rounded-full border border-neutral-200 bg-white px-4 py-2 text-[11px] font-bold text-neutral-500">
              <span className="relative flex h-2 w-2">
                <span className="ping-ring absolute h-full w-full rounded-full bg-gain" />
                <span className="relative h-2 w-2 rounded-full bg-gain" />
              </span>
              PnL updates every fill
            </span>
          </Reveal>
        </div>

        <div className="mt-8 flex flex-wrap items-center gap-3">
          <div className="flex rounded-full border border-neutral-200 bg-white p-0.5">
            {(["7D", "30D", "90D"] as Period[]).map((p) => (
              <button
                key={p}
                type="button"
                onClick={() => setPeriod(p)}
                className={cn(
                  "rounded-full px-4 py-1.5 text-[11px] font-extrabold transition-all",
                  period === p ? "bg-ink text-white shadow-sm" : "text-neutral-500 hover:text-ink"
                )}
              >
                {p} PnL
              </button>
            ))}
          </div>
          <div className="flex flex-wrap items-center gap-1.5">
            {(["All", "Tape", "Pump.fun", "On-chain"] as const).map((s) => (
              <button
                key={s}
                type="button"
                onClick={() => setSource(s)}
                className={cn(
                  "rounded-full border px-3 py-1.5 text-[11px] font-bold transition-colors",
                  source === s
                    ? "border-ink bg-ink text-white"
                    : "border-neutral-200 bg-white text-neutral-500 hover:border-neutral-400 hover:text-ink"
                )}
              >
                {s}
              </button>
            ))}
          </div>
          <span className="ml-auto hidden text-[11px] font-semibold text-neutral-400 sm:block">
            {rows.length} ranked · 7D / 30D / 90D
          </span>
        </div>

        <Reveal delay={0.12} className="mt-5">
          <div className="overflow-x-auto rounded-3xl border border-neutral-200 bg-white">
            <table className="w-full min-w-[860px] text-left">
              <thead>
                <tr className="border-b border-neutral-200 text-[10px] font-extrabold uppercase tracking-[0.16em] text-neutral-400">
                  <th className="px-5 py-4">#</th>
                  <th className="px-3 py-4">Trader / Wallet</th>
                  <th className="px-3 py-4">Source</th>
                  <th className="px-3 py-4">Win rate</th>
                  <th className="px-3 py-4">{period} PnL</th>
                  <th className="px-3 py-4">Tracked AUM</th>
                  <th className="px-3 py-4">Curve</th>
                  <th className="px-5 py-4 text-right">Follow / Copy</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((r, i) => (
                  <tr key={r.id} className="border-b border-neutral-100 transition-colors last:border-0 hover:bg-paper/60">
                    <td className="px-5 py-3.5 font-display text-[15px] font-black text-neutral-300">
                      {String(i + 1).padStart(2, "0")}
                    </td>
                    <td className="px-3 py-3.5">
                      <div className="flex items-center gap-3">
                        <Avatar src={r.img} name={r.name} size={38} />
                        <div>
                          <div className="flex items-center gap-1.5">
                            <span className="text-[13.5px] font-extrabold">{r.name}</span>
                            <Verified className="h-3.5 w-3.5" />
                          </div>
                          <div className="font-mono text-[10.5px] font-medium text-neutral-400">
                            {r.handle} · {r.chain}
                          </div>
                        </div>
                      </div>
                    </td>
                    <td className="px-3 py-3.5">
                      <SourceBadge source={r.source} />
                    </td>
                    <td className="px-3 py-3.5 text-[13px] font-bold text-neutral-600">{r.win}</td>
                    <td className="px-3 py-3.5 font-display text-[16px] font-black text-gain">{fmtPct(r.p[period])}</td>
                    <td className="px-3 py-3.5 text-[13px] font-bold text-neutral-600">{r.aum}</td>
                    <td className="px-3 py-3.5">
                      <Sparkline points={SPARKS[i % SPARKS.length]} w={84} h={28} id={`cl-${r.id}`} delay={0.5 + i * 0.08} />
                    </td>
                    <td className="px-5 py-3.5">
                      <div className="flex items-center justify-end gap-1.5">
                        <FollowButton className="px-3 py-1.5 text-[10.5px]" />
                        <button
                          type="button"
                          onClick={onCopy}
                          className="inline-flex items-center gap-1 rounded-full bg-ink px-3 py-1.5 text-[10.5px] font-extrabold text-white transition-all hover:bg-neutral-700 active:scale-95"
                        >
                          <IcCopy className="h-3 w-3" /> Copy
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Reveal>

        <div className="mt-4 flex flex-wrap items-center gap-x-6 gap-y-2 rounded-2xl border border-neutral-200 bg-white px-5 py-4">
          <span className="text-[11px] font-extrabold uppercase tracking-[0.14em] text-neutral-400">On every profile</span>
          <span className="flex items-center gap-1.5 text-[11.5px] font-bold text-neutral-600">
            <IcChevR className="h-3.5 w-3.5 text-neutral-400" /> Follow — see theses, trades and alerts
          </span>
          <span className="flex items-center gap-1.5 text-[11.5px] font-bold text-neutral-600">
            <IcCopy className="h-3.5 w-3.5 text-neutral-400" /> Copy — auto-execute with your allocation, TP, SL, trail
          </span>
          <span className="flex items-center gap-1.5 text-[11.5px] font-bold text-neutral-600">
            <IcSliders className="h-3.5 w-3.5 text-neutral-400" /> Or trade independently from the same wallet
          </span>
        </div>
      </div>
    </section>
  );
}
