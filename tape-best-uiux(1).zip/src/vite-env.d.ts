/// <reference types="vite/client" />

interface ImportMetaEnv {
  readonly VITE_TAPE_API_URL?: string;
  readonly VITE_PUMPFUN_INDEXER_URL?: string;
  readonly VITE_ONCHAIN_INDEXER_URL?: string;
  readonly VITE_DATA_PROXY_URL?: string;
  readonly VITE_MARKET_POLL_MS?: string;
}

interface ImportMeta {
  readonly env: ImportMetaEnv;
}
