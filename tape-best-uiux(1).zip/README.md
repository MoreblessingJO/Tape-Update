# Tape

**Follow traders. See trades. Trade smarter.** A social trading product: discover and rank
traders across Tape, Pump.fun and on-chain wallets, follow their trades and theses, or copy
them with your own allocation, take profit, stop loss, trailing stop and max investment.

Built with **React 19 + Vite + TypeScript + Tailwind CSS v4**.

## Quick start

```bash
npm install
npm run dev      # local dev server
npm run build    # production build -> dist/
npm run preview  # preview the production build
```

Node 20+ recommended.

## What's inside

| Area | Details |
| --- | --- |
| `src/App.tsx` | Landing page composition + landing ⇄ web app routing |
| `src/phones.tsx` | The five floating phone screens (Home, Discover, Profile, Trade post, Notifications) |
| `src/appshell.tsx` | Signed-in web app — nav, Home, Discover, Trade, Copy, Wallet, Profile, Notifications |
| `src/copytrade.tsx` | Copy configuration modal, copy engine state, execution log, ranked board |
| `src/webapp.tsx` | Auth (sign in / create account) then the app shell |
| `src/sections.tsx`, `src/copylanding.tsx` | Marketing sections |
| `src/api/market.tsx` | Normalized market-data contract + provider config + `MarketProvider` |
| `src/DataSource.tsx` | In-app **Data sources** page: provider status and wiring map |
| `src/data.tsx`, `src/icons.tsx`, `src/ui.tsx` | Seed content, custom icon set, shared primitives |
| `src/index.css` | Theme tokens, motion, reduced-motion handling |

## Environment

Copy `.env.example` to `.env.local` and fill in your own backend routes:

```bash
cp .env.example .env.local
```

Provider secrets stay **server-side** — never prefix them with `VITE_` and never commit
`.env.local`. See **[INTEGRATIONS.md](./INTEGRATIONS.md)** for the live-data architecture
(Tape native, Pump.fun via PumpPortal, on-chain via Birdeye/Helius) and the required
`ApiTrader` response contract.

Until those URLs are configured, the app runs clearly-labelled demo data and the top bar
shows a **Demo data** badge.

## Deploy

Any static host works; `npm run build` emits a self-contained `dist/`.

- **Vercel:** import the repo → framework preset **Vite** → build `npm run build`, output `dist`
- **Netlify:** build `npm run build`, publish directory `dist`
- **GitHub Pages:** publish `dist` (set `base` in `vite.config.ts` if serving from a subpath)

Add the `VITE_*` variables in the host's environment settings.

## Risk notice

Crypto is volatile. Nothing in this product is financial advice, and copy trading does not
remove risk. Never trade more than you can afford to lose.
