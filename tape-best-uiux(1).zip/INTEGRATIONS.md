# Tape — Live market data integration

The UI currently runs on clearly-labelled **demo data**. Everything needed to swap in live
Feeds is already in place behind one normalized contract.

## Where it lives

| File | Responsibility |
| --- | --- |
| `src/api/market.tsx` | Provider config, normalized `ApiTrader` contract, fetch/ranking, `MarketProvider`, `useMarket()` |
| `src/DataSource.tsx` | In-app **Data sources** page (status, endpoints, field mapping, checklist) |
| `src/copytrade.tsx` → `RankedBoard` | Consumes `rows` from `useMarket()`; Follow + Copy on every row |
| `src/appshell.tsx` | Passes live rows into Discover; top-bar live/demo pill → Sources page |
| `src/webapp.tsx` | Mounts `MarketProvider` around the authenticated app |
| `.env.example` | The three public URLs + server-side secrets |

## Architecture (do not call providers from the browser)

```
                 ┌────────────────────────────────────────────┐
 Browser  ─────► │  Tape API / serverless proxy               │
 (no keys)       │  • holds provider keys                     │
                 │  • normalizes → ApiTrader                  │
                 │  • computes PnL, win rate, AUM, ranking    │
                 │  • executes copy TP/SL/trail               │
                 └───────┬─────────────┬─────────────┬────────┘
                         │             │             │
                  Tape native      Pump.fun       On-chain
                  own DB +         PumpPortal     Birdeye / Helius
                  exchange APIs    WS + REST      Alchemy / Covalent
```

## The three upstreams

### 1. Tape native — `VITE_TAPE_API_URL`
Own backend. Trades are recorded for Tape traders through connected exchange accounts
(Binance/Bybit via CCXT) and linked wallets.

- `GET /v1/leaderboard?window=7d|30d|90d&limit=50` → `{ traders: ApiTrader[] }`
- `GET /v1/trades?since=<cursor>` → fills for the social feed
- `WS /v1/stream` → new fills/alerts (copy engine entry triggers)
- `POST /v1/copies` → user risk config (allocation, cap, TP, SL, trail)
- `GET /v1/copies/:id/executions` → execution log shown in the app

### 2. Pump.fun — `VITE_PUMPFUN_INDEXER_URL`
PumpPortal is the practical realtime source (unofficial for pump.fun):
`wss://pumpportal.fun/api/data` with channels `subscribeAccountTrade`,
`subscribeNewToken`, `subscribeMigration`. Account/token subscriptions require an API key
and a linked funded wallet. Your indexer subscribes once, persists events to Postgres and
exposes the normalized contract.

- Upstream: `wss://pumpportal.fun/api/data?api-key=…` (server only)
- Also `GET /trades?mint=<CA>&limit=100` behind your route for token history
- Market-cap context for the copy preview comes from the launchpad/pool state.

### 3. On-chain wallets — `VITE_ONCHAIN_INDEXER_URL`
- Solana: Birdeye `GET /wallet/v2/pnl/summary`, `GET /v1/wallet/tx_list`,
  or Helius `getSignaturesForAddress` + `getTransaction`
- EVM (BSC/Ethereum/Base): Alchemy, Moralis or Covalent wallet activity
- Ranking: aggregate per-wallet trade history → realized/deployed PnL over 7/30/90 days
- Wallets are discovered/indexed — users do not connect them to view.

## Required response contract

```json
{
  "traders": [
    {
      "id": "sol:0x4f…9c2d",
      "venue": "onchain",
      "name": "OxSuumi",
      "handle": "0x4f…9c2d",
      "avatar_url": "https://…",
      "chain": "Solana",
      "verified": true,
      "followers": 9100,
      "win_rate": 0.74,
      "aum_usd": 4200000,
      "pnl_7d": 312,
      "pnl_30d": 684,
      "pnl_90d": 1203,
      "updated_at": "2026-04-07T12:00:00Z"
    }
  ]
}
```

`src/api/market.tsx` maps this to the UI `Ranked` type (`win`, `aum`, `p.followers`,
`p[7D|30D|90D]`). Any provider can be added by appending a `SOURCE_CONFIG` entry and a
venue mapping.

## Enabling live mode

1. `cp .env.example .env.local`
2. Deploy the proxy routes; set `VITE_TAPE_API_URL`, `VITE_PUMPFUN_INDEXER_URL`,
   `VITE_ONCHAIN_INDEXER_URL` to them.
3. Keep `BIRDEYE_API_KEY`, `HELIUS_API_KEY`, `PUMPPORTAL_API_KEY`, exchange secrets and
   `DATABASE_URL` **server-side only** (no `VITE_` prefix).
4. Each provider independently flips from **Demo data** to **Live** in the top bar and on
   the Data sources page; an error on one provider leaves the others running.

## Copy engine execution (must be server-side)

The browser sends the user's config only. The worker listens for trader fills and, per
copy: checks max-investment headroom → executes the entry at the user's allocation →
registers TP, SL and trailing triggers with an order/position service → closes on trigger
whether or not the trader still holds. Idempotency keys on `(copy_id, trader_fill_id)`
prevent double execution.

## Rate limits, caching, cost

- Cache leaderboard snapshots in Postgres materialized views; refresh every 30–60s.
- Poll wallet endpoints on a schedule (not per user); fan-out reads are served from cache.
- Deduplicate wallets across venues before ranking; keep venue + chain on the row.
- Show `updated_at` in the UI and never label bundled data as live.
